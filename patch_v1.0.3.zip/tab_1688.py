#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1688 商品图影素材采集与批量下载面板
提供高保真原图提取、规格/主图/详情分类浏览、多选批量下载、高清大图画廊预览
"""

import os
import re
import urllib.request
import subprocess
from typing import List, Dict, Optional

from PySide6.QtCore import (
    Qt, QObject, Signal, QUrl, QTimer, QSize, QRunnable, QThreadPool
)
from PySide6.QtGui import (
    QFont, QIcon, QPixmap, QImage, QDesktopServices, QColor, QCursor
)
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QLabel,
    QScrollArea, QFrame, QGridLayout, QFileDialog, QMessageBox,
    QProgressBar, QCheckBox, QToolButton, QDialog, QButtonGroup,
    QRadioButton, QSizePolicy, QApplication
)
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage, QWebEngineSettings

from service_1688 import Alibaba1688Engine, parse_1688_offer_url
from service_douyin import DouyinEngine, parse_douyin_offer_url
from downloader_1688 import (
    clean_alibaba_media_url, get_thumbnail_url, sanitize_filename, BatchDownloadWorker
)
from nmpa_desktop_app import ImagePreviewDialog


def detect_and_parse_ecommerce_url(raw_input: str) -> tuple[str, str]:
    """智能识别输入是 1688 还是 抖音链接/分享文案，返回规范化平台与URL"""
    if not raw_input:
        return "", ""
    raw = raw_input.strip()

    # 1. 尝试从混合分享文案中提取 http 链接
    m = re.search(r'https?://[^\s\u4e00-\u9fa5]+', raw)
    url = m.group(0) if m else raw

    # 2. 判断是否是抖音短链 (v.douyin.com)
    if "v.douyin.com" in url:
        url = parse_douyin_offer_url(url)

    # 3. 判定平台
    if any(k in url for k in ["jinritemai.com", "douyin.com", "iesdouyin.com"]):
        return "douyin", parse_douyin_offer_url(url)
    elif "1688.com" in url or (url.isdigit() and len(url) >= 8):
        return "1688", parse_1688_offer_url(url)

    # 默认兜底按 1688 处理
    return "1688", parse_1688_offer_url(url)


GLOBAL_THUMB_CACHE = {}
THUMB_POOL = QThreadPool()
THUMB_POOL.setMaxThreadCount(16)


class AsyncImageLoaderSignals(QObject):
    sig_loaded = Signal(str, bytes, str)  # item_id, bytes, clean_url
    sig_error = Signal(str, str)


class AsyncImageLoaderWorker(QRunnable):
    """异步下载单张图片用于卡片展示与原图缓存"""
    def __init__(self, item_id: str, fetch_url: str, clean_url: str):
        super().__init__()
        self.item_id = item_id
        self.fetch_url = fetch_url
        self.clean_url = clean_url
        self.signals = AsyncImageLoaderSignals()

    def run(self):
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
            }
            if "alicdn.com" in self.fetch_url:
                headers["Referer"] = "https://detail.1688.com/"
            elif any(d in self.fetch_url for d in ["ecombdimg.com", "byteimg.com", "zjcdn.com", "bytednsdoc.com"]):
                headers["Referer"] = "https://haohuo.jinritemai.com/"

            req = urllib.request.Request(self.fetch_url, headers=headers)
            with urllib.request.urlopen(req, timeout=12) as resp:
                raw_bytes = resp.read()
            
            try:
                self.signals.sig_loaded.emit(self.item_id, raw_bytes, self.clean_url)
            except RuntimeError:
                pass
        except Exception as e:
            try:
                self.signals.sig_error.emit(self.item_id, str(e))
            except Exception:
                pass
        except Exception as e:
            try:
                self.signals.sig_error.emit(self.item_id, str(e))
            except Exception:
                pass


class MediaCard1688(QFrame):
    """单个媒体素材展示卡片 (支持多选、缩略图异步加载、分类标记、独立下载与高清预览)"""
    sig_selection_changed = Signal(str, bool)
    sig_preview_requested = Signal(dict)
    sig_single_download = Signal(dict)

    def __init__(self, item: Dict, parent=None):
        super().__init__(parent)
        self.item = item
        self.raw_bytes = None
        self.is_selected = True

        self.setFixedSize(180, 240)
        self.setObjectName("media_card")
        self.setStyleSheet("""
            QFrame#media_card {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 10px;
            }
            QFrame#media_card:hover {
                border: 1.5px solid #007AFF;
                background-color: #F8FAFC;
            }
        """)

        self.init_ui()
        self.load_thumbnail()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # 顶部工具栏: 选择复选框 + 分类标签
        top_bar = QHBoxLayout()
        top_bar.setSpacing(4)

        self.chk_select = QCheckBox()
        self.chk_select.setChecked(True)
        self.chk_select.setCursor(Qt.PointingHandCursor)
        self.chk_select.toggled.connect(self._on_toggled)
        top_bar.addWidget(self.chk_select)

        cat = self.item.get("category", "main")
        badge_text, badge_style = self._get_badge_style(cat)
        self.lbl_badge = QLabel(badge_text)
        self.lbl_badge.setStyleSheet(badge_style)
        self.lbl_badge.setFixedHeight(20)
        top_bar.addWidget(self.lbl_badge)
        top_bar.addStretch()

        layout.addLayout(top_bar)

        # 中部缩略图展示区
        self.thumb_container = QFrame()
        self.thumb_container.setFixedHeight(130)
        self.thumb_container.setStyleSheet("""
            background-color: #F1F5F9;
            border-radius: 6px;
        """)
        thumb_layout = QVBoxLayout(self.thumb_container)
        thumb_layout.setContentsMargins(0, 0, 0, 0)
        thumb_layout.setAlignment(Qt.AlignCenter)

        self.lbl_image = QLabel("载入中...")
        self.lbl_image.setAlignment(Qt.AlignCenter)
        self.lbl_image.setStyleSheet("color: #94A3B8; font-size: 11px;")
        self.lbl_image.setCursor(Qt.PointingHandCursor)
        self.lbl_image.mousePressEvent = lambda e: self.sig_preview_requested.emit(self.item)
        thumb_layout.addWidget(self.lbl_image)

        layout.addWidget(self.thumb_container)

        # 底部名称与单项操作
        self.lbl_title = QLabel(self.item.get("title", ""))
        self.lbl_title.setStyleSheet("font-size: 11px; font-weight: 500; color: #1E293B;")
        self.lbl_title.setToolTip(self.item.get("title", ""))
        self.lbl_title.setFixedHeight(18)
        layout.addWidget(self.lbl_title)

        bottom_bar = QHBoxLayout()
        bottom_bar.setSpacing(4)

        self.btn_preview = QToolButton()
        self.btn_preview.setText("🔍 预览")
        self.btn_preview.setCursor(Qt.PointingHandCursor)
        self.btn_preview.setStyleSheet("""
            QToolButton {
                background-color: #F1F5F9;
                color: #475569;
                border: none;
                border-radius: 4px;
                padding: 2px 6px;
                font-size: 10px;
                font-weight: 500;
            }
            QToolButton:hover {
                background-color: #E2E8F0;
                color: #0F172A;
            }
        """)
        self.btn_preview.clicked.connect(lambda: self.sig_preview_requested.emit(self.item))
        bottom_bar.addWidget(self.btn_preview)

        self.btn_download = QToolButton()
        self.btn_download.setText("💾 单下")
        self.btn_download.setCursor(Qt.PointingHandCursor)
        self.btn_download.setStyleSheet("""
            QToolButton {
                background-color: #EFF6FF;
                color: #1D4ED8;
                border: none;
                border-radius: 4px;
                padding: 2px 6px;
                font-size: 10px;
                font-weight: 500;
            }
            QToolButton:hover {
                background-color: #DBEAFE;
                color: #1E40AF;
            }
        """)
        self.btn_download.clicked.connect(lambda: self.sig_single_download.emit(self.item))
        bottom_bar.addWidget(self.btn_download)

        bottom_bar.addStretch()
        layout.addLayout(bottom_bar)

    def _get_badge_style(self, cat: str):
        if cat == "main":
            return "主图", "background-color: #DBEAFE; color: #1E40AF; font-size: 10px; font-weight: 600; padding: 2px 6px; border-radius: 4px;"
        elif cat == "sku":
            return "规格SKU", "background-color: #DCFCE7; color: #166534; font-size: 10px; font-weight: 600; padding: 2px 6px; border-radius: 4px;"
        elif cat == "detail":
            return "详情图", "background-color: #F3E8FF; color: #6B21A8; font-size: 10px; font-weight: 600; padding: 2px 6px; border-radius: 4px;"
        elif cat == "video":
            return "🎬 视频", "background-color: #FEE2E2; color: #991B1B; font-size: 10px; font-weight: 600; padding: 2px 6px; border-radius: 4px;"
        return "素材", "background-color: #F1F5F9; color: #475569; font-size: 10px; font-weight: 600; padding: 2px 6px; border-radius: 4px;"

    def load_thumbnail(self):
        url = self.item.get("thumb_url") or self.item.get("url")
        if not url:
            self.lbl_image.setText("无预览")
            return

        clean_url = clean_alibaba_media_url(url)
        # 为视频使用其封面图
        if self.item.get("category") == "video" and self.item.get("cover"):
            clean_url = clean_alibaba_media_url(self.item.get("cover"))

        # 1. 命中内存缓存直接秒显
        if clean_url in GLOBAL_THUMB_CACHE:
            pixmap, raw_bytes = GLOBAL_THUMB_CACHE[clean_url]
            self.raw_bytes = raw_bytes
            scaled = pixmap.scaled(160, 126, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.lbl_image.setPixmap(scaled)
            return

        # 2. 网络下载采用 CDN 尺寸加速缩略图提升 5~10 倍加载速度 (1688 与 抖音专属优化)
        req_url = get_thumbnail_url(clean_url)

        worker = AsyncImageLoaderWorker(self.item.get("id", ""), req_url, clean_url)
        worker.signals.sig_loaded.connect(self._on_image_loaded)
        worker.signals.sig_error.connect(lambda fid, err: self.lbl_image.setText("加载失败"))
        THUMB_POOL.start(worker)

    def _on_image_loaded(self, item_id: str, raw_bytes: bytes, clean_url: str):
        if item_id != self.item.get("id"):
            return
        pixmap = QPixmap()
        if not pixmap.loadFromData(raw_bytes):
            self.lbl_image.setText("解码失败")
            return
        if clean_url:
            GLOBAL_THUMB_CACHE[clean_url] = (pixmap, raw_bytes)
        self.raw_bytes = raw_bytes
        scaled = pixmap.scaled(160, 126, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.lbl_image.setPixmap(scaled)

    def _on_toggled(self, checked: bool):
        self.is_selected = checked
        self.sig_selection_changed.emit(self.item.get("id", ""), checked)

    def set_checked(self, checked: bool):
        self.chk_select.blockSignals(True)
        self.chk_select.setChecked(checked)
        self.is_selected = checked
        self.chk_select.blockSignals(False)


class InteractiveBrowserDialog(QDialog):
    """电商平台安全滑块验证与扫码登录独立交互窗口 (采用专属独立视图，不抢占后台引擎)"""
    def __init__(self, profile: QWebEngineProfile, canonical_url: str = "", default_action: str = "login", on_completed_callback=None, parent=None):
        super().__init__(parent)
        self.profile = profile
        self.canonical_url = canonical_url or "https://detail.1688.com/"
        self.default_action = default_action
        self.on_completed = on_completed_callback
        self.setWindowTitle("电商平台认证与安全验证助手")
        self.resize(1060, 780)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        # 顶部提示栏
        hint_frame = QFrame()
        hint_frame.setStyleSheet("""
            QFrame {
                background-color: #FEF3C7;
                border: 1px solid #F59E0B;
                border-radius: 8px;
                padding: 8px 12px;
            }
        """)
        h_box = QHBoxLayout(hint_frame)
        h_box.setContentsMargins(4, 4, 4, 4)
        h_box.setSpacing(10)

        lbl_icon = QLabel("🛡️")
        lbl_icon.setStyleSheet("font-size: 20px;")
        h_box.addWidget(lbl_icon)

        lbl_text = QLabel(
            "<b>安全验证与登录提示：</b><br>"
            "1. <b>扫码登录</b>：点击下方「🔑 1688 扫码登录」或「🛍️ 淘宝扫码登录」，使用手机 App 扫码登录（登录态将自动永久保存）。<br>"
            "2. <b>滑块验证</b>：若遇到安全拦截，请点击「📦 查看当前商品(滑块验证)」，在下方窗口中手动拖动滑块完成校验。<br>"
            "3. <b>完成验证</b>：操作成功后，点击右下方「✅ 我已完成验证/登录，立即提取素材」即可自动提取商品图影。"
        )
        lbl_text.setStyleSheet("color: #92400E; font-size: 12px; line-height: 1.4;")
        h_box.addWidget(lbl_text, stretch=1)
        layout.addWidget(hint_frame)

        # 导航与快捷操作栏
        nav_bar = QHBoxLayout()
        nav_bar.setSpacing(8)

        btn_style_login = """
            QPushButton {
                background-color: #EFF6FF;
                color: #1D4ED8;
                border: 1px solid #BFDBFE;
                border-radius: 6px;
                padding: 6px 12px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #DBEAFE;
            }
        """
        btn_style_prod = """
            QPushButton {
                background-color: #F8FAFC;
                color: #334155;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 6px 12px;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #E2E8F0;
            }
        """

        is_douyin = "douyin" in self.canonical_url or "jinritemai" in self.canonical_url

        if is_douyin:
            self.btn_douyin = QPushButton("🎵 抖音商城登录")
            self.btn_douyin.setStyleSheet(btn_style_login)
            self.btn_douyin.clicked.connect(lambda: self.navigate_to("https://haohuo.jinritemai.com/"))
            nav_bar.addWidget(self.btn_douyin)
        else:
            self.btn_1688_login = QPushButton("🔑 1688 扫码登录")
            self.btn_1688_login.setStyleSheet(btn_style_login)
            self.btn_1688_login.clicked.connect(lambda: self.navigate_to("https://login.1688.com/member/signin.htm"))
            nav_bar.addWidget(self.btn_1688_login)

            self.btn_taobao_login = QPushButton("🛍️ 淘宝扫码登录")
            self.btn_taobao_login.setStyleSheet(btn_style_login)
            self.btn_taobao_login.clicked.connect(lambda: self.navigate_to("https://login.taobao.com/member/login.jhtml"))
            nav_bar.addWidget(self.btn_taobao_login)

        self.btn_product = QPushButton("📦 当前商品(滑块验证)")
        self.btn_product.setStyleSheet(btn_style_prod)
        self.btn_product.clicked.connect(lambda: self.navigate_to(self.canonical_url))
        nav_bar.addWidget(self.btn_product)

        self.input_url = QLineEdit()
        self.input_url.setFixedHeight(32)
        self.input_url.setPlaceholderText("请输入网址...")
        self.input_url.setStyleSheet("""
            QLineEdit {
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 4px 8px;
                font-size: 12px;
                background-color: #FFFFFF;
                color: #0F172A;
            }
        """)
        self.input_url.returnPressed.connect(lambda: self.navigate_to(self.input_url.text().strip()))
        nav_bar.addWidget(self.input_url, stretch=1)

        btn_go = QPushButton("前往")
        btn_go.setFixedHeight(32)
        btn_go.setStyleSheet(btn_style_prod)
        btn_go.clicked.connect(lambda: self.navigate_to(self.input_url.text().strip()))
        nav_bar.addWidget(btn_go)

        btn_reload = QPushButton("🔄 刷新")
        btn_reload.setFixedHeight(32)
        btn_reload.setStyleSheet(btn_style_prod)
        btn_reload.clicked.connect(self._do_reload)
        nav_bar.addWidget(btn_reload)

        btn_clear = QPushButton("🧹 清除账号/退出登录")
        btn_clear.setFixedHeight(32)
        btn_clear.setToolTip("清空本窗口与软件内已保存的 1688 账号及所有 Cookie 登录态")
        btn_clear.setStyleSheet("""
            QPushButton {
                background-color: #FEF2F2;
                color: #DC2626;
                border: 1px solid #FECACA;
                border-radius: 6px;
                padding: 0 10px;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #FEE2E2;
            }
        """)
        btn_clear.clicked.connect(self._do_clear_cookies)
        nav_bar.addWidget(btn_clear)

        layout.addLayout(nav_bar)

        # 专用的独立 WebEngineView，完全不抢占后台爬虫引擎
        self.page = QWebEnginePage(self.profile, self)
        self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.AutoLoadImages, True)
        self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
        self.view = QWebEngineView(self)
        self.view.setPage(self.page)
        layout.addWidget(self.view, stretch=1)

        self.view.urlChanged.connect(lambda u: self.input_url.setText(u.toString()))

        # 底部操作栏
        bottom_bar = QHBoxLayout()
        bottom_bar.setSpacing(10)

        btn_cancel = QPushButton("关闭窗口")
        btn_cancel.setFixedHeight(38)
        btn_cancel.setStyleSheet(btn_style_prod)
        btn_cancel.clicked.connect(self.reject)
        bottom_bar.addWidget(btn_cancel)

        bottom_bar.addStretch()

        self.btn_finish = QPushButton("✅ 我已完成验证/登录，立即提取素材")
        self.btn_finish.setFixedHeight(38)
        self.btn_finish.setCursor(Qt.PointingHandCursor)
        self.btn_finish.setStyleSheet("""
            QPushButton {
                background-color: #007AFF;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 0 24px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #0062CC;
            }
        """)
        self.btn_finish.clicked.connect(self._on_done_clicked)
        bottom_bar.addWidget(self.btn_finish)

        layout.addLayout(bottom_bar)

        # 初始加载
        if self.default_action == "login":
            if is_douyin:
                self.navigate_to("https://haohuo.jinritemai.com/")
            else:
                self.navigate_to("https://login.1688.com/member/signin.htm")
        else:
            self.navigate_to(self.canonical_url)

    def navigate_to(self, url: str):
        if not url: return
        if not url.startswith("http"): url = "https://" + url
        self.input_url.setText(url)
        self.view.load(QUrl(url))

    def _do_reload(self):
        self.view.reload()

    def _do_clear_cookies(self):
        """清空会话 Cookie 与缓存并刷新至登录页"""
        try:
            self.profile.cookieStore().deleteAllCookies()
            self.profile.clearHttpCache()
            if hasattr(self, "view") and self.view.page():
                self.view.page().profile().cookieStore().deleteAllCookies()
                self.view.page().profile().clearHttpCache()
        except Exception:
            pass
        if "douyin" in self.canonical_url or "jinritemai" in self.canonical_url:
            self.navigate_to("https://haohuo.jinritemai.com/")
        else:
            self.navigate_to("https://login.1688.com/member/signin.htm")

    def _on_done_clicked(self):
        self.accept()
        if self.on_completed:
            self.on_completed()


class DownloadNotificationBanner(QFrame):
    """macOS 原生沉浸式下载结果通知横幅 (完全告别传统阻塞模态弹窗)"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.target_path = ""
        self.is_file = False
        self._dismiss_timer = QTimer(self)
        self._dismiss_timer.setSingleShot(True)
        self._dismiss_timer.timeout.connect(self.hide)
        self.setup_ui()

    def setup_ui(self):
        self.setObjectName("download_notification_banner")
        self.setFixedHeight(56)
        self.setStyleSheet("""
            QFrame#download_notification_banner {
                background-color: #F0FDF4;
                border: 1px solid #86EFAC;
                border-radius: 10px;
            }
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 6, 14, 6)
        layout.setSpacing(12)

        # 图标
        self.lbl_icon = QLabel("✅")
        self.lbl_icon.setStyleSheet("font-size: 20px;")
        layout.addWidget(self.lbl_icon)

        # 文本信息 (标题 + 路径)
        text_layout = QVBoxLayout()
        text_layout.setSpacing(2)
        text_layout.setContentsMargins(0, 0, 0, 0)

        self.lbl_title = QLabel("已成功下载素材！")
        self.lbl_title.setStyleSheet("font-size: 13px; font-weight: 700; color: #166534;")
        text_layout.addWidget(self.lbl_title)

        self.lbl_path = QLabel("保存目录: -")
        self.lbl_path.setStyleSheet("font-size: 11px; color: #475569;")
        self.lbl_path.setTextInteractionFlags(Qt.TextSelectableByMouse)
        text_layout.addWidget(self.lbl_path)

        layout.addLayout(text_layout, stretch=1)

        # 操作按钮区
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(8)

        # 1. 在访达中打开 / 定位
        self.btn_open = QPushButton("📂 在访达 (Finder) 中打开")
        self.btn_open.setFixedHeight(30)
        self.btn_open.setCursor(Qt.PointingHandCursor)
        self.btn_open.setStyleSheet("""
            QPushButton {
                background-color: #16A34A;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 0 14px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #15803D;
            }
            QPushButton:pressed {
                background-color: #166534;
            }
        """)
        self.btn_open.clicked.connect(self._on_open_clicked)
        btn_layout.addWidget(self.btn_open)

        # 2. 复制路径
        self.btn_copy = QPushButton("📋 复制路径")
        self.btn_copy.setFixedHeight(30)
        self.btn_copy.setCursor(Qt.PointingHandCursor)
        self.btn_copy.setStyleSheet("""
            QPushButton {
                background-color: #FFFFFF;
                color: #374151;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 0 12px;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #F8FAFC;
                border-color: #94A3B8;
            }
        """)
        self.btn_copy.clicked.connect(self._on_copy_clicked)
        btn_layout.addWidget(self.btn_copy)

        # 3. 关闭按钮
        self.btn_close = QPushButton("✕")
        self.btn_close.setFixedSize(24, 24)
        self.btn_close.setCursor(Qt.PointingHandCursor)
        self.btn_close.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #94A3B8;
                border: none;
                border-radius: 12px;
                font-size: 13px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(0, 0, 0, 0.06);
                color: #475569;
            }
        """)
        self.btn_close.clicked.connect(self.hide)
        btn_layout.addWidget(self.btn_close)

        layout.addLayout(btn_layout)
        self.hide()

    def enterEvent(self, event):
        # 鼠标悬浮在横幅上时暂停自动消失倒计时
        self._dismiss_timer.stop()
        super().enterEvent(event)

    def leaveEvent(self, event):
        # 鼠标离开后 8 秒自动隐藏
        if self.isVisible():
            self._dismiss_timer.start(8000)
        super().leaveEvent(event)

    def show_notification(self, title: str, path: str = "", is_file: bool = False, is_success: bool = True, auto_hide_seconds: int = 15):
        self.target_path = path
        self.is_file = is_file

        if is_success:
            self.setStyleSheet("""
                QFrame#download_notification_banner {
                    background-color: #F0FDF4;
                    border: 1px solid #86EFAC;
                    border-radius: 10px;
                }
            """)
            self.lbl_icon.setText("✅")
            self.lbl_title.setStyleSheet("font-size: 13px; font-weight: 700; color: #166534;")
            if path:
                self.btn_open.show()
                self.btn_copy.show()
                self.btn_open.setText("📂 在访达中定位" if is_file else "📂 在访达 (Finder) 中打开")
            else:
                self.btn_open.hide()
                self.btn_copy.hide()
        else:
            self.setStyleSheet("""
                QFrame#download_notification_banner {
                    background-color: #FFFBEB;
                    border: 1px solid #FDE68A;
                    border-radius: 10px;
                }
            """)
            self.lbl_icon.setText("⚠️")
            self.lbl_title.setStyleSheet("font-size: 13px; font-weight: 700; color: #92400E;")
            if not path:
                self.btn_open.hide()
                self.btn_copy.hide()

        self.lbl_title.setText(title)

        if path:
            short_path = path
            home = os.path.expanduser("~")
            if short_path.startswith(home):
                short_path = "~" + short_path[len(home):]
            if len(short_path) > 70:
                short_path = short_path[:38] + "..." + short_path[-28:]
            prefix = "文件位置" if is_file else "保存目录"
            self.lbl_path.setText(f"{prefix}: {short_path}")
            self.lbl_path.setToolTip(path)
            self.lbl_path.show()
        else:
            self.lbl_path.hide()

        self.btn_copy.setText("📋 复制路径")
        self.show()

        # macOS 系统级无阻碍横幅提示
        if is_success and path:
            self._notify_macos(title, path)

        self._dismiss_timer.stop()
        if auto_hide_seconds > 0:
            self._dismiss_timer.start(auto_hide_seconds * 1000)

    def _notify_macos(self, title: str, path: str):
        try:
            name = os.path.basename(path) if path else ""
            clean_title = title.replace('"', '\\"')
            clean_name = name.replace('"', '\\"')
            script = f'display notification "{clean_name}" with title "素材下载完成" subtitle "{clean_title}" sound name "Glass"'
            subprocess.Popen(["osascript", "-e", script], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

    def _on_open_clicked(self):
        if not self.target_path or not os.path.exists(self.target_path):
            return
        try:
            if self.is_file:
                subprocess.Popen(["open", "-R", self.target_path])
            else:
                subprocess.Popen(["open", self.target_path])
        except Exception:
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.target_path))

    def _on_copy_clicked(self):
        if self.target_path:
            QApplication.clipboard().setText(self.target_path)
            self.btn_copy.setText("✅ 已复制!")
            QTimer.singleShot(2000, lambda: self.btn_copy.setText("📋 复制路径"))


class Tab1688Widget(QWidget):
    """电商 (1688 / 抖音) 商品图影素材采集与批量下载主功能标签页"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.engine_1688 = Alibaba1688Engine(self)
        self.engine_douyin = DouyinEngine(self)
        self.engine = self.engine_1688  # 保持向下兼容
        self.active_engine = self.engine_1688
        self.current_platform = "1688"

        self.cards: List[MediaCard1688] = []
        self.current_data: Optional[Dict] = None
        self.all_items: List[Dict] = []
        self.filtered_items: List[Dict] = []
        self.active_filter = "all"  # 'all' | 'main' | 'sku' | 'detail' | 'video'
        self.active_download_worker: Optional[BatchDownloadWorker] = None
        self.last_download_folder = ""

        self.init_ui()
        self.setup_signals()

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(18, 16, 18, 16)
        main_layout.setSpacing(12)

        # -----------------------------
        # 1. 顶部搜索与控制栏 (现代化卡片)
        # -----------------------------
        search_card = QFrame()
        search_card.setObjectName("search_card_1688")
        search_card.setStyleSheet("""
            QFrame#search_card_1688 {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 12px;
                padding: 4px;
            }
        """)
        top_bar = QHBoxLayout(search_card)
        top_bar.setContentsMargins(12, 10, 12, 10)
        top_bar.setSpacing(10)

        lbl_icon = QLabel("🛍️")
        lbl_icon.setStyleSheet("font-size: 20px;")
        top_bar.addWidget(lbl_icon)

        self.input_url = QLineEdit()
        self.input_url.setPlaceholderText("粘贴 1688 或 抖音商品详情链接 / 分享文案 (支持自动智能识别)...")
        self.input_url.setText("https://detail.1688.com/offer/786765906618.html")
        self.input_url.setFixedHeight(40)
        self.input_url.setStyleSheet("""
            QLineEdit {
                background-color: #F8FAFC;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                padding: 0 14px;
                font-size: 13px;
                color: #0F172A;
            }
            QLineEdit:focus {
                border: 1.5px solid #007AFF;
                background-color: #FFFFFF;
            }
        """)
        self.input_url.returnPressed.connect(self.start_extract)
        top_bar.addWidget(self.input_url, stretch=1)

        # 粘贴按钮
        self.btn_paste = QPushButton("📋 粘贴")
        self.btn_paste.setFixedHeight(40)
        self.btn_paste.setCursor(Qt.PointingHandCursor)
        self.btn_paste.setStyleSheet(self._btn_secondary_style())
        self.btn_paste.clicked.connect(self._on_paste_clicked)
        top_bar.addWidget(self.btn_paste)

        # 开始提取按钮
        self.btn_extract = QPushButton("🚀 一键提取素材")
        self.btn_extract.setFixedHeight(40)
        self.btn_extract.setCursor(Qt.PointingHandCursor)
        self.btn_extract.setStyleSheet("""
            QPushButton {
                background-color: #FF6000;
                color: #FFFFFF;
                border: none;
                border-radius: 8px;
                padding: 0 22px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #E65100;
            }
            QPushButton:pressed {
                background-color: #BF360C;
            }
            QPushButton:disabled {
                background-color: #CBD5E1;
                color: #94A3B8;
            }
        """)
        self.btn_extract.clicked.connect(self.start_extract)
        top_bar.addWidget(self.btn_extract)

        # 同步本机 Chrome Cookie 按钮
        self.btn_sync_cookie = QPushButton("🔄 同步Cookie")
        self.btn_sync_cookie.setFixedHeight(40)
        self.btn_sync_cookie.setCursor(Qt.PointingHandCursor)
        self.btn_sync_cookie.setToolTip("从本机 Chrome/Edge 浏览器自动同步 1688 登录态，免扫码")
        self.btn_sync_cookie.setStyleSheet(self._btn_secondary_style())
        self.btn_sync_cookie.clicked.connect(self.sync_chrome_cookie)
        top_bar.addWidget(self.btn_sync_cookie)

        # 辅助网页/登录窗口
        self.btn_open_browser = QPushButton("👁️ 验证/登录窗口")
        self.btn_open_browser.setFixedHeight(40)
        self.btn_open_browser.setCursor(Qt.PointingHandCursor)
        self.btn_open_browser.setToolTip("打开内置 Chromium 界面进行扫码登录或滑动安全滑块")
        self.btn_open_browser.setStyleSheet(self._btn_secondary_style())
        self.btn_open_browser.clicked.connect(self.open_interactive_dialog)
        top_bar.addWidget(self.btn_open_browser)

        main_layout.addWidget(search_card)

        # -----------------------------
        # 2. 状态提示与动态进度条
        # -----------------------------
        status_bar_layout = QHBoxLayout()
        self.lbl_status = QLabel("就绪。请输入 1688 或 抖音商品链接并点击「一键提取素材」。")
        self.lbl_status.setStyleSheet("color: #64748B; font-size: 12px;")
        status_bar_layout.addWidget(self.lbl_status)
        status_bar_layout.addStretch()

        self.lbl_cookie_badge = QLabel("🌐 平台: 自动识别")
        self.lbl_cookie_badge.setStyleSheet("""
            QLabel {
                background-color: #F1F5F9;
                color: #475569;
                font-size: 11px;
                font-weight: 600;
                padding: 4px 10px;
                border-radius: 4px;
            }
        """)
        status_bar_layout.addWidget(self.lbl_cookie_badge)
        main_layout.addLayout(status_bar_layout)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(3)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: none;
                background-color: #E2E8F0;
                border-radius: 1px;
            }
            QProgressBar::chunk {
                background-color: #FF6000;
                border-radius: 1px;
            }
        """)
        self.progress_bar.hide()
        main_layout.addWidget(self.progress_bar)

        # -----------------------------
        # 3. 商品详情概要面板 (提取成功后呈现)
        # -----------------------------
        self.product_card = QFrame()
        self.product_card.setObjectName("product_card")
        self.product_card.setStyleSheet("""
            QFrame#product_card {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 12px;
                padding: 12px 16px;
            }
        """)
        prod_layout = QVBoxLayout(self.product_card)
        prod_layout.setContentsMargins(14, 12, 14, 12)
        prod_layout.setSpacing(8)

        # 标题行
        title_row = QHBoxLayout()
        self.lbl_prod_title = QLabel("商品标题")
        self.lbl_prod_title.setStyleSheet("font-size: 15px; font-weight: 700; color: #0F172A;")
        self.lbl_prod_title.setTextInteractionFlags(Qt.TextSelectableByMouse)
        title_row.addWidget(self.lbl_prod_title, stretch=1)

        self.lbl_price = QLabel("¥0.00")
        self.lbl_price.setStyleSheet("font-size: 16px; font-weight: 800; color: #DC2626;")
        title_row.addWidget(self.lbl_price)
        prod_layout.addLayout(title_row)

        # 厂家/店铺与数量统计胶囊栏
        meta_row = QHBoxLayout()
        meta_row.setSpacing(10)

        self.lbl_meta_info = QLabel("Offer ID: - | 店铺: -")
        self.lbl_meta_info.setStyleSheet("font-size: 12px; color: #64748B;")
        meta_row.addWidget(self.lbl_meta_info)
        meta_row.addStretch()

        self.lbl_badge_main = QLabel("主图: 0")
        self.lbl_badge_main.setStyleSheet("background-color: #DBEAFE; color: #1E40AF; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 4px;")
        meta_row.addWidget(self.lbl_badge_main)

        self.lbl_badge_sku = QLabel("规格SKU: 0")
        self.lbl_badge_sku.setStyleSheet("background-color: #DCFCE7; color: #166534; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 4px;")
        meta_row.addWidget(self.lbl_badge_sku)

        self.lbl_badge_detail = QLabel("详情图: 0")
        self.lbl_badge_detail.setStyleSheet("background-color: #F3E8FF; color: #6B21A8; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 4px;")
        meta_row.addWidget(self.lbl_badge_detail)

        self.lbl_badge_video = QLabel("视频: 0")
        self.lbl_badge_video.setStyleSheet("background-color: #FEE2E2; color: #991B1B; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 4px;")
        meta_row.addWidget(self.lbl_badge_video)

        prod_layout.addLayout(meta_row)

        self.product_card.hide()
        main_layout.addWidget(self.product_card)

        # -----------------------------
        # 4. 批量操作与分类过滤工具栏
        # -----------------------------
        self.action_bar = QFrame()
        self.action_bar.setStyleSheet("""
            QFrame {
                background-color: #F8FAFC;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                padding: 6px 12px;
            }
        """)
        action_layout = QHBoxLayout(self.action_bar)
        action_layout.setContentsMargins(8, 4, 8, 4)
        action_layout.setSpacing(12)

        # 全选勾选框
        self.chk_select_all = QCheckBox("全选")
        self.chk_select_all.setChecked(True)
        self.chk_select_all.setCursor(Qt.PointingHandCursor)
        self.chk_select_all.setStyleSheet("font-size: 13px; font-weight: 600; color: #1E293B;")
        self.chk_select_all.toggled.connect(self._on_select_all_toggled)
        action_layout.addWidget(self.chk_select_all)

        # 分类切换筛选按钮
        self.btn_filter_all = QPushButton("全部 (0)")
        self.btn_filter_all.setCheckable(True)
        self.btn_filter_all.setChecked(True)
        self.btn_filter_all.setStyleSheet(self._filter_btn_style())
        self.btn_filter_all.clicked.connect(lambda: self._set_active_filter("all"))
        action_layout.addWidget(self.btn_filter_all)

        self.btn_filter_main = QPushButton("主图 (0)")
        self.btn_filter_main.setCheckable(True)
        self.btn_filter_main.setStyleSheet(self._filter_btn_style())
        self.btn_filter_main.clicked.connect(lambda: self._set_active_filter("main"))
        action_layout.addWidget(self.btn_filter_main)

        self.btn_filter_sku = QPushButton("规格图 (0)")
        self.btn_filter_sku.setCheckable(True)
        self.btn_filter_sku.setStyleSheet(self._filter_btn_style())
        self.btn_filter_sku.clicked.connect(lambda: self._set_active_filter("sku"))
        action_layout.addWidget(self.btn_filter_sku)

        self.btn_filter_detail = QPushButton("详情图 (0)")
        self.btn_filter_detail.setCheckable(True)
        self.btn_filter_detail.setStyleSheet(self._filter_btn_style())
        self.btn_filter_detail.clicked.connect(lambda: self._set_active_filter("detail"))
        action_layout.addWidget(self.btn_filter_detail)

        self.btn_filter_video = QPushButton("视频 (0)")
        self.btn_filter_video.setCheckable(True)
        self.btn_filter_video.setStyleSheet(self._filter_btn_style())
        self.btn_filter_video.clicked.connect(lambda: self._set_active_filter("video"))
        action_layout.addWidget(self.btn_filter_video)

        action_layout.addStretch()

        # 子文件夹组织选项
        self.chk_organize = QCheckBox("按分类建文件夹保存")
        self.chk_organize.setChecked(True)
        self.chk_organize.setToolTip("开启后将自动建立「01_主图画廊」、「02_规格SKU图」、「03_详情描述图」、「04_商品视频」分类子目录")
        self.chk_organize.setStyleSheet("font-size: 12px; color: #475569;")
        action_layout.addWidget(self.chk_organize)

        # 打开下载文件夹按钮
        self.btn_open_folder = QPushButton("📂 打开下载目录")
        self.btn_open_folder.setFixedHeight(32)
        self.btn_open_folder.setCursor(Qt.PointingHandCursor)
        self.btn_open_folder.setStyleSheet(self._btn_secondary_style())
        self.btn_open_folder.clicked.connect(self._open_download_folder)
        self.btn_open_folder.hide()
        action_layout.addWidget(self.btn_open_folder)

        # 批量下载主按钮
        self.btn_download_selected = QPushButton("📥 批量下载选中项 (0)")
        self.btn_download_selected.setFixedHeight(32)
        self.btn_download_selected.setCursor(Qt.PointingHandCursor)
        self.btn_download_selected.setStyleSheet("""
            QPushButton {
                background-color: #007AFF;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 0 16px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #0062CC;
            }
            QPushButton:disabled {
                background-color: #CBD5E1;
                color: #94A3B8;
            }
        """)
        self.btn_download_selected.clicked.connect(self.start_batch_download)
        action_layout.addWidget(self.btn_download_selected)

        self.action_bar.hide()
        main_layout.addWidget(self.action_bar)

        # -----------------------------
        # 5. 下载进度条指示面板
        # -----------------------------
        self.download_progress_card = QFrame()
        self.download_progress_card.setStyleSheet("""
            QFrame {
                background-color: #EFF6FF;
                border: 1px solid #BFDBFE;
                border-radius: 8px;
                padding: 8px 14px;
            }
        """)
        dl_layout = QHBoxLayout(self.download_progress_card)
        dl_layout.setContentsMargins(10, 6, 10, 6)

        self.lbl_dl_status = QLabel("正在下载中: 0/0...")
        self.lbl_dl_status.setStyleSheet("color: #1D4ED8; font-size: 12px; font-weight: 600;")
        dl_layout.addWidget(self.lbl_dl_status, stretch=1)

        self.dl_bar = QProgressBar()
        self.dl_bar.setFixedHeight(8)
        self.dl_bar.setRange(0, 100)
        self.dl_bar.setValue(0)
        self.dl_bar.setTextVisible(False)
        self.dl_bar.setStyleSheet("""
            QProgressBar {
                background-color: #DBEAFE;
                border-radius: 4px;
                border: none;
            }
            QProgressBar::chunk {
                background-color: #2563EB;
                border-radius: 4px;
            }
        """)
        dl_layout.addWidget(self.dl_bar, stretch=2)

        self.btn_cancel_dl = QPushButton("取消")
        self.btn_cancel_dl.setFixedHeight(26)
        self.btn_cancel_dl.clicked.connect(self._cancel_download)
        dl_layout.addWidget(self.btn_cancel_dl)

        self.download_progress_card.hide()
        main_layout.addWidget(self.download_progress_card)

        # -----------------------------
        # 5.1 下载完成与交互反馈横幅 (完全无弹窗体验)
        # -----------------------------
        self.download_result_banner = DownloadNotificationBanner(self)
        main_layout.addWidget(self.download_result_banner)

        # -----------------------------
        # 6. 素材卡片流式画廊网格展示区
        # -----------------------------
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("""
            QScrollArea {
                border: 1px solid #E2E8F0;
                border-radius: 12px;
                background-color: #F8FAFC;
            }
        """)

        self.grid_container = QWidget()
        self.grid_container.setStyleSheet("background-color: #F8FAFC;")
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setContentsMargins(16, 16, 16, 16)
        self.grid_layout.setSpacing(14)
        self.grid_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)

        self.scroll_area.setWidget(self.grid_container)
        main_layout.addWidget(self.scroll_area, stretch=1)

    def _btn_secondary_style(self):
        return """
            QPushButton {
                background-color: #F8FAFC;
                color: #334155;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                padding: 0 14px;
                font-size: 13px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #F1F5F9;
                color: #0F172A;
                border-color: #94A3B8;
            }
        """

    def _filter_btn_style(self):
        return """
            QPushButton {
                background-color: #FFFFFF;
                color: #475569;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 4px 10px;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:checked {
                background-color: #007AFF;
                color: #FFFFFF;
                border-color: #007AFF;
                font-weight: 600;
            }
            QPushButton:hover:!checked {
                background-color: #F1F5F9;
                color: #0F172A;
            }
        """

    def setup_signals(self):
        # 1688 引擎信号
        self.engine_1688.sig_status.connect(self.lbl_status.setText)
        self.engine_1688.sig_loading.connect(self._on_engine_loading)
        self.engine_1688.sig_success.connect(self._on_extract_success)
        self.engine_1688.sig_error.connect(self._on_extract_error)
        self.engine_1688.sig_need_interaction.connect(self._on_need_interaction)
        self.engine_1688.sig_cookie_synced.connect(self._on_cookie_synced)

        # 抖音引擎信号
        self.engine_douyin.sig_status.connect(self.lbl_status.setText)
        self.engine_douyin.sig_loading.connect(self._on_engine_loading)
        self.engine_douyin.sig_success.connect(self._on_extract_success)
        self.engine_douyin.sig_error.connect(self._on_extract_error)
        self.engine_douyin.sig_need_interaction.connect(self._on_need_interaction)

    def _on_paste_clicked(self):
        clipboard = QApplication.clipboard()
        text = clipboard.text().strip()
        if text:
            self.input_url.setText(text)
            self.start_extract()

    def sync_chrome_cookie(self):
        self.lbl_status.setText("正在读取本机 Chrome / Edge 安全凭据...")
        count = self.engine_1688.sync_cookies_from_chrome()
        if count > 0:
            self.download_result_banner.show_notification(
                title=f"成功从本机 Chrome 导入 {count} 个 1688 安全 Cookie 凭证！",
                path="",
                is_file=False,
                is_success=True,
                auto_hide_seconds=8
            )
        else:
            self.download_result_banner.show_notification(
                title="未能自动读取到本机 1688 Cookie，可点击上方「验证/登录窗口」扫码登录",
                path="",
                is_file=False,
                is_success=False,
                auto_hide_seconds=10
            )

    def _on_cookie_synced(self, count: int):
        self.lbl_cookie_badge.setText(f"🔑 1688 Cookie: 已注入 ({count})")
        self.lbl_cookie_badge.setStyleSheet("""
            QLabel {
                background-color: #DCFCE7;
                color: #166534;
                font-size: 11px;
                font-weight: 600;
                padding: 4px 10px;
                border-radius: 4px;
            }
        """)

    def open_interactive_dialog(self):
        raw = self.input_url.text().strip()
        platform, canonical = detect_and_parse_ecommerce_url(raw)
        engine = self.engine_douyin if platform == "douyin" else self.engine_1688
        dlg = InteractiveBrowserDialog(
            profile=engine.profile,
            canonical_url=canonical,
            default_action="login",
            on_completed_callback=self.start_extract,
            parent=self
        )
        dlg.exec()

    def _on_need_interaction(self, itype: str, msg: str):
        self.progress_bar.hide()
        engine = self.active_engine or self.engine_1688
        default_action = "captcha" if itype == "captcha" else "login"
        raw = self.input_url.text().strip()
        _, canonical = detect_and_parse_ecommerce_url(raw)
        dlg = InteractiveBrowserDialog(
            profile=engine.profile,
            canonical_url=canonical,
            default_action=default_action,
            on_completed_callback=self.start_extract,
            parent=self
        )
        dlg.exec()

    def start_extract(self):
        raw = self.input_url.text().strip()
        if not raw:
            self.download_result_banner.show_notification(
                title="请在上方输入框中粘贴 1688 或 抖音商品网址",
                path="",
                is_file=False,
                is_success=False,
                auto_hide_seconds=6
            )
            return

        self.download_result_banner.hide()
        platform, canonical_url = detect_and_parse_ecommerce_url(raw)
        self.current_platform = platform

        self.btn_extract.setEnabled(False)
        self.progress_bar.show()

        if platform == "douyin":
            self.active_engine = self.engine_douyin
            self.lbl_cookie_badge.setText("🎵 抖音电商")
            self.lbl_cookie_badge.setStyleSheet("""
                QLabel {
                    background-color: #EDE9FE;
                    color: #5B21B6;
                    font-size: 11px;
                    font-weight: 600;
                    padding: 4px 10px;
                    border-radius: 4px;
                }
            """)
            self.engine_douyin.start_fetch(canonical_url)
        else:
            self.active_engine = self.engine_1688
            self.lbl_cookie_badge.setText("🛍️ 1688")
            self.lbl_cookie_badge.setStyleSheet("""
                QLabel {
                    background-color: #FFF7ED;
                    color: #C2410C;
                    font-size: 11px;
                    font-weight: 600;
                    padding: 4px 10px;
                    border-radius: 4px;
                }
            """)
            self.engine_1688.start_fetch(canonical_url)

    def _on_engine_loading(self, loading: bool):
        self.btn_extract.setEnabled(not loading)
        if loading:
            self.progress_bar.show()
        else:
            self.progress_bar.hide()

    def _on_extract_error(self, err_msg: str):
        self.progress_bar.hide()
        self.btn_extract.setEnabled(True)
        self.lbl_status.setText(f"❌ 提取失败: {err_msg}")
        self.download_result_banner.show_notification(
            title=f"素材提取受阻: {err_msg}",
            path="",
            is_file=False,
            is_success=False,
            auto_hide_seconds=12
        )

    def _on_extract_success(self, data: Dict):
        self.current_data = data
        self.progress_bar.hide()
        self.btn_extract.setEnabled(True)

        # 填充商品概要
        platform = data.get("platform", "1688")
        title = data.get("title", "未命名商品")
        self.lbl_prod_title.setText(title)
        offer_id = data.get("offerId", "")
        company = data.get("companyName", "商家")
        price = data.get("priceRange", "")
        self.lbl_price.setText(price if price else "平台热销")

        if platform == "douyin":
            self.lbl_meta_info.setText(f"平台: <b>🎵 抖音电商</b> | 商品 ID: <b>{offer_id}</b> | 店铺/商家: <b>{company}</b>")
        else:
            self.lbl_meta_info.setText(f"平台: <b>🛍️ 1688</b> | Offer ID: <b>{offer_id}</b> | 供应商/厂家: <b>{company}</b>")

        # 组装素材列表
        self.all_items = []
        item_counter = 1

        # 1. 视频
        video = data.get("video")
        if video and video.get("url"):
            self.all_items.append({
                "id": f"item_{item_counter}",
                "category": "video",
                "title": f"主图视频_{video.get('title', '视频')}",
                "url": video.get("url"),
                "cover": video.get("cover"),
                "thumb_url": video.get("cover")
            })
            item_counter += 1

        # 2. 主图
        main_images = data.get("mainImages", [])
        for idx, u in enumerate(main_images):
            self.all_items.append({
                "id": f"item_{item_counter}",
                "category": "main",
                "title": f"主图_{idx+1:02d}",
                "url": u,
                "thumb_url": u
            })
            item_counter += 1

        # 3. 规格 SKU 图
        sku_images = data.get("skuImages", [])
        for idx, sku in enumerate(sku_images):
            s_name = sku.get("name", f"规格_{idx+1}")
            self.all_items.append({
                "id": f"item_{item_counter}",
                "category": "sku",
                "title": f"规格_{s_name}",
                "url": sku.get("url"),
                "thumb_url": sku.get("url")
            })
            item_counter += 1

        # 4. 详情描述图
        detail_images = data.get("detailImages", [])
        for idx, u in enumerate(detail_images):
            self.all_items.append({
                "id": f"item_{item_counter}",
                "category": "detail",
                "title": f"详情_{idx+1:02d}",
                "url": u,
                "thumb_url": u
            })
            item_counter += 1

        # 更新标签徽章统计
        self.lbl_badge_main.setText(f"主图: {len(main_images)}")
        self.lbl_badge_sku.setText(f"规格SKU: {len(sku_images)}")
        self.lbl_badge_detail.setText(f"详情图: {len(detail_images)}")
        self.lbl_badge_video.setText(f"视频: {1 if video else 0}")

        self.btn_filter_all.setText(f"全部 ({len(self.all_items)})")
        self.btn_filter_main.setText(f"主图 ({len(main_images)})")
        self.btn_filter_sku.setText(f"规格图 ({len(sku_images)})")
        self.btn_filter_detail.setText(f"详情图 ({len(detail_images)})")
        self.btn_filter_video.setText(f"视频 ({1 if video else 0})")

        self.product_card.show()
        self.action_bar.show()

        # 渲染卡片
        self._apply_filter_and_render()
        self._update_selected_count()

    def _set_active_filter(self, filter_name: str):
        self.active_filter = filter_name
        self.btn_filter_all.setChecked(filter_name == "all")
        self.btn_filter_main.setChecked(filter_name == "main")
        self.btn_filter_sku.setChecked(filter_name == "sku")
        self.btn_filter_detail.setChecked(filter_name == "detail")
        self.btn_filter_video.setChecked(filter_name == "video")
        self._apply_filter_and_render()

    def _apply_filter_and_render(self):
        # 清除现有卡片
        for card in self.cards:
            self.grid_layout.removeWidget(card)
            card.deleteLater()
        self.cards.clear()

        # 筛选
        if self.active_filter == "all":
            items_to_show = self.all_items
        else:
            items_to_show = [i for i in self.all_items if i.get("category") == self.active_filter]

        # 网格布局 (每行 5 列)
        cols = 5
        for idx, item in enumerate(items_to_show):
            row = idx // cols
            col = idx % cols
            card = MediaCard1688(item, parent=self.grid_container)
            card.sig_selection_changed.connect(self._on_card_selection_changed)
            card.sig_preview_requested.connect(self._on_card_preview)
            card.sig_single_download.connect(self._on_card_single_download)
            self.grid_layout.addWidget(card, row, col)
            self.cards.append(card)

    def _on_select_all_toggled(self, checked: bool):
        for card in self.cards:
            card.set_checked(checked)
        self._update_selected_count()

    def _on_card_selection_changed(self, item_id: str, checked: bool):
        self._update_selected_count()

    def _update_selected_count(self):
        selected_count = sum(1 for c in self.cards if c.is_selected)
        total_count = len(self.cards)
        self.btn_download_selected.setText(f"📥 批量下载选中项 ({selected_count})")
        self.btn_download_selected.setEnabled(selected_count > 0)

        # 联动全选框状态
        self.chk_select_all.blockSignals(True)
        self.chk_select_all.setChecked(selected_count == total_count and total_count > 0)
        self.chk_select_all.blockSignals(False)

    def _on_card_preview(self, item: Dict):
        """点击预览大图或播放视频"""
        cat = item.get("category")
        title = item.get("title", "预览")
        url = item.get("url", "")

        if cat == "video":
            # 打开视频外链播放或用系统播放器
            QDesktopServices.openUrl(QUrl(url))
            return

        # 查找卡片中的内存缓存数据
        target_card = next((c for c in self.cards if c.item.get("id") == item.get("id")), None)
        raw_bytes = target_card.raw_bytes if target_card else None

        if raw_bytes:
            mime = "image/png" if ".png" in url.lower() else "image/jpeg"
            dlg = ImagePreviewDialog(title, raw_bytes, mime, item.get("id", "0"), self)
            dlg.exec()
        else:
            self.lbl_status.setText("正在拉取高清大图...")
            def on_loaded(item_id, pixmap, r_bytes):
                if target_card:
                    target_card.raw_bytes = r_bytes
                mime = "image/png" if ".png" in url.lower() else "image/jpeg"
                dlg = ImagePreviewDialog(title, r_bytes, mime, item_id, self)
                dlg.exec()
            
            clean_url = clean_alibaba_media_url(url)
            worker = AsyncImageLoaderWorker(item.get("id", "0"), clean_url)
            worker.signals.sig_loaded.connect(on_loaded)
            QThreadPool.globalInstance().start(worker)

    def _on_card_single_download(self, item: Dict):
        """单张素材下载"""
        title = sanitize_filename(item.get("title", "1688_item"))
        ext = ".mp4" if item.get("category") == "video" else ".jpg"
        default_name = f"{title}{ext}"

        file_path, _ = QFileDialog.getSaveFileName(self, "保存素材文件", os.path.expanduser(f"~/Downloads/{default_name}"))
        if not file_path:
            return

        target_card = next((c for c in self.cards if c.item.get("id") == item.get("id")), None)
        raw_bytes = target_card.raw_bytes if target_card else None

        if raw_bytes and item.get("category") != "video":
            with open(file_path, "wb") as f:
                f.write(raw_bytes)
            self.lbl_status.setText(f"✅ 素材已保存至: {file_path}")
            self.download_result_banner.show_notification(
                title=f"素材已成功保存: {os.path.basename(file_path)}",
                path=file_path,
                is_file=True,
                is_success=True,
                auto_hide_seconds=12
            )
        else:
            self.lbl_status.setText("正在下载素材...")
            url = clean_alibaba_media_url(item.get("url", ""))
            try:
                headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"}
                if "alicdn.com" in url:
                    headers["Referer"] = "https://detail.1688.com/"
                elif any(d in url for d in ["ecombdimg.com", "byteimg.com", "zjcdn.com", "bytednsdoc.com"]):
                    headers["Referer"] = "https://haohuo.jinritemai.com/"
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=20) as resp:
                    data = resp.read()
                with open(file_path, "wb") as f:
                    f.write(data)
                self.lbl_status.setText(f"✅ 素材已保存至: {file_path}")
                self.download_result_banner.show_notification(
                    title=f"素材已成功保存: {os.path.basename(file_path)}",
                    path=file_path,
                    is_file=True,
                    is_success=True,
                    auto_hide_seconds=12
                )
            except Exception as e:
                self.download_result_banner.show_notification(
                    title=f"下载失败: {e}",
                    path="",
                    is_file=False,
                    is_success=False,
                    auto_hide_seconds=8
                )

    def start_batch_download(self):
        """批量下载选中的素材"""
        selected_items = [c.item for c in self.cards if c.is_selected]
        if not selected_items:
            self.download_result_banner.show_notification(
                title="请至少勾选一项要下载的图片或视频素材",
                path="",
                is_file=False,
                is_success=False,
                auto_hide_seconds=6
            )
            return

        # 隐藏之前的通知
        self.download_result_banner.hide()

        # 默认保存目录
        plat_prefix = "抖音" if self.current_platform == "douyin" else "1688"
        prod_title = sanitize_filename(self.current_data.get("title", f"{plat_prefix}素材")) if self.current_data else f"{plat_prefix}素材"
        offer_id = self.current_data.get("offerId", "") if self.current_data else ""
        default_dir_name = f"{plat_prefix}_{prod_title[:20]}_{offer_id}" if offer_id else f"{plat_prefix}_{prod_title[:20]}"
        default_folder = os.path.expanduser(f"~/Downloads/{default_dir_name}")

        dest_dir = QFileDialog.getExistingDirectory(self, "选择素材保存目录", os.path.dirname(default_folder))
        if not dest_dir:
            return

        final_dest = os.path.join(dest_dir, default_dir_name)
        os.makedirs(final_dest, exist_ok=True)
        self.last_download_folder = final_dest

        # 显示下载面板
        self.download_progress_card.show()
        self.dl_bar.setValue(0)
        self.btn_download_selected.setEnabled(False)
        self.lbl_dl_status.setText(f"准备下载 {len(selected_items)} 项素材...")

        organize = self.chk_organize.isChecked()
        worker = BatchDownloadWorker(selected_items, final_dest, organize_subfolders=organize)
        self.active_download_worker = worker
        worker.signals.sig_progress.connect(self._on_download_progress)
        worker.signals.sig_all_finished.connect(self._on_download_finished)
        QThreadPool.globalInstance().start(worker)

    def _on_download_progress(self, current: int, total: int, filename: str):
        pct = int(current / total * 100) if total > 0 else 0
        self.dl_bar.setValue(pct)
        self.lbl_dl_status.setText(f"📥 正在高速下载 ({current}/{total}): {filename}...")

    def _on_download_finished(self, success_cnt: int, fail_cnt: int, folder: str):
        self.download_progress_card.hide()
        self.btn_download_selected.setEnabled(True)
        self.btn_open_folder.show()
        self.lbl_status.setText(f"🎉 批量下载完成！成功: {success_cnt} 项，失败: {fail_cnt} 项。")

        title = f"已成功下载 {success_cnt} 项素材！"
        if fail_cnt > 0:
            title += f"（{fail_cnt} 项下载失败）"

        self.download_result_banner.show_notification(
            title=title,
            path=folder,
            is_file=False,
            is_success=(fail_cnt == 0),
            auto_hide_seconds=20
        )

    def _open_download_folder(self):
        if self.last_download_folder and os.path.exists(self.last_download_folder):
            try:
                subprocess.Popen(["open", self.last_download_folder])
            except Exception:
                QDesktopServices.openUrl(QUrl.fromLocalFile(self.last_download_folder))

    def _cancel_download(self):
        if self.active_download_worker:
            self.active_download_worker.cancel()
            self.download_progress_card.hide()
            self.btn_download_selected.setEnabled(True)
            self.lbl_status.setText("已取消素材批量下载。")
