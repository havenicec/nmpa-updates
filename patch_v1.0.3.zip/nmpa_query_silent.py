#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
====================================================================
国家药监局化妆品备案信息 - 无感后台静默自动化查询客户端
====================================================================
功能特点：
1. 纯后台静默运行（无任何弹窗、无界面干扰）
2. 自动处理瑞数6动态鉴权与请求签名
3. 本地 ddddocr 自动识别验证码，内置错误自动刷新与重试机制
4. 自动提取完整备案信息、全配方成分及包装图纸附件（平面图/立体图/说明书）下载链接
"""

import sys
import os
import json
import base64
import time
import argparse
import ddddocr

# 基础接口地址
BASE_URL = "https://hzpba.nmpa.gov.cn/HZPBZCX/PTHZPBA-SERVER"
PREVIEW_URL = f"{BASE_URL}/nmpafile/gsxxFilePreview?attachmentId="


class NmpaSilentClient:
    def __init__(self):
        self.ocr = ddddocr.DdddOcr(show_ad=False)

    def detect_gb(self, record_no: str) -> str:
        """判断国别: G=国产, J=进口"""
        if "进字" in record_no or "J" in record_no.upper():
            return "J"
        return "G"

    def execute_in_page(self, page, script_str, arg=None):
        """在页面上下文中执行脚本，借助天然环境通过瑞数鉴权"""
        if arg is not None:
            return page.evaluate(script_str, arg)
        return page.evaluate(script_str)

    def query(self, page, record_no: str, max_retries: int = 5) -> dict:
        gb = self.detect_gb(record_no)
        print(f"[*] 目标备案编号: {record_no} (国别类型: {'国产[G]' if gb == 'G' else '进口[J]'})")

        # -----------------------------
        # 阶段一：列表检索与获取 ID
        # -----------------------------
        item = None
        for attempt in range(1, max_retries + 1):
            # 1.1 获取验证码与 Token
            cap_data = page.evaluate("""async () => {
                const res = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/kaptcha');
                return await res.json();
            }""")
            token1 = cap_data.get("captchaKey")
            img_b64 = cap_data.get("base64Img", "").split(",")[-1]
            code1 = self.ocr.classification(base64.b64decode(img_b64)).strip()

            # 1.2 提交列表查询
            list_res = page.evaluate("""async (args) => {
                const res = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/query', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json;charset=utf-8'},
                    body: JSON.stringify({
                        prodName: '',
                        recordNo: args.recordNo,
                        entName: '',
                        gb: args.gb,
                        token: args.token,
                        dataCode: args.code
                    })
                });
                return await res.json();
            }""", {"recordNo": record_no, "gb": gb, "token": token1, "code": code1})

            if isinstance(list_res, dict) and "msg" in list_res:
                print(f"[-] 列表验证码校验未通过 ({list_res['msg']})，正在重试 ({attempt}/{max_retries})...")
                time.sleep(0.5)
                continue

            if isinstance(list_res, list):
                if len(list_res) == 0:
                    return {"status": "error", "message": f"未找到备案编号为 '{record_no}' 的产品记录"}
                item = list_res[0]
                break

        if not item:
            return {"status": "error", "message": "列表查询超出最大重试次数"}

        prod_id = item["id"]
        print(f"[+] 成功命中产品: 《{item.get('prodName')}》 (系统ID: {prod_id})")

        # -----------------------------
        # 阶段二：获取详情资料与图纸附件
        # -----------------------------
        detail = None
        for attempt in range(1, max_retries + 1):
            cap_data2 = page.evaluate("""async () => {
                const res = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/kaptcha');
                return await res.json();
            }""")
            token2 = cap_data2.get("captchaKey")
            img_b64_2 = cap_data2.get("base64Img", "").split(",")[-1]
            code2 = self.ocr.classification(base64.b64decode(img_b64_2)).strip()

            detail_res = page.evaluate("""async (args) => {
                const res = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/getProdInfo', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json;charset=utf-8'},
                    body: JSON.stringify({
                        prodId: args.prodId,
                        gb: args.gb,
                        token: args.token,
                        dataCode: args.code
                    })
                });
                return await res.json();
            }""", {"prodId": prod_id, "gb": gb, "token": token2, "code": code2})

            if isinstance(detail_res, dict) and (detail_res.get("msg") == "1" or "验证码" in str(detail_res.get("msg", ""))):
                print(f"[-] 详情验证码校验未通过，正在重试 ({attempt}/{max_retries})...")
                time.sleep(0.5)
                continue

            detail = detail_res
            break

        if not detail:
            return {"status": "error", "message": "详情获取超出最大重试次数"}

        # 获取法定功效宣称与评价依据
        gx_res = page.evaluate("""async (args) => {
            try {
                const res = await fetch('/HZPBZCX/PTHZPBA-SERVER/gxxc/getGxxcInfo', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json;charset=utf-8'},
                    body: JSON.stringify({ prodId: args.prodId, gb: args.gb })
                });
                return await res.json();
            } catch(e) {
                return null;
            }
        }""", {"prodId": prod_id, "gb": gb})
        from nmpa_desktop_app import parse_gxxc_data
        eff_info = parse_gxxc_data(gx_res)

        # -----------------------------
        # 阶段三：规整资料与提取附件链接
        # -----------------------------
        file_ids = detail.get("fileIdList") or {}
        dzbq_ids = detail.get("dzbq") or {}

        def format_urls(ids):
            if not ids or not isinstance(ids, list):
                return []
            return [{"id": x, "url": f"{PREVIEW_URL}{x}"} for x in ids if x]

        archive = {
            "status": "success",
            "basic_info": {
                "record_no": record_no,
                "product_name": detail.get("prodName"),
                "product_name_en": detail.get("prodNameEn") or "",
                "is_children_cosmetics": detail.get("sfetcp") == "是",
                "record_date": detail.get("recordDate"),
                "shelf_life": detail.get("syqx"),
                "status": "有效/正常在售" if not detail.get("offdate") else f"注销({detail.get('offdate')})"
            },
            "enterprise_info": {
                "registrant": detail.get("entName"),
                "registrant_address": detail.get("entAddr"),
                "manufacturer": detail.get("productEnt"),
                "domestic_responsible_person": detail.get("jnzrrName") or "",
            },
            "efficacy_info": eff_info,
            "formula_and_usage": {
                "claims": eff_info.get("claims"),
                "conclusion": eff_info.get("conclusion"),
                "components": detail.get("component"),
                "usage_method": detail.get("syff"),
                "caution": detail.get("aqjsyy"),
                "storage_condition": detail.get("zctj"),
                "history_timeline": detail.get("history")
            },
            "drawing_attachments": {
                "packaging_plane_views": format_urls(file_ids.get("pmt")),      # 包装平面图
                "stereo_product_views": format_urls(file_ids.get("ltt")),       # 产品立体图
                "leaflet_manuals": format_urls(file_ids.get("sms")),            # 纸质说明书
                "electronic_labels": format_urls(dzbq_ids.get("sms"))           # 电子标签
            }
        }
        return archive


def main():
    parser = argparse.ArgumentParser(description="国家药监局化妆品备案信息 - 无感后台静默自动化查询工具")
    parser.add_argument("record_no", nargs="?", default="浙G妆网备字2022023901", help="化妆品备案编号 (如: 浙G妆网备字2022023901)")
    parser.add_argument("--output", "-o", help="保存结果为 JSON 文件路径")
    args = parser.parse_args()

    client = NmpaSilentClient()

    # 尝试连接当前运行中的静默后台会话
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("[!] 错误: 未检测到 playwright 库，请先执行: pip install playwright")
        sys.exit(1)

    # 优先检测本地已存在的 Chrome 实例
    port_file = os.path.expanduser("~/Library/Application Support/Google/Chrome/DevToolsActivePort")
    target_page = None

    with sync_playwright() as p:
        # 尝试连接现有 Chrome 实例
        if os.path.exists(port_file):
            try:
                with open(port_file) as f:
                    lines = [l.strip() for l in f.readlines() if l.strip()]
                    endpoint = f"ws://127.0.0.1:{lines[0]}{lines[1]}"
                browser = p.chromium.connect_over_cdp(endpoint, timeout=3000)
                for ctx in browser.contexts:
                    for pg in ctx.pages:
                        if "gccx" in pg.url:
                            target_page = pg
                            break
                    if target_page:
                        break
            except Exception:
                target_page = None

        # 若未检测到常驻会话，则自动在后台启动一个无头无感实例
        browser_instance = None
        if not target_page:
            browser_instance = p.chromium.launch(
                channel="chrome",
                headless=True,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-sandbox",
                    "--disable-gpu"
                ]
            )
            ctx = browser_instance.new_context(
                user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
            )
            target_page = ctx.new_page()
            target_page.goto("https://hzpba.nmpa.gov.cn/gccx/", wait_until="domcontentloaded", timeout=20000)
            time.sleep(1)

        # 执行查询
        result = client.query(target_page, args.record_no)

        if browser_instance:
            browser_instance.close()

    # 结果输出
    print("\n" + "=" * 60)
    print("                     查询结果简报")
    print("=" * 60)
    if result.get("status") == "success":
        b = result["basic_info"]
        e = result["enterprise_info"]
        a = result["drawing_attachments"]
        print(f"【产品名称】 {b['product_name']}")
        print(f"【备案编号】 {b['record_no']}")
        print(f"【备案企业】 {e['registrant']}")
        print(f"【备案日期】 {b['record_date']}  |  状态: {b['status']}")
        print("\n【包装与图纸附件清单】:")
        print(f"  * 包装平面图: {len(a['packaging_plane_views'])} 张")
        for x in a['packaging_plane_views']:
            print(f"    - ID: {x['id']}  链接: {x['url']}")
        print(f"  * 产品立体图: {len(a['stereo_product_views'])} 张")
        for x in a['stereo_product_views']:
            print(f"    - ID: {x['id']}  链接: {x['url']}")
        print(f"  * 纸质说明书: {len(a['leaflet_manuals'])} 张")
        for x in a['leaflet_manuals']:
            print(f"    - ID: {x['id']}  链接: {x['url']}")
        print("=" * 60)

        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print(f"[+] 完整档案已保存至: {args.output}")
    else:
        print(f"[-] 查询失败: {result.get('message')}")


if __name__ == "__main__":
    main()
