#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
====================================================================
化妆品备案档案速查助手 - 客户端无缝自动同步与热更新模块
NMPA Cosmetics Viewer Auto-Updater & Hot-Patch Engine
====================================================================
特点：
1. 双轨更新架构：
   - ⚡ 增量热更新 (Hot-Patch)：脚本、规则、接口变动仅需下载 20~80KB 增量包，0.5秒即时生效。
   - 📦 全量版本更新 (Full-DMG)：涉及底层核心二进制变动时，下载独立 DMG 并引导一键升级。
2. 零编译拦截 (HotPatchFinder)：
   - 运行时优先从 ~/.nmpa_cosmetics_viewer/patches 加载最新代码，彻底规避 Gatekeeper 与重装流程。
3. 现代化 macOS 原生体验：
   - 支持后台静默检测、更新日志渲染、下载进度监控、重启即生效。
"""

import os
import sys
import json
import time
import zipfile
import urllib.request
import importlib.util

from PySide6.QtCore import Qt, QThread, Signal, QUrl
from PySide6.QtGui import QFont, QDesktopServices, QColor
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QProgressBar, QTextEdit, QFrame, QMessageBox, QWidget
)

# 基础版本配置
APP_VERSION = "1.0.0"
CONFIG_FILE = os.path.expanduser("~/.nmpa_proxy_config.json")
DATA_DIR = os.path.expanduser("~/.nmpa_cosmetics_viewer")
PATCH_DIR = os.path.join(DATA_DIR, "patches")
VERSION_FILE = os.path.join(DATA_DIR, "installed_version.txt")

# 默认更新地址 (用户可在设置中自定义，也可默认指向 Gitee / GitHub / 自有服务器)
DEFAULT_UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/dengrui/nmpa-cosmetics-viewer/main/update_manifest.json"


# ====================================================================
# 1. 运行时优先加载器 (HotPatchFinder)
# ====================================================================
class HotPatchFinder:
    """在 Python 导入链最顶层拦截并优先加载补丁目录下的新版本 Python 脚本"""
    def __init__(self, patch_directory: str):
        self.patch_directory = patch_directory

    def find_spec(self, fullname, path=None, target=None):
        rel_path = fullname.replace('.', os.sep) + '.py'
        candidate = os.path.join(self.patch_directory, rel_path)
        if os.path.isfile(candidate):
            return importlib.util.spec_from_file_location(fullname, candidate)
        return None


def init_hot_patch_system():
    """在应用启动时初始化热补丁系统"""
    os.makedirs(PATCH_DIR, exist_ok=True)
    if os.path.exists(PATCH_DIR):
        # 插入到 sys.meta_path 最前端，保证优先级高于 PyInstaller 内部冻结模块
        for finder in sys.meta_path:
            if isinstance(finder, HotPatchFinder):
                return
        sys.meta_path.insert(0, HotPatchFinder(PATCH_DIR))


def get_current_app_version() -> str:
    """获取当前生效的版本号（若存在已安装的热补丁则返回热补丁版本号）"""
    if os.path.exists(VERSION_FILE):
        try:
            with open(VERSION_FILE, "r", encoding="utf-8") as f:
                v = f.read().strip()
                if v:
                    return v
        except Exception:
            pass
    return APP_VERSION


def parse_version_tuple(v_str: str):
    """解析语义化版本号，如 '1.0.1' -> (1, 0, 1)"""
    parts = []
    for x in v_str.replace("v", "").replace("V", "").split("."):
        try:
            parts.append(int(x))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def is_version_newer(remote_v: str, local_v: str) -> bool:
    """比较远端版本与本地版本"""
    return parse_version_tuple(remote_v) > parse_version_tuple(local_v)


# ====================================================================
# 2. 异步检查与下载线程
# ====================================================================
class CheckUpdateThread(QThread):
    sig_update_available = Signal(dict)
    sig_already_latest = Signal(str)
    sig_check_error = Signal(str)

    def __init__(self, manifest_url: str):
        super().__init__()
        self.manifest_url = manifest_url

    def run(self):
        try:
            req = urllib.request.Request(
                self.manifest_url,
                headers={"User-Agent": f"NMPA-Cosmetics-Viewer/{get_current_app_version()}"}
            )
            with urllib.request.urlopen(req, timeout=6) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            remote_ver = data.get("version", "")
            current_ver = get_current_app_version()

            if is_version_newer(remote_ver, current_ver):
                self.sig_update_available.emit(data)
            else:
                self.sig_already_latest.emit(current_ver)
        except Exception as e:
            self.sig_check_error.emit(str(e))


class DownloadUpdateThread(QThread):
    sig_progress = Signal(int, str)  # percent, speed_text
    sig_success = Signal(str, str)   # saved_path, update_type
    sig_error = Signal(str)

    def __init__(self, download_url: str, update_type: str, file_name: str):
        super().__init__()
        self.download_url = download_url
        self.update_type = update_type
        self.file_name = file_name
        self._is_cancelled = False

    def cancel(self):
        self._is_cancelled = True

    def run(self):
        try:
            os.makedirs(DATA_DIR, exist_ok=True)
            target_path = os.path.join(DATA_DIR, self.file_name)

            req = urllib.request.Request(
                self.download_url,
                headers={"User-Agent": "Mozilla/5.0 NMPA-Viewer-Updater"}
            )
            with urllib.request.urlopen(req, timeout=15) as response:
                total_size = int(response.headers.get("Content-Length", 0))
                downloaded = 0
                chunk_size = 32 * 1024
                start_time = time.time()

                with open(target_path, "wb") as f:
                    while True:
                        if self._is_cancelled:
                            return
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)

                        duration = max(time.time() - start_time, 0.001)
                        speed = downloaded / duration / 1024  # KB/s
                        speed_str = f"{speed:.1f} KB/s" if speed < 1024 else f"{speed/1024:.2f} MB/s"

                        percent = int((downloaded / total_size) * 100) if total_size > 0 else 50
                        self.sig_progress.emit(percent, speed_str)

            self.sig_success.emit(target_path, self.update_type)
        except Exception as e:
            self.sig_error.emit(f"下载失败: {str(e)}")


# ====================================================================
# 3. 现代化 macOS 风格更新对话框
# ====================================================================
class UpdateDialog(QDialog):
    def __init__(self, update_info: dict, parent=None):
        super().__init__(parent)
        self.update_info = update_info
        self.download_thread = None
        self.downloaded_file = None
        self.is_ready_restart = False

        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("发现新版本更新")
        self.setFixedSize(520, 480)
        self.setStyleSheet("""
            QDialog {
                background-color: #F8FAFC;
            }
            QWidget {
                font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "PingFang SC", sans-serif;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        # 头部：版本徽标与标题
        header_card = QFrame()
        header_card.setStyleSheet("""
            QFrame {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 12px;
                padding: 16px;
            }
        """)
        h_layout = QHBoxLayout(header_card)
        h_layout.setContentsMargins(12, 8, 12, 8)

        icon_lbl = QLabel("🚀")
        icon_lbl.setStyleSheet("font-size: 38px;")
        h_layout.addWidget(icon_lbl)

        info_v = QVBoxLayout()
        remote_ver = self.update_info.get("version", "最新版")
        current_ver = get_current_app_version()
        up_type = self.update_info.get("type", "patch")

        title_lbl = QLabel(f"发现新版本 v{remote_ver}")
        title_lbl.setStyleSheet("font-size: 17px; font-weight: 700; color: #0F172A;")
        
        type_desc = "⚡ 毫秒级增量热更新（无需重装，点击秒更新）" if up_type == "patch" else "📦 全量应用升级包（推荐下载并替换安装）"
        badge_lbl = QLabel(f"当前版本: v{current_ver}  ➔  最新: v{remote_ver}\n{type_desc}")
        badge_lbl.setStyleSheet("font-size: 12px; color: #475569; line-height: 1.4;")

        info_v.addWidget(title_lbl)
        info_v.addWidget(badge_lbl)
        h_layout.addLayout(info_v, stretch=1)
        layout.addWidget(header_card)

        # 中部：更新日志展示
        changelog_lbl = QLabel("📋 更新说明：")
        changelog_lbl.setStyleSheet("font-size: 13px; font-weight: 600; color: #334155;")
        layout.addWidget(changelog_lbl)

        self.txt_changelog = QTextEdit()
        self.txt_changelog.setReadOnly(True)
        changelog_items = self.update_info.get("changelog", ["常规性能优化与体验升级"])
        formatted_notes = ""
        for item in changelog_items:
            formatted_notes += f"• {item}\n"
        
        self.txt_changelog.setPlainText(formatted_notes.strip())
        self.txt_changelog.setStyleSheet("""
            QTextEdit {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                padding: 12px;
                color: #1E293B;
                font-size: 13px;
                line-height: 1.6;
            }
        """)
        layout.addWidget(self.txt_changelog, stretch=1)

        # 进度条与状态标签
        self.lbl_progress_status = QLabel("准备就绪")
        self.lbl_progress_status.setStyleSheet("font-size: 12px; color: #64748B;")
        self.lbl_progress_status.hide()
        layout.addWidget(self.lbl_progress_status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(8)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: none;
                background-color: #E2E8F0;
                border-radius: 4px;
            }
            QProgressBar::chunk {
                background-color: #2563EB;
                border-radius: 4px;
            }
        """)
        self.progress_bar.hide()
        layout.addWidget(self.progress_bar)

        # 底部按钮栏
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)

        self.btn_cancel = QPushButton("稍后提醒")
        self.btn_cancel.setStyleSheet("""
            QPushButton {
                background-color: #F1F5F9;
                color: #475569;
                font-weight: 500;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 8px 18px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #E2E8F0;
            }
        """)
        self.btn_cancel.clicked.connect(self.reject)

        self.btn_action = QPushButton("立即一键更新")
        self.btn_action.setStyleSheet("""
            QPushButton {
                background-color: #0284C7;
                color: #FFFFFF;
                font-weight: 600;
                border: none;
                border-radius: 6px;
                padding: 8px 24px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #0369A1;
            }
        """)
        self.btn_action.clicked.connect(self.on_action_clicked)

        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_cancel)
        btn_layout.addWidget(self.btn_action)
        layout.addLayout(btn_layout)

    def on_action_clicked(self):
        if self.is_ready_restart:
            # 执行重启或打开 DMG
            up_type = self.update_info.get("type", "patch")
            if up_type == "patch":
                self.restart_application()
            else:
                if self.downloaded_file and os.path.exists(self.downloaded_file):
                    QDesktopServices.openUrl(QUrl.fromLocalFile(self.downloaded_file))
                self.accept()
            return

        # 开始下载
        download_url = self.update_info.get("download_url", "")
        if not download_url:
            QMessageBox.warning(self, "错误", "未获取到有效的新版本下载链接。")
            return

        up_type = self.update_info.get("type", "patch")
        remote_ver = self.update_info.get("version", "latest")
        file_name = f"patch_v{remote_ver}.zip" if up_type == "patch" else f"NMPA_Viewer_v{remote_ver}.dmg"

        self.btn_action.setEnabled(False)
        self.btn_action.setText("正在下载...")
        self.btn_cancel.setText("取消")
        self.lbl_progress_status.show()
        self.progress_bar.show()
        self.progress_bar.setValue(0)

        self.download_thread = DownloadUpdateThread(download_url, up_type, file_name)
        self.download_thread.sig_progress.connect(self.on_download_progress)
        self.download_thread.sig_success.connect(self.on_download_success)
        self.download_thread.sig_error.connect(self.on_download_error)
        self.download_thread.start()

    def on_download_progress(self, percent: int, speed_str: str):
        self.progress_bar.setValue(percent)
        self.lbl_progress_status.setText(f"下载进度: {percent}% ({speed_str})")

    def on_download_success(self, file_path: str, update_type: str):
        self.downloaded_file = file_path
        self.progress_bar.setValue(100)

        if update_type == "patch":
            # 解压热补丁
            try:
                self.lbl_progress_status.setText("正在应用热补丁...")
                with zipfile.ZipFile(file_path, "r") as zf:
                    zf.extractall(PATCH_DIR)

                # 记录已更新版本
                remote_ver = self.update_info.get("version", "latest")
                with open(VERSION_FILE, "w", encoding="utf-8") as f:
                    f.write(remote_ver)

                self.lbl_progress_status.setText("✨ 热补丁已成功部署！点击下方按钮立即重启应用生效。")
                self.btn_action.setEnabled(True)
                self.btn_action.setText("立即重启生效")
                self.btn_action.setStyleSheet("""
                    QPushButton {
                        background-color: #16A34A;
                        color: #FFFFFF;
                        font-weight: 600;
                        border-radius: 6px;
                        padding: 8px 24px;
                    }
                    QPushButton:hover {
                        background-color: #15803D;
                    }
                """)
                self.is_ready_restart = True
            except Exception as e:
                QMessageBox.critical(self, "更新失败", f"解压部署补丁失败: {str(e)}")
                self.btn_action.setEnabled(True)
                self.btn_action.setText("重试")
        else:
            # DMG 全量包下载完成
            self.lbl_progress_status.setText("新版 DMG 安装包已下载完成！")
            self.btn_action.setEnabled(True)
            self.btn_action.setText("打开安装包")
            self.is_ready_restart = True

    def on_download_error(self, err_msg: str):
        self.lbl_progress_status.setText(f"❌ {err_msg}")
        self.btn_action.setEnabled(True)
        self.btn_action.setText("重新下载")

    def restart_application(self):
        """无缝重启应用程序"""
        import subprocess
        self.accept()
        # macOS 下通过 open 命令启动应用自身，然后当前进程退出
        if getattr(sys, "frozen", False):
            # 获取 .app 根路径
            mac_app_path = sys.executable
            # 如果是 .app/Contents/MacOS/xxx
            if ".app/Contents/MacOS" in mac_app_path:
                app_bundle = mac_app_path.split(".app/Contents/MacOS")[0] + ".app"
                subprocess.Popen(["open", "-n", app_bundle])
            else:
                subprocess.Popen([sys.executable] + sys.argv[1:])
        else:
            subprocess.Popen([sys.executable] + sys.argv)
        sys.exit(0)


# ====================================================================
# 4. 全局便捷调用接口
# ====================================================================
def get_configured_update_url() -> str:
    """读取用户配置的更新地址"""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                custom_url = data.get("update_server_url", "").strip()
                if custom_url:
                    return custom_url
        except Exception:
            pass
    return DEFAULT_UPDATE_MANIFEST_URL


def check_for_updates_interactive(parent_widget=None, silent_if_latest=False):
    """交互式检查更新函数（供界面按钮或启动时自动调用）"""
    url = get_configured_update_url()

    thread = CheckUpdateThread(url)

    def on_available(info):
        dlg = UpdateDialog(info, parent_widget)
        dlg.exec()

    def on_latest(cur_ver):
        if not silent_if_latest:
            QMessageBox.information(
                parent_widget,
                "检查更新",
                f"当前已经是最新版本 (v{cur_ver})，暂无可用更新。"
            )

    def on_error(err):
        if not silent_if_latest:
            QMessageBox.warning(
                parent_widget,
                "检查更新失败",
                f"未能连接至更新服务器：\n{err}\n\n请检查网络或在设置中确认更新源地址。"
            )

    thread.sig_update_available.connect(on_available)
    thread.sig_already_latest.connect(on_latest)
    thread.sig_check_error.connect(on_error)
    thread.start()

    # 保持线程引用防垃圾回收
    if parent_widget:
        parent_widget._update_check_thread = thread
    return thread
