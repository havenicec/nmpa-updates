#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
====================================================================
化妆品备案档案速查助手 (macOS 原生独立桌面端)
NMPA Cosmetic Archive Viewer
====================================================================
特点：
1. 彻底解耦用户主 Chrome：内置 QtWebEngine Chromium 独立引擎，无弹窗、不接管 CDP。
2. 自动化破盾：原生执行瑞数6 (Ruishu 6) 动态脚本鉴权。
3. 双模网络支持：支持豆芽动态代理智能接入与原生直连自动降级切换。
4. 全面归档：提取基本备案、分色号配方、说明书与立体图图纸、注销变更生命周期。
"""

import sys
import os
import re
import json
import base64
import time
import socket
import ssl
import io
import urllib.request

# 自动定位 macOS PyInstaller 打包环境中的 QtWebEngine 依赖路径
if sys.platform == "darwin":
    _mac_app_dir = os.path.dirname(os.path.abspath(sys.executable))
    _cand_procs = [
        os.path.join(_mac_app_dir, "..", "Frameworks", "PySide6", "Qt", "lib", "QtWebEngineCore.framework", "Versions", "Resources", "Helpers", "QtWebEngineProcess.app", "Contents", "MacOS", "QtWebEngineProcess"),
        os.path.join(_mac_app_dir, "..", "Frameworks", "PySide6", "Qt", "lib", "QtWebEngineCore.framework", "Helpers", "QtWebEngineProcess.app", "Contents", "MacOS", "QtWebEngineProcess"),
        os.path.join(_mac_app_dir, "QtWebEngineProcess"),
    ]
    for _p in _cand_procs:
        _p = os.path.abspath(_p)
        if os.path.exists(_p):
            os.environ.setdefault("QTWEBENGINEPROCESS_PATH", _p)
            break

    _cand_res = [
        os.path.join(_mac_app_dir, "..", "Frameworks", "PySide6", "Qt", "lib", "QtWebEngineCore.framework", "Versions", "Resources", "Resources"),
        os.path.join(_mac_app_dir, "..", "Frameworks", "PySide6", "Qt", "lib", "QtWebEngineCore.framework", "Resources"),
    ]
    for _r in _cand_res:
        _r = os.path.abspath(_r)
        if os.path.exists(_r):
            os.environ.setdefault("QTWEBENGINE_RESOURCES_PATH", _r)
            break

    _cand_locales = [
        os.path.join(_mac_app_dir, "..", "Frameworks", "PySide6", "Qt", "lib", "QtWebEngineCore.framework", "Versions", "Resources", "Resources", "qtwebengine_locales"),
        os.path.join(_mac_app_dir, "..", "Frameworks", "PySide6", "Qt", "lib", "QtWebEngineCore.framework", "Resources", "qtwebengine_locales"),
    ]
    for _l in _cand_locales:
        _l = os.path.abspath(_l)
        if os.path.exists(_l):
            os.environ.setdefault("QTWEBENGINE_LOCALES_PATH", _l)
            break

# 初始化客户端热补丁动态加载器与更新服务
from updater import init_hot_patch_system, get_current_app_version, check_for_updates_interactive
init_hot_patch_system()

import ddddocr
from PIL import Image
Image.MAX_IMAGE_PIXELS = None

from PySide6.QtCore import (
    Qt, QObject, Signal, QUrl, QTimer, QSize, QThread, QRunnable, QThreadPool, QRectF, QCoreApplication
)
from PySide6.QtGui import (
    QFont, QIcon, QPixmap, QImage, QDesktopServices, QColor, QPalette, QGuiApplication, QImageReader, QTextCursor,
    QPainter, QBrush
)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QLabel, QTabWidget, QTextEdit,
    QScrollArea, QFrame, QGridLayout, QFileDialog, QMessageBox,
    QProgressBar, QSplitter, QSizePolicy, QToolButton, QDialog,
    QRadioButton, QButtonGroup, QGroupBox, QComboBox, QCheckBox,
    QGraphicsView, QGraphicsScene, QGraphicsPixmapItem
)
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage, QWebEngineLoadingInfo
from PySide6.QtNetwork import QNetworkProxy
try:
    from PySide6.QtOpenGLWidgets import QOpenGLWidget
except ImportError:
    QOpenGLWidget = None

# 基础 URL 配置
BASE_URL = "https://hzpba.nmpa.gov.cn/HZPBZCX/PTHZPBA-SERVER"
PORTAL_URL = "https://hzpba.nmpa.gov.cn/gccx/"
DATASEARCH_PORTAL_URL = "https://datasearch.nmpa.gov.cn/datasearch/home-index.html#category=hzp"
PREVIEW_URL = f"{BASE_URL}/nmpafile/gsxxFilePreview?attachmentId="
DEFAULT_PROXY_API = "https://api.douyadaili.com/proxy/?service=GetUnl&authkey=0aS9KtiMWXXRTy8E2VG1&lifetime=0"
CONFIG_FILE = os.path.expanduser("~/.nmpa_proxy_config.json")
LOG_FILE = os.path.expanduser("~/.nmpa_desktop.log")

# 全局图纸与附件内存缓存系统 (多级异步缓存，彻底杜绝切换卡顿与主线程阻塞)
ATTACHMENT_CACHE = {}  # { str(file_id): {"mime": str, "raw": bytes} }
THUMBNAIL_CACHE = {}   # { str(file_id): (QPixmap, str, float) } -> (pixmap, kind, size_mb)
PREVIEW_CACHE = {}     # { (str(file_id), int(page_idx)): QPixmap }
IN_PROGRESS_FIDS = set()  # 当前正在后台加载的附件 ID 集合


class AttachmentHub(QObject):
    """全局附件事件总线：解耦网络拉取、后台图形计算与 UI 卡片刷新"""
    sig_attachment_loaded = Signal(str)  # fid: 二进制就绪
    sig_thumbnail_ready = Signal(str)    # fid: 缩略图 QPixmap 渲染入库就绪


attachment_hub = AttachmentHub()


class AppLogger(QObject):
    """全局统一诊断日志系统，支持控制台、文件持久化和 GUI 实时信号派发"""
    sig_log = Signal(str, str, str)  # (timestamp, level, message)
    _instance = None

    def __init__(self):
        super().__init__()
        self.log_file = LOG_FILE
        self._init_file()

    @classmethod
    def get(cls):
        if cls._instance is None:
            cls._instance = AppLogger()
        return cls._instance

    def _init_file(self):
        try:
            if os.path.exists(self.log_file) and os.path.getsize(self.log_file) > 10 * 1024 * 1024:
                old_file = self.log_file + ".1"
                if os.path.exists(old_file):
                    os.remove(old_file)
                os.rename(self.log_file, old_file)
        except Exception:
            pass

    def log(self, level: str, msg: str):
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        level_upper = level.upper()
        line = f"[{now_str}] [{level_upper}] {msg}"
        try:
            sys.__stdout__.write(line + "\n")
            sys.__stdout__.flush()
        except Exception:
            pass
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass
        self.sig_log.emit(now_str, level_upper, msg)

    def info(self, msg: str): self.log("INFO", msg)
    def warn(self, msg: str): self.log("WARN", msg)
    def error(self, msg: str): self.log("ERROR", msg)
    def success(self, msg: str): self.log("SUCCESS", msg)


logger = AppLogger.get()
def log_info(msg: str): logger.info(msg)
def log_warn(msg: str): logger.warn(msg)
def log_error(msg: str): logger.error(msg)
def log_success(msg: str): logger.success(msg)


def process_thumbnail_bytes(raw_bytes: bytes, mime: str = "") -> tuple[bytes, str, float]:
    """
    后台工作线程执行：快速自适应生成缩略图 PNG 数据，杜绝占用 Qt 主 UI 线程。
    针对超大包装图纸/复杂多页矢量 PDF 进行靶向轻量级栅格化，耗时由原来的数百毫秒骤降至 10~20ms。
    """
    size_mb = len(raw_bytes) / (1024 * 1024) if raw_bytes else 0.0
    if not raw_bytes:
        return b"", "empty", 0.0

    # 1. PDF 快速轻量栅格化
    if "pdf" in mime.lower() or raw_bytes.startswith(b"%PDF"):
        try:
            import fitz
            doc = fitz.open(stream=raw_bytes, filetype="pdf")
            if len(doc) > 0:
                page = doc.load_page(0)
                rect = page.rect
                # 直接通过 Matrix 缩放到 ~260x160 目标尺寸，避免全分辨率 2000px 渲染与全量转码
                scale = min(260.0 / max(rect.width, 1), 160.0 / max(rect.height, 1), 1.0)
                mat = fitz.Matrix(scale, scale)
                pix = page.get_pixmap(matrix=mat, alpha=False)
                return pix.tobytes("png"), f"pdf_{len(doc)}", size_mb
        except Exception as e:
            print(f"[process_thumbnail_bytes] PDF 缩略图渲染异常: {e}")

    # 2. PIL 普通图片处理 (支持大图、CMYK、JPEG、PNG 等任意格式)
    try:
        with Image.open(io.BytesIO(raw_bytes)) as im:
            if im.mode not in ("RGB", "RGBA"):
                im = im.convert("RGB")
            im.thumbnail((280, 180), Image.Resampling.BILINEAR)
            buf = io.BytesIO()
            im.save(buf, format="PNG")
            return buf.getvalue(), "image", size_mb
    except Exception as e:
        print(f"[process_thumbnail_bytes] PIL 缩略图渲染异常: {e}")

    return b"", "binary", size_mb


class ThumbnailWorkerSignals(QObject):
    finished = Signal(str, bytes, str, float)  # fid, png_bytes, kind, size_mb
    error = Signal(str, str)


class ThumbnailWorker(QRunnable):
    """后台异步缩略图计算线程"""
    def __init__(self, fid: str, raw_bytes: bytes, mime: str):
        super().__init__()
        self.fid = str(fid)
        self.raw_bytes = raw_bytes
        self.mime = mime
        self.signals = ThumbnailWorkerSignals()

    def run(self):
        try:
            png_bytes, kind, size_mb = process_thumbnail_bytes(self.raw_bytes, self.mime)
            self.signals.finished.emit(self.fid, png_bytes, kind, size_mb)
        except Exception as e:
            self.signals.error.emit(self.fid, str(e))


ACTIVE_WORKERS = set()


def request_thumbnail_worker(fid: str, raw_bytes: bytes, mime: str):
    """发起后台异步生成缩略图，完成后入库全局缓存并广播通知卡片刷新"""
    fid_str = str(fid)
    if fid_str in THUMBNAIL_CACHE:
        attachment_hub.sig_thumbnail_ready.emit(fid_str)
        return

    worker = ThumbnailWorker(fid_str, raw_bytes, mime)
    ACTIVE_WORKERS.add(worker)

    def on_done(f_id, png_bytes, kind, size_mb):
        ACTIVE_WORKERS.discard(worker)
        if png_bytes:
            qpix = QPixmap()
            if qpix.loadFromData(png_bytes):
                THUMBNAIL_CACHE[f_id] = (qpix, kind, size_mb)
                attachment_hub.sig_thumbnail_ready.emit(f_id)

    def on_err(f_id, err):
        ACTIVE_WORKERS.discard(worker)

    worker.signals.finished.connect(on_done)
    worker.signals.error.connect(on_err)
    QThreadPool.globalInstance().start(worker)


class DirectDownloadSignals(QObject):
    finished = Signal(str, bytes, str)  # fid, raw_bytes, mime
    error = Signal(str, str)  # fid, error


class DirectDownloadWorker(QRunnable):
    """图片直连下载线程：Python requests 直连（NoProxy），不走代理通道。
    cookies 为主线程快照的 dict（绝不在工作线程碰 Qt/WebEngine）。"""
    def __init__(self, fid: str, cookies: dict, url: str = None):
        super().__init__()
        self.fid = str(fid)
        self.cookies = dict(cookies or {})
        self.url = url
        self.signals = DirectDownloadSignals()

    def run(self):
        try:
            import requests as _rq
            cookies = dict(self.cookies)
            s = _rq.Session()
            s.trust_env = False  # 不读系统代理，直连
            referer = "https://datasearch.nmpa.gov.cn/" if (self.url and "nidc" in self.url) else PORTAL_URL
            s.headers.update({
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
                "Referer": referer,
            })
            for k, v in cookies.items():
                s.cookies.set(k, v)
            target_url = self.url if (self.url and self.url.startswith("http")) else f"{BASE_URL}/nmpafile/gsxxFilePreview?attachmentId={self.fid}"
            r = s.get(target_url, timeout=25)
            if r.status_code != 200:
                self.signals.error.emit(self.fid, f"HTTP {r.status_code}")
                return
            self.signals.finished.emit(self.fid, r.content, r.headers.get("Content-Type", ""))
        except Exception as e:
            try:
                self.signals.error.emit(self.fid, str(e))
            except Exception:
                pass


def request_direct_download(fid: str, cookie_getter, on_fallback=None, url: str = None):
    """发起图片直连下载；失败时经 on_fallback(fid) 回落引擎代理通道。
    cookie_getter 在主线程调用，快照后才起线程（工作线程绝不碰 Qt）。"""
    fid_str = str(fid)
    if fid_str in ATTACHMENT_CACHE or fid_str in IN_PROGRESS_FIDS:
        return False
    try:
        cookies = dict(cookie_getter() or {}) if cookie_getter else {}
    except Exception as e:
        log_warn(f"[DirectDownload] 附件 {fid_str} Cookie 快照失败({e})，直接走代理通道")
        if on_fallback:
            try:
                on_fallback(fid_str)
            except Exception as e2:
                log_error(f"[DirectDownload] 回落代理通道异常: {e2}")
        return True
    IN_PROGRESS_FIDS.add(fid_str)
    worker = DirectDownloadWorker(fid_str, cookies, url)
    ACTIVE_WORKERS.add(worker)

    def on_done(f_id, raw, mime):
        ACTIVE_WORKERS.discard(worker)
        ATTACHMENT_CACHE[f_id] = {"mime": mime, "raw": raw}
        attachment_hub.sig_attachment_loaded.emit(f_id)
        request_thumbnail_worker(f_id, raw, mime)
        preheat_preview_worker(f_id, raw, mime)
        log_info(f"[DirectDownload] 附件 {f_id} 直连下载成功 ({len(raw)/1024/1024:.1f}MB)")
        IN_PROGRESS_FIDS.discard(f_id)

    def on_err(f_id, err):
        ACTIVE_WORKERS.discard(worker)
        log_warn(f"[DirectDownload] 附件 {f_id} 直连失败({err})")
        IN_PROGRESS_FIDS.discard(f_id)
        if on_fallback:
            try:
                on_fallback(f_id)
            except Exception as e:
                log_error(f"[DirectDownload] 回落代理通道异常: {e}")

    worker.signals.finished.connect(on_done)
    worker.signals.error.connect(on_err)
    QThreadPool.globalInstance().start(worker)
    return True

class PreviewWorkerSignals(QObject):
    finished = Signal(int, QImage, int)  # page_idx, qimage, total_pages
    error = Signal(int, str)


class PreviewWorker(QRunnable):
    """大图/PDF超清异步渲染线程 (使用内存 QImage 直传，0 压缩解码开销，彻底杜绝主线程卡顿)"""
    def __init__(self, raw_bytes: bytes, mime: str, page_idx: int):
        super().__init__()
        self.raw_bytes = raw_bytes
        self.mime = mime
        self.page_idx = page_idx
        self.signals = PreviewWorkerSignals()

    def run(self):
        try:
            is_pdf = "pdf" in self.mime.lower() or self.raw_bytes.startswith(b"%PDF")
            if is_pdf:
                import fitz
                doc = fitz.open(stream=self.raw_bytes, filetype="pdf")
                total = len(doc)
                if 0 <= self.page_idx < total:
                    page = doc.load_page(self.page_idx)
                    # 适度合理的 DPI (144dpi 视网膜级超清画质，渲染耗时仅需数十毫秒)
                    pix = page.get_pixmap(dpi=144)
                    fmt = QImage.Format.Format_RGBA8888 if pix.alpha else QImage.Format.Format_RGB888
                    # 纯内存直接构建 QImage 并做深拷贝，0 压缩开销
                    qimg = QImage(bytes(pix.samples), pix.width, pix.height, pix.stride, fmt).copy()
                    self.signals.finished.emit(self.page_idx, qimg, total)
                    return
                self.signals.error.emit(self.page_idx, "页码超出有效范围")
                return

            # 普通图像处理：优先使用 Qt 高度汇编优化的原生图片解码器
            qimg = QImage.fromData(self.raw_bytes)
            if not qimg.isNull():
                if qimg.width() > 2560 or qimg.height() > 2560:
                    qimg = qimg.scaled(2560, 2560, Qt.KeepAspectRatio, Qt.FastTransformation)
                self.signals.finished.emit(0, qimg, 1)
                return

            # 回退 PIL 兜底支持特殊色彩模式 (如 CMYK 分色图纸)
            with Image.open(io.BytesIO(self.raw_bytes)) as im:
                if im.mode not in ("RGB", "RGBA"):
                    im = im.convert("RGB")
                if im.width > 2560 or im.height > 2560:
                    im.thumbnail((2560, 2560), Image.Resampling.BILINEAR)
                raw_bytes_im = im.tobytes()
                fmt = QImage.Format.Format_RGBA8888 if im.mode == "RGBA" else QImage.Format.Format_RGB888
                stride = len(raw_bytes_im) // max(im.height, 1)
                qimg = QImage(raw_bytes_im, im.width, im.height, stride, fmt).copy()
                self.signals.finished.emit(0, qimg, 1)
        except Exception as e:
            self.signals.error.emit(self.page_idx, str(e))


def preheat_preview_worker(fid: str, raw_bytes: bytes, mime: str):
    """后台静默预渲染高清第 0 页，保证用户点击大图时 0ms 秒开无卡顿"""
    fid_str = str(fid)
    cache_key = (fid_str, 0)
    if cache_key in PREVIEW_CACHE or not raw_bytes:
        return
    worker = PreviewWorker(raw_bytes, mime, 0)
    ACTIVE_WORKERS.add(worker)

    def on_done(page_idx, qimg, total):
        ACTIVE_WORKERS.discard(worker)
        if qimg and not qimg.isNull():
            PREVIEW_CACHE[(fid_str, page_idx)] = QPixmap.fromImage(qimg)

    def on_err(page_idx, err):
        ACTIVE_WORKERS.discard(worker)

    worker.signals.finished.connect(on_done)
    worker.signals.error.connect(on_err)
    QThreadPool.globalInstance().start(worker)


def make_thumbnail(raw_bytes: bytes, mime: str = "") -> tuple[QPixmap | None, str]:
    """同步辅助函数 (保持向下兼容)"""
    png_bytes, kind, _ = process_thumbnail_bytes(raw_bytes, mime)
    if png_bytes:
        pix = QPixmap()
        if qpix_loaded := pix.loadFromData(png_bytes):
            return pix, kind
    return None, "binary"


class NetworkManager:
    """代理与网络通道管理器 (支持本地持久化配置、连通性探测与动态切换)"""

    @staticmethod
    def load_config() -> dict:
        """加载本地配置，缺省时使用最新 API 地址"""
        default_cfg = {
            "mode": "direct",
            "api_url": DEFAULT_PROXY_API,
            "last_node": "本机直连"
        }
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        default_cfg.update(data)
            except Exception:
                pass
        return default_cfg

    @staticmethod
    def save_config(cfg: dict):
        """持久化网络配置"""
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    @staticmethod
    def get_my_public_ip() -> str:
        """获取本机当前对外出口的真实公网 IPv4"""
        for url in ("https://myip.ipip.net", "https://api.ipify.org", "http://txt.go.sohu.com/ip/soip"):
            try:
                import re
                req = urllib.request.Request(url, headers={"User-Agent": "curl/8.7.1"})
                with urllib.request.urlopen(req, timeout=2.5) as resp:
                    text = resp.read().decode("utf-8", errors="ignore")
                    m = re.search(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", text)
                    if m:
                        return m.group(1)
            except Exception:
                pass
        return "未知"

    @staticmethod
    def test_proxy_api(api_url: str) -> tuple[bool, str, str]:
        """测试 Proxy API 返回的 IP，返回 (成功/失败, 消息, ip_port)"""
        if not api_url or not api_url.startswith("http"):
            return False, "请输入以 http:// 或 https:// 开头的有效代理 API 地址", ""

        try:
            t_api_start = time.time()
            req = urllib.request.Request(api_url, headers={"User-Agent": "curl/8.7.1"})
            with urllib.request.urlopen(req, timeout=4) as resp:
                text = resp.read().decode("utf-8").strip()

            api_ms = int((time.time() - t_api_start) * 1000)

            match = re.search(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d+)", text)
            if not match:
                return False, f"API 响应未识别到有效 IP:端口。\n原始响应: {text[:150]}", ""

            host = match.group(1)
            port = int(match.group(2))

            # 1. 快速 TCP 握手
            t_tcp_start = time.time()
            s = socket.create_connection((host, port), timeout=3.0)
            tcp_ms = int((time.time() - t_tcp_start) * 1000)

            # 2. HTTP CONNECT 握手验证代理权限与是否需要认证 (407)
            s.sendall(b"CONNECT hzpba.nmpa.gov.cn:443 HTTP/1.1\r\nHost: hzpba.nmpa.gov.cn:443\r\nProxy-Connection: Keep-Alive\r\n\r\n")
            s.settimeout(3.5)
            resp_head = s.recv(1024).decode("latin1", errors="ignore")

            if "407" in resp_head:
                s.close()
                my_ip = NetworkManager.get_my_public_ip()
                return False, (
                    f"代理鉴权未通过 (HTTP 407 Proxy Authentication Required)！\n\n"
                    f"原因：当前本机公网 IP【{my_ip}】尚未加入豆芽白名单。\n"
                    f"请登录豆芽代理官网「个人中心 -> 业务管理 -> 白名单设置」，将【{my_ip}】添加至白名单后再试！"
                ), f"{host}:{port}"

            if not ("200" in resp_head or "HTTP/1." in resp_head):
                s.close()
                return False, f"代理隧道建立失败。\n响应头: {resp_head[:100]}", f"{host}:{port}"

            # 3. TLS 握手与药监局 WAF 响应探测
            t_tls_start = time.time()
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            ss = ctx.wrap_socket(s, server_hostname="hzpba.nmpa.gov.cn")
            ss.settimeout(3.0)
            ss.sendall(b"GET /gccx/ HTTP/1.1\r\nHost: hzpba.nmpa.gov.cn\r\nUser-Agent: curl/8.7.1\r\n\r\n")
            waf_head = ss.recv(256).decode("latin1", errors="ignore")
            tls_ms = int((time.time() - t_tls_start) * 1000)
            ss.close()

            if "412" in waf_head or "200" in waf_head:
                return True, (
                    f"API 延迟: {api_ms}ms | 代理握手: {tcp_ms}ms | TLS/WAF握手: {tls_ms}ms\n"
                    f"代理通道连通状态: 正常通过 (HTTP 200 Tunnel OK / WAF响应正常)"
                ), f"{host}:{port}"
            else:
                return False, f"药监局服务器响应异常:\n{waf_head[:100]}", f"{host}:{port}"

        except Exception as e:
            return False, f"连接异常: {e}", ""

    @staticmethod
    def test_direct_connection() -> tuple[bool, str]:
        """测试本机直接连接国家药监局安全入口的连通性与握手延迟"""
        try:
            t_start = time.time()
            s = socket.create_connection(("hzpba.nmpa.gov.cn", 443), timeout=3.5)
            tcp_ms = int((time.time() - t_start) * 1000)

            t_tls = time.time()
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            ss = ctx.wrap_socket(s, server_hostname="hzpba.nmpa.gov.cn")
            ss.settimeout(3.5)
            ss.sendall(b"GET /gccx/ HTTP/1.1\r\nHost: hzpba.nmpa.gov.cn\r\nUser-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)\r\n\r\n")
            tls_data = ss.recv(256).decode("latin1", errors="ignore")
            tls_ms = int((time.time() - t_tls) * 1000)
            ss.close()

            first_line = tls_data.split("\r\n")[0] if "\r\n" in tls_data else tls_data
            if first_line.startswith("HTTP/") and (" 400" in first_line or " 403" in first_line):
                return False, f"本机 IP 遭到药监局防火墙限制 ({first_line})，建议切换为动态代理模式。"
            return True, f"TCP 握手: {tcp_ms}ms | TLS/WAF 响应: {tls_ms}ms\n直连药监局安全入口正常 ({first_line})。"
        except Exception as e:
            return False, f"本机直连异常: {e}"

    _last_proxy_time = 0

    @staticmethod
    def setup_proxy(mode: str = None, api_url: str = None, max_retries: int = 3, auto_fallback_direct: bool = False) -> tuple[bool, str]:
        """尝试获取并配置动态代理 (同步辅助方法)；若不可用则重试或自动降级直连"""
        cfg = NetworkManager.load_config()
        if mode is None:
            mode = cfg.get("mode", "direct")
        if api_url is None:
            api_url = cfg.get("api_url", DEFAULT_PROXY_API)

        if mode == "direct":
            QNetworkProxy.setApplicationProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
            return True, "原生直连模式"

        last_err = ""
        for attempt in range(max_retries):
            try:
                req = urllib.request.Request(api_url, headers={"User-Agent": "curl/8.7.1"})
                with urllib.request.urlopen(req, timeout=3.5) as resp:
                    text = resp.read().decode("utf-8").strip()

                match = re.search(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d+)", text)
                if not match:
                    last_err = f"API未返回合规IP: {text[:60]}"
                    continue

                host = match.group(1)
                port = int(match.group(2))

                # 1. 快速 TCP CONNECT 探活 2.5s
                s = socket.create_connection((host, port), timeout=2.5)
                s.sendall(b"CONNECT hzpba.nmpa.gov.cn:443 HTTP/1.1\r\nHost: hzpba.nmpa.gov.cn:443\r\nProxy-Connection: Keep-Alive\r\n\r\n")
                s.settimeout(2.5)
                resp_head = s.recv(1024).decode("latin1", errors="ignore")

                if "407" in resp_head:
                    s.close()
                    my_ip = NetworkManager.get_my_public_ip()
                    log_error(f"[NetworkManager] 代理返回 407: 本机公网 IP {my_ip} 未在白名单中")
                    return False, f"代理鉴权失败(407)：当前本机 IP【{my_ip}】未在白名单中"

                if "200" not in resp_head:
                    s.close()
                    last_err = f"代理握手未返回200 (响应: {resp_head[:40]})"
                    continue

                # 2. TLS + 药监局响应快速验证 (2.5s)
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                ss = ctx.wrap_socket(s, server_hostname="hzpba.nmpa.gov.cn")
                ss.settimeout(2.5)
                ss.sendall(b"GET /gccx/ HTTP/1.1\r\nHost: hzpba.nmpa.gov.cn\r\nUser-Agent: curl/8.7.1\r\n\r\n")
                tls_data = ss.recv(256).decode("latin1", errors="ignore")
                ss.close()

                if "412" not in tls_data and "200" not in tls_data:
                    last_err = f"药监局入口TLS响应异常: {tls_data[:40]}"
                    continue

                # 验证通过，设置为全局代理
                proxy = QNetworkProxy()
                proxy.setType(QNetworkProxy.ProxyType.HttpProxy)
                proxy.setHostName(host)
                proxy.setPort(port)
                QNetworkProxy.setApplicationProxy(proxy)
                NetworkManager._last_proxy_time = time.time()

                cfg["last_node"] = f"{host}:{port}"
                cfg["mode"] = "proxy"
                cfg["api_url"] = api_url
                NetworkManager.save_config(cfg)
                log_success(f"[NetworkManager] 动态代理已就绪: {host}:{port}")
                return True, f"动态代理 ({host}:{port})"

            except Exception as e_probe:
                last_err = str(e_probe)
                log_warn(f"[NetworkManager] 代理节点尝试 {attempt + 1}/{max_retries} 失败: {e_probe}")
                time.sleep(0.3)

        if auto_fallback_direct:
            log_warn(f"[NetworkManager] 代理重试耗尽 ({last_err})，自动降级为原生直连模式")
            QNetworkProxy.setApplicationProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
            return True, "原生直连模式 (代理异常自动降级)"

        log_error(f"[NetworkManager] 动态代理配置失败: {last_err}")
        return False, f"代理配置失败(尝试{max_retries}个节点均不可达): {last_err}"


class ProxyProbeWorker(QThread):
    """异步代理与网络连通性探测工作线程，避免任何主 GUI 线程阻塞卡顿"""
    sig_progress = Signal(str)
    sig_finished = Signal(bool, str, str, int)  # success, desc, host, port

    def __init__(self, mode="direct", api_url=DEFAULT_PROXY_API, max_retries=3, parent=None):
        super().__init__(parent)
        self.mode = mode
        self.api_url = api_url
        self.max_retries = max_retries
        self._is_cancelled = False

    def cancel(self):
        self._is_cancelled = True

    def run(self):
        if self.mode == "direct":
            self.sig_progress.emit("正在探测本机直连与国家药监局安全入口连通性...")
            try:
                s = socket.create_connection(("hzpba.nmpa.gov.cn", 443), timeout=3.5)
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                ss = ctx.wrap_socket(s, server_hostname="hzpba.nmpa.gov.cn")
                ss.settimeout(3.5)
                ss.sendall(b"GET /gccx/ HTTP/1.1\r\nHost: hzpba.nmpa.gov.cn\r\nUser-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)\r\n\r\n")
                tls_data = ss.recv(256).decode("latin1", errors="ignore")
                ss.close()
                first_line = tls_data.split("\r\n")[0] if "\r\n" in tls_data else tls_data
                if first_line.startswith("HTTP/") and (" 400" in first_line or " 403" in first_line):
                    self.sig_finished.emit(False, f"本机直连被药监局防护拦截 ({first_line})，建议使用动态代理", "", 0)
                    return
                else:
                    self.sig_finished.emit(True, "原生直连模式", "", 0)
                    return
            except Exception as e:
                self.sig_finished.emit(False, f"本机直连异常: {e}", "", 0)
                return

        last_err = ""
        for attempt in range(1, self.max_retries + 1):
            if self._is_cancelled:
                return
            self.sig_progress.emit(f"正在从服务商接口申请动态 IP (第 {attempt}/{self.max_retries} 次)...")
            try:
                req = urllib.request.Request(self.api_url, headers={"User-Agent": "curl/8.7.1"})
                with urllib.request.urlopen(req, timeout=3.5) as resp:
                    text = resp.read().decode("utf-8").strip()

                m = re.search(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d+)", text)
                if not m:
                    last_err = f"API未返回合规IP: {text[:60]}"
                    continue

                host = m.group(1)
                port = int(m.group(2))

                if self._is_cancelled:
                    return

                # 1. TCP CONNECT 隧道握手
                self.sig_progress.emit(f"正在建立代理节点 TCP 隧道 ({host}:{port})...")
                s = socket.create_connection((host, port), timeout=2.5)
                s.sendall(b"CONNECT hzpba.nmpa.gov.cn:443 HTTP/1.1\r\nHost: hzpba.nmpa.gov.cn:443\r\nProxy-Connection: Keep-Alive\r\n\r\n")
                s.settimeout(2.5)
                resp_head = s.recv(1024).decode("latin1", errors="ignore")

                if "407" in resp_head:
                    s.close()
                    my_ip = NetworkManager.get_my_public_ip()
                    self.sig_finished.emit(False, f"代理鉴权未通过(407)：当前本机公网 IP【{my_ip}】未在豆芽白名单中", "", 0)
                    return

                if "200" not in resp_head:
                    s.close()
                    last_err = f"代理握手未返回200 (响应: {resp_head[:40]})"
                    continue

                if self._is_cancelled:
                    s.close()
                    return

                # 2. TLS + 药监局入口 WAF 连通性探测
                self.sig_progress.emit(f"正在验证药监局安全入口 TLS/WAF 响应 ({host}:{port})...")
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                ss = ctx.wrap_socket(s, server_hostname="hzpba.nmpa.gov.cn")
                ss.settimeout(2.5)
                ss.sendall(b"GET /gccx/ HTTP/1.1\r\nHost: hzpba.nmpa.gov.cn\r\nUser-Agent: curl/8.7.1\r\n\r\n")
                tls_data = ss.recv(256).decode("latin1", errors="ignore")
                ss.close()

                if "412" not in tls_data and "200" not in tls_data:
                    last_err = f"药监局入口TLS响应异常: {tls_data[:40]}"
                    continue

                if self._is_cancelled:
                    return

                self.sig_finished.emit(True, f"动态代理 ({host}:{port})", host, port)
                return

            except Exception as e_probe:
                last_err = str(e_probe)
                time.sleep(0.3)

        self.sig_finished.emit(False, f"代理配置失败(尝试{self.max_retries}个节点均不可达): {last_err}", "", 0)


class EmbeddedNmpaEngine(QObject):
    """内置无头 Chromium 运行引擎，负责承载 NMPA 页面与瑞数 6 算力环境"""
    sig_ready = Signal(bool, str)
    sig_title = Signal(str)
    sig_status = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.view = QWebEngineView()
        self.profile = QWebEngineProfile.defaultProfile()
        self.profile.setHttpUserAgent(
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
        )
        self.is_ready = False
        self.is_reconfiguring = False
        self.net_mode = "初始化..."
        self.last_proxy_time = 0
        self.engine_attempt = 0
        self.max_engine_attempts = 3
        self.watchdog_timeout_sec = 25.0
        self.watchdog_start_time = 0
        self._last_heartbeat_time = 0
        self._probe_worker = None
        self._request_generation = 0
        # Cookie 缓存：cookieAdded 持续累积（含 HttpOnly），直连下载线程取用
        self._cookie_cache: dict = {}
        try:
            self.view.page().profile().cookieStore().cookieAdded.connect(self._on_cookie_added)
        except Exception:
            pass

        self.watchdog_timer = QTimer(self)
        self.watchdog_timer.setInterval(500)
        self.watchdog_timer.timeout.connect(self._check_watchdog)

        self.view.titleChanged.connect(self._on_title_changed)
        self.view.loadFinished.connect(self._on_load_finished)
        self.view.page().loadingChanged.connect(self._on_loading_changed)

        # 特殊化妆品 (datasearch) 专属后台运行容器
        self.ds_view = QWebEngineView()
        self.is_ds_ready = False
        self.ds_view.titleChanged.connect(self._on_ds_title_changed)
        self.ds_view.loadFinished.connect(self._on_ds_load_finished)
        self.ds_view.page().loadingChanged.connect(self._on_ds_loading_changed)

    def _on_ds_title_changed(self, title: str):
        if "数据查询" in title or "国家药品监督管理局" in title:
            self._set_ds_ready()

    def _on_ds_load_finished(self, ok: bool):
        if ok and ("数据查询" in self.ds_view.title() or "国家药品监督管理局" in self.ds_view.title()):
            self._set_ds_ready()

    def _on_ds_loading_changed(self, info: QWebEngineLoadingInfo):
        if self.is_ds_ready:
            return
        status = info.status()
        if status == QWebEngineLoadingInfo.LoadStatus.LoadFailedStatus:
            code = info.errorCode()
            err_str = info.errorString()
            if "NETWORK_CHANGED" in err_str or "ABORTED" in err_str or code in (-21, -3):
                QTimer.singleShot(300, lambda: self.ds_view.load(QUrl(DATASEARCH_PORTAL_URL)))

    def _set_ds_ready(self):
        if not self.is_ds_ready:
            self.is_ds_ready = True
            log_success(f"[EmbeddedNmpaEngine] 特殊化妆品查询通道已就绪: {self.net_mode}")

    def _on_cookie_added(self, c):
        try:
            self._cookie_cache[bytes(c.name()).decode()] = bytes(c.value()).decode()
        except Exception:
            pass

    def _start_watchdog(self):
        self.watchdog_start_time = time.time()
        self._last_heartbeat_time = self.watchdog_start_time
        self.watchdog_timer.start(500)

    def _on_loading_changed(self, info: QWebEngineLoadingInfo):
        if self.is_ready:
            return
        status = info.status()
        if status == QWebEngineLoadingInfo.LoadStatus.LoadFailedStatus:
            code = info.errorCode()
            err_str = info.errorString()
            cfg = NetworkManager.load_config()
            is_proxy = cfg.get("mode", "direct") == "proxy"

            # 1. 网络环境切换过渡瞬态错误 (ERR_NETWORK_CHANGED, ERR_ABORTED)，自动重试载入
            if "NETWORK_CHANGED" in err_str or "ABORTED" in err_str or code in (-21, -3):
                log_warn(f"[EmbeddedNmpaEngine] 检测到网络栈切换过渡 ({err_str}, code={code})，300ms 后自动重新载入入口...")
                self.sig_status.emit("正在同步底层网络环境，自动重新载入入口...")
                QTimer.singleShot(300, lambda: self.view.load(QUrl(PORTAL_URL)))
                return

            # 2. 直连模式下遭遇常规网络加载失败，提示用户检查网络或在设置中开启代理，绝不擅自篡改用户配置
            if not is_proxy:
                log_warn(f"[EmbeddedNmpaEngine] 直连加载未完成 ({err_str})")
                self.sig_status.emit(f"直连访问药监局受阻 ({err_str})。如本机公网 IP 受限，建议在「⚙️ 代理设置」中启用动态代理。")
                return

            # 3. 代理模式下遇到 HTTP 400/403 或底层代理隧道断开，立即秒级切换新节点，无需白等 25 秒
            if is_proxy and (code in (400, 403) or "ERR_PROXY" in err_str or "ERR_TUNNEL" in err_str):
                log_warn(f"[EmbeddedNmpaEngine] 代理节点异常 (HTTP {code} / {err_str})，立即切换新节点...")
                self._trigger_next_proxy(f"代理节点异常({code or err_str[:30]})，正在自动切换下一代理...")

    def _trigger_next_proxy(self, status_msg: str = ""):
        self.watchdog_timer.stop()
        if self.engine_attempt < self.max_engine_attempts:
            self.engine_attempt += 1
            msg = status_msg or f"节点响应超时，正在自动切换下一节点重试 (第 {self.engine_attempt}/{self.max_engine_attempts} 次)..."
            self.sig_status.emit(msg)
            self._start_probe_async()
        else:
            self.is_reconfiguring = False
            err_msg = "连接药监局入口超时，尝试多个代理节点均不可达。建议点击右上角「⚙️ 代理设置」刷新或重置 API"
            self.sig_status.emit(err_msg)
            self.sig_ready.emit(False, err_msg)

    def _check_watchdog(self):
        if self.is_ready:
            self.watchdog_timer.stop()
            return

        # 严格通过 JS 验证页面是否真正完成 DOM 加载、瑞数 6 算力环境注入与通信准备
        js = """(() => {
            try {
                const rs = document.readyState;
                const t = document.title || '';
                const body = document.body ? (document.body.innerText || '') : '';
                const hasTitle = t.includes('备案') || t.includes('化妆品') || body.includes('化妆品');
                const hasToken = typeof window.token !== 'undefined' && window.token !== null && window.token !== '';
                const hasDollar = typeof window.$ !== 'undefined';
                const hasJQuery = typeof window.jQuery !== 'undefined';
                const cookieLen = (document.cookie || '').length;
                const domReady = (rs === 'complete' || rs === 'interactive');
                const envReady = (hasToken || hasDollar || hasJQuery || (domReady && cookieLen > 200));
                return domReady && hasTitle && envReady;
            } catch(e) {
                return false;
            }
        })()"""

        def cb(ready_val):
            if self.is_ready:
                return
            if ready_val:
                self._set_ready()
                return

            now = time.time()
            elapsed = now - self.watchdog_start_time

            # 每隔 1.5 秒更新一次进度与耗时，保证 UI 绝不处于“静止假死”状态
            if now - self._last_heartbeat_time >= 1.5:
                self._last_heartbeat_time = now
                self.sig_status.emit(f"正在载入国家药监局安全入口并进行瑞数鉴权 ({self.net_mode}，已耗时 {int(elapsed)}s)...")

            if elapsed > self.watchdog_timeout_sec:
                cfg = NetworkManager.load_config()
                is_proxy = cfg.get("mode", "direct") == "proxy"
                if is_proxy:
                    self._trigger_next_proxy(f"当前节点响应超时({int(elapsed)}s)，正在自动切换下一代理重试...")
                else:
                    self.watchdog_timer.stop()
                    self.is_reconfiguring = False
                    err_msg = "连接药监局入口超时，请检查本机网络或在代理设置中启用动态代理"
                    self.sig_status.emit(err_msg)
                    self.sig_ready.emit(False, err_msg)

        self.view.page().runJavaScript(js, cb)

    def _set_ready(self):
        self.watchdog_timer.stop()
        self.is_reconfiguring = False
        self.engine_attempt = 0
        if not self.is_ready:
            self.is_ready = True
            log_success(f"[EmbeddedNmpaEngine] 安全通道已就绪: {self.net_mode}")
            self.sig_status.emit(f"安全通道已就绪 ({self.net_mode})")
            self.sig_ready.emit(True, self.net_mode)

    def _start_probe_async(self, mode: str = None, api_url: str = None):
        cfg = NetworkManager.load_config()
        if mode is None:
            mode = cfg.get("mode", "direct")
        if api_url is None:
            api_url = cfg.get("api_url", DEFAULT_PROXY_API)

        if self._probe_worker and self._probe_worker.isRunning():
            self._probe_worker.cancel()
            self._probe_worker.wait(1000)

        self._request_generation += 1
        current_gen = self._request_generation

        self._probe_worker = ProxyProbeWorker(mode=mode, api_url=api_url, max_retries=3, parent=self)

        def on_prog(msg):
            if current_gen == self._request_generation and not self.is_ready:
                self.sig_status.emit(msg)

        def on_fin(ok, desc, host, port):
            if current_gen != self._request_generation:
                return
            self._on_probe_done(ok, desc, host, port, mode, api_url)

        self._probe_worker.sig_progress.connect(on_prog)
        self._probe_worker.sig_finished.connect(on_fin)
        self._probe_worker.start()

    def _on_probe_done(self, ok: bool, desc: str, host: str, port: int, mode: str, api_url: str):
        if not ok:
            self.is_reconfiguring = False
            self.sig_status.emit(desc)
            self.sig_ready.emit(False, desc)
            return

        # 1. 切换通道或节点时，清理绑定旧 IP 的旧 Cookie 缓存与底层 CookieStore，防止跨 IP 遭到药监局 WAF 拦截
        self._cookie_cache.clear()
        try:
            self.view.page().profile().cookieStore().deleteAllCookies()
            self.view.page().profile().clearHttpCache()
        except Exception:
            pass

        if host and port:
            proxy = QNetworkProxy()
            proxy.setType(QNetworkProxy.ProxyType.HttpProxy)
            proxy.setHostName(host)
            proxy.setPort(port)
            QNetworkProxy.setApplicationProxy(proxy)
            self.net_mode = f"动态代理 ({host}:{port})"
        else:
            QNetworkProxy.setApplicationProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
            self.net_mode = desc

        self.last_proxy_time = time.time()
        cfg = NetworkManager.load_config()
        cfg["mode"] = mode
        if host and port:
            cfg["last_node"] = f"{host}:{port}"
        else:
            cfg["last_node"] = "本机直连"
        if api_url:
            cfg["api_url"] = api_url
        NetworkManager.save_config(cfg)

        self.sig_status.emit(f"正在载入国家药监局安全入口并进行瑞数鉴权 ({self.net_mode})...")

        # 2. 关键优化：给 Chromium 网络栈 200ms 缓冲，释放旧的代理 SocketPool，避免并发遭遇 ERR_NETWORK_CHANGED
        def _do_load():
            self.view.load(QUrl(PORTAL_URL))
            self.ds_view.load(QUrl(DATASEARCH_PORTAL_URL))
            self._start_watchdog()

        QTimer.singleShot(200, _do_load)

    def initialize(self, mode: str = None, api_url: str = None):
        """配置网络并载入查询首页 (全异步无阻断)"""
        self.is_reconfiguring = True
        self.is_ready = False
        self.is_ds_ready = False
        self.engine_attempt = 0
        self.watchdog_timer.stop()
        self.sig_status.emit("正在配置网络通道与探测连通性...")
        self._start_probe_async(mode, api_url)

    def reconfigure_network(self, mode: str = None, api_url: str = None) -> tuple[bool, str]:
        """重新配置代理网络并刷新核心入口"""
        self.initialize(mode, api_url)
        return True, "正在重新配置网络通道..."

    def reload_portal(self):
        self.is_ready = False
        self.is_ds_ready = False
        self.engine_attempt = 0
        self.sig_status.emit(f"正在刷新药监局入口 ({self.net_mode})...")
        self.view.load(QUrl(PORTAL_URL))
        self.ds_view.load(QUrl(DATASEARCH_PORTAL_URL))
        self._start_watchdog()

    def _on_title_changed(self, title: str):
        self.sig_title.emit(title)
        if not self.is_ready:
            self._check_watchdog()

    def _on_load_finished(self, ok: bool):
        try:
            self.view.page().profile().cookieStore().loadAllCookies()
        except Exception:
            pass
        if not self.is_ready:
            self._check_watchdog()

    def run_js(self, script: str, callback=None):
        """执行 JS 脚本"""
        if callback:
            self.view.page().runJavaScript(script, callback)
        else:
            self.view.page().runJavaScript(script)

    def get_cookie_dict_sync(self, timeout_ms: int = 5000) -> dict:
        """获取当前引擎已缓存的全部 Cookie 字典（含 HttpOnly，主线程纯只读快照，非阻塞、杜绝事件循环重入）。"""
        return dict(getattr(self, "_cookie_cache", {}) or {})

    def query_special_cosmetic(self, search_val: str, callback):
        """异步查询特殊化妆品（全异步非阻塞），完成后回调 callback(ok: bool, data_or_msg)"""
        val_clean = search_val.strip()
        if not val_clean:
            callback(False, "查询内容为空")
            return

        # 检查特殊化妆品通道是否就绪
        if not self.is_ds_ready:
            if self.ds_view.url().isEmpty():
                self.ds_view.load(QUrl(DATASEARCH_PORTAL_URL))

            def _wait_ready(attempts=0):
                if self.is_ds_ready:
                    self._check_pajax_and_query(val_clean, callback)
                elif attempts < 40:
                    QTimer.singleShot(200, lambda: _wait_ready(attempts + 1))
                else:
                    callback(False, "特殊化妆品数据查询通道连接超时，请检查网络或在代理设置中切换重试。")
            _wait_ready()
        else:
            self._check_pajax_and_query(val_clean, callback)

    def _check_pajax_and_query(self, val_clean: str, callback):
        def _check_pajax(attempts=0):
            def _on_check(is_ready):
                if is_ready:
                    self._do_query_special_js(val_clean, callback)
                elif attempts < 30:
                    QTimer.singleShot(200, lambda: _check_pajax(attempts + 1))
                else:
                    self._do_query_special_js(val_clean, callback)
            self.ds_view.page().runJavaScript(
                "typeof pajax !== 'undefined' && typeof api !== 'undefined'",
                _on_check
            )
        _check_pajax()

    def _do_query_special_js(self, val_clean: str, callback):
        js = f"""
        window.__spDone = false;
        window.__spResult = null;
        (async function() {{
            try {{
                const val = {json.dumps(val_clean)};
                const isJk = val.includes('进') || val.toUpperCase().includes('J');
                const primaryItemId = isJk ? 'ff8080818046502f0180f9519c154181' : 'ff8080818046502f0180f934f6873f78';
                const secondaryItemId = isJk ? 'ff8080818046502f0180f934f6873f78' : 'ff8080818046502f0180f9519c154181';

                let listRes = await pajax.hasTokenGet(api.queryList, {{
                    itemId: primaryItemId,
                    isSenior: 'N',
                    searchValue: val,
                    pageNum: 1,
                    pageSize: 5
                }});
                let chosenItemId = primaryItemId;
                let list = (listRes.data && listRes.data.data && listRes.data.data.list) || [];

                if (list.length === 0) {{
                    listRes = await pajax.hasTokenGet(api.queryList, {{
                        itemId: secondaryItemId,
                        isSenior: 'N',
                        searchValue: val,
                        pageNum: 1,
                        pageSize: 5
                    }});
                    chosenItemId = secondaryItemId;
                    list = (listRes.data && listRes.data.data && listRes.data.data.list) || [];
                }}

                if (list.length === 0) {{
                    window.__spResult = JSON.stringify({{ ok: false, msg: '未在国家药监局特殊化妆品库检索到该产品信息，请核对注册证号或产品名称。' }});
                    window.__spDone = true;
                    return;
                }}

                const item = list[0];
                const isImported = (chosenItemId === 'ff8080818046502f0180f9519c154181');
                const detailId = isImported ? item.f0 : item.f4;

                const detRes = await pajax.hasTokenGet(api.queryDetail, {{
                    itemId: chosenItemId,
                    id: detailId
                }});

                const detail = (detRes.data && detRes.data.data && detRes.data.data.detail) || {{}};

                window.__spResult = JSON.stringify({{
                    ok: true,
                    is_imported: isImported,
                    item: item,
                    detail: detail
                }});
                window.__spDone = true;
            }} catch(e) {{
                window.__spResult = JSON.stringify({{ ok: false, msg: '特殊化妆品检索异常: ' + (e.message || String(e)) }});
                window.__spDone = true;
            }}
        }})()
        """
        self.ds_view.page().runJavaScript(js)

        start_time = time.time()
        def _poll():
            def _on_done(is_done):
                if is_done:
                    def _on_data(raw_data):
                        try:
                            res = json.loads(raw_data) if raw_data else {}
                            if res.get("ok"):
                                item = res.get("item", {})
                                detail = res.get("detail", {})
                                is_imported = res.get("is_imported", False)
                                base_data = normalize_special_cosmetic_data(
                                    item,
                                    detail,
                                    is_imported
                                )
                                # 启动异步深度解析线程，并发抓取中检院/药监局包装图纸、全配方成分及试验依据
                                worker = SpecialCosmeticEnrichWorker(base_data, detail)
                                ACTIVE_WORKERS.add(worker)

                                def on_enrich_done(enriched):
                                    ACTIVE_WORKERS.discard(worker)
                                    callback(True, enriched)

                                worker.sig_done.connect(on_enrich_done)
                                worker.start()
                            else:
                                callback(False, res.get("msg", "未检索到产品数据"))
                        except Exception as e:
                            callback(False, f"解析特殊化妆品数据异常: {e}")
                    self.ds_view.page().runJavaScript("window.__spResult", _on_data)
                elif time.time() - start_time > 15.0:
                    callback(False, "等待药监局特殊化妆品接口响应超时")
                else:
                    QTimer.singleShot(100, _poll)
            self.ds_view.page().runJavaScript("window.__spDone === true", _on_done)
        _poll()


def parse_gxxc_data(raw: dict) -> dict:
    """解析国家药监局法定功效宣称数据 (gxxc/getGxxcInfo)"""
    if not isinstance(raw, dict) or not raw:
        return {
            "claims": "常规护理/基础修饰",
            "claims_list": ["常规护理/基础修饰"],
            "conclusion": "未单独申报或按规定免予公布摘要",
            "body_part": "",
            "dosage_form": "",
            "target_users": "",
            "usage_type": "",
            "eval_summary": "",
            "test_items": [],
            "display_text": "【宣称功效】常规基础修饰 / 日常护理\n【说明】未单独录入功效宣称数据或按法规免予公布摘要。"
        }

    base = raw.get("gxxc") or {}
    cpgx = base.get("cpgx") or ""
    claims_list = []
    if cpgx:
        raw_parts = re.split(r"[,，、;；\s]+", cpgx.strip())
        for p in raw_parts:
            p = p.strip()
            if not p:
                continue
            cleaned = re.sub(r"^\d+\s*", "", p).strip()
            if cleaned and cleaned not in claims_list:
                claims_list.append(cleaned)
    claim_str = "、".join(claims_list) if claims_list else cpgx

    conclusion = base.get("gxpjjl") or ""

    def clean_code(val):
        if not val:
            return ""
        return re.sub(r"^\d+\s*", "", str(val).strip()).strip()

    body_part_clean = clean_code(base.get("zybw"))
    dosage_form_clean = clean_code(base.get("cpjx"))
    target_users_clean = clean_code(base.get("syrq"))
    usage_type_clean = clean_code(base.get("syff"))

    eval_items = []
    test_items = []
    type_map = {
        "1": "人体功效评价试验",
        "2": "实验室试验",
        "3": "消费者使用测试",
        "4": "文献资料评价",
        "5": "研究数据评价"
    }
    for item in raw.get("gxxccps") or []:
        gxmc = item.get("gxmc") or ""
        desc = item.get("cpgxxc") or ""
        pjs = item.get("zlsbGxxzpjList") or []
        pj_texts = []
        sub_tests = []
        for pj in pjs:
            t_name = type_map.get(str(pj.get("type")), "评价项目")
            method = pj.get("ffmc") or ""
            jg = pj.get("jgjs") or method or ""
            if jg:
                pj_texts.append(f"【{t_name}】{jg}")
            else:
                pj_texts.append(f"【{t_name}】已完成合规评价")
            sub_tests.append({
                "type_name": t_name,
                "method": method,
                "result": jg
            })

        detail_lines = []
        if gxmc:
            detail_lines.append(f"● 宣称功效: {gxmc}")
        if pj_texts:
            detail_lines.append("  " + "；".join(pj_texts))
        elif desc:
            detail_lines.append(f"  评价说明: {desc}")
        if detail_lines:
            eval_items.append("\n".join(detail_lines))

        test_items.append({
            "claim": gxmc,
            "desc": desc,
            "tests": sub_tests,
            "detail_text": "\n".join(detail_lines)
        })

    eval_summary = "\n\n".join(eval_items) if eval_items else ""

    summary_parts = []
    if claim_str:
        summary_parts.append(f"【宣称功效】{claim_str}")
    if conclusion:
        summary_parts.append(f"【评价结论】{conclusion}")
    meta_info = []
    if body_part_clean:
        meta_info.append(f"作用部位: {body_part_clean}")
    if dosage_form_clean:
        meta_info.append(f"产品剂型: {dosage_form_clean}")
    if usage_type_clean:
        meta_info.append(f"使用方式: {usage_type_clean}")
    if target_users_clean:
        meta_info.append(f"适用人群: {target_users_clean}")
    if meta_info:
        meta_str = " | ".join(meta_info)
        summary_parts.append(f"【分类属性】{meta_str}")
    if eval_summary:
        summary_parts.append(f"【功效评价依据与项目摘要】\n{eval_summary}")

    return {
        "claims": claim_str or "常规护理/基础修饰",
        "claims_list": claims_list or ["常规护理/基础修饰"],
        "conclusion": conclusion or "按规定免予公布或完成合规评价",
        "body_part": body_part_clean,
        "dosage_form": dosage_form_clean,
        "target_users": target_users_clean,
        "usage_type": usage_type_clean,
        "eval_summary": eval_summary,
        "test_items": test_items,
        "display_text": "\n\n".join(summary_parts) if summary_parts else "【宣称功效】常规基础修饰 / 日常护理\n【说明】未单独录入功效宣称数据或已按常规备案管理。"
    }


def normalize_special_cosmetic_data(item: dict, detail: dict, is_imported: bool) -> dict:
    """将国家药监局数据查询平台返回的特殊化妆品字段标准化为系统通用的档案字典"""
    if is_imported:
        prod_name = detail.get("f1") or item.get("f1") or ""
        prod_en = detail.get("f2") or ""
        category = detail.get("f3") or ""
        enterprise = detail.get("f4") or item.get("f2") or ""
        enterprise_en = detail.get("f5") or ""
        enterprise_addr = detail.get("f6") or ""
        country = detail.get("f7") or ""
        rp_name = detail.get("f8") or ""
        rp_addr = detail.get("f9") or ""
        mfr = detail.get("f10") or ""
        rec_no = detail.get("f11") or item.get("f3") or ""
        rec_date = detail.get("f12") or ""
        exp_date = detail.get("f13") or ""
        remark = detail.get("f14") or ""
        status = detail.get("f15") or item.get("f4") or ""
        std_attach = detail.get("f16") or ""
        tag_attach = detail.get("f17") or ""
        pkg_attach = detail.get("f18") or ""
        claim_summary = detail.get("f19") or ""
        validity = detail.get("f20") or ""
        name_remark = detail.get("f21") or ""
        tech_req = detail.get("f22") or ""
    else:
        prod_name = detail.get("f0") or item.get("f0") or ""
        category = detail.get("f1") or ""
        enterprise = detail.get("f2") or item.get("f1") or ""
        prod_en = detail.get("f3") or ""
        enterprise_addr = detail.get("f4") or ""
        country = detail.get("f5") or "中国"
        rp_name = detail.get("f6") or ""
        rp_addr = detail.get("f7") or ""
        mfr = detail.get("f8") or ""
        rec_no = detail.get("f9") or item.get("f2") or ""
        rec_date = detail.get("f10") or ""
        exp_date = detail.get("f11") or ""
        remark = detail.get("f12") or ""
        status = detail.get("f13") or item.get("f3") or ""
        std_attach = detail.get("f14") or ""
        tag_attach = detail.get("f15") or ""
        pkg_attach = detail.get("f16") or ""
        claim_summary = detail.get("f17") or ""
        validity = detail.get("f18") or ""
        name_remark = detail.get("f19") or ""
        tech_req = detail.get("f21") or ""
        enterprise_en = ""

    clean_claim = claim_summary or ""
    if "<a" in clean_claim:
        href_match = re.search(r'href=[\"\'](.*?)[\"\']', clean_claim)
        if href_match:
            clean_claim = href_match.group(1)

    shelf_str = f"有效期至: {exp_date} (批件期限: {validity})" if exp_date else (validity or "-")

    storage_info = []
    if rp_name:
        storage_info.append(f"【境内责任人】{rp_name}")
    if rp_addr:
        storage_info.append(f"【责任人地址】{rp_addr}")
    if country:
        storage_info.append(f"【原产国/地区】{country}")

    usage_info = f"【特殊用途分类】\n{category or '特殊用途化妆品'}"
    if name_remark:
        usage_info += f"\n\n【产品名称备注】\n{name_remark}"

    mfr_clean = (mfr or "").replace("<br/>", "\n").replace("<br>", "\n").strip()

    comp_text = f"【注册类别】: {category or '特殊化妆品'}\n【执行标准】: {std_attach or '已按国家标准执行'}"
    if tech_req:
        comp_text += f"\n\n【技术要求规范】:\n{tech_req}"

    hist_full = f"【批件状态】: {status}\n【批准日期】: {rec_date}\n【注册有效期】: {shelf_str}"
    if clean_claim and clean_claim.startswith("http"):
        hist_full += f"\n\n【功效宣称依据摘要公示 (中检院 NIDC 评价)】\n{clean_claim}"
    if remark:
        hist_full += f"\n\n【监管部门备注】\n{remark}"

    eff_disp = f"【特殊用途分类】{category or '特殊用途化妆品'}\n【功效宣称公示】{clean_claim if clean_claim else '经国家中检院综合审评并核发注册证'}"

    return {
        "product_name": prod_name,
        "product_name_en": prod_en or enterprise_en or "无",
        "record_no": rec_no,
        "record_date": rec_date or "-",
        "status": status or "有效",
        "is_children": False,
        "shelf_life": shelf_str,
        "enterprise": enterprise or "-",
        "enterprise_addr": enterprise_addr or "-",
        "manufacturer": mfr_clean or "-",
        "usage": usage_info,
        "storage": "\n".join(storage_info) if storage_info else "无",
        "caution": remark or "国家药品监督管理局未组织对本产品所称功效进行审核，本注册证不作为对产品所称功效的认可。",
        "components": comp_text,
        "formula_list": [],
        "attachments": {},
        "history": hist_full,
        "annual_report": f"国家特殊化妆品注册管理，监管批件状态: 【{status}】",
        "is_special": True,
        "is_imported": is_imported,
        "efficacy_claims": category or "特殊用途化妆品",
        "efficacy_info": {
            "claims": category or "特殊用途化妆品",
            "conclusion": "国家特殊化妆品注册管理，经中检院严格技术审评核发批准注册证",
            "body_part": "详见产品使用说明",
            "dosage_form": "特殊化妆品",
            "target_users": "普通人群",
            "usage_type": "驻留/淋洗",
            "eval_summary": f"【功效宣称依据公示】{clean_claim if clean_claim else '经国家中检院综合审评并核发注册证'}",
            "display_text": eff_disp
        },
        "special_details": {
            "claim_url": clean_claim if clean_claim.startswith("http") else "",
            "std_pdf": std_attach,
            "tag_pdf": tag_attach,
            "pkg_attach": pkg_attach
        }
    }


def enrich_special_cosmetic_data(normalized: dict, detail: dict) -> dict:
    """
    针对国家特殊化妆品进行中检院 (NIDC) 数据库深度穿透：
    1. 抓取 LX=4 化妆品上市销售包装图纸附件（产品平面图/立体图/实物包装/标签图纸，支持多页超清 PDF 栅格化预览及原图下载）
    2. 抓取 LX=3 产品执行的标准规范与全配方成分明细 (完整提取原料名称、使用目的、使用方法、贮存条件、安全警示用语)
    3. 抓取 LX=1 功效宣称依据公示与人体功效试验评价项目摘要
    """
    nidc_id = None
    # 优先从特殊化妆品关键字段检索 NIDC ID
    for k in ("f16", "f17", "f18", "f19", "f14", "f15"):
        v = detail.get(k)
        if isinstance(v, str):
            m = re.search(r'ID=([a-fA-F0-9]{20,})', v)
            if m:
                nidc_id = m.group(1)
                break
            m = re.search(r'zxbzInfo([a-fA-F0-9]{20,})_', v)
            if m:
                nidc_id = m.group(1)
                break

    if not nidc_id:
        for k, v in detail.items():
            if isinstance(v, str):
                m = re.search(r'ID=([a-fA-F0-9]{20,})', v) or re.search(r'zxbzInfo([a-fA-F0-9]{20,})_', v)
                if m:
                    nidc_id = m.group(1)
                    break

    if not nidc_id:
        return normalized

    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "Referer": "https://datasearch.nmpa.gov.cn/"
    }

    def _fetch(url):
        try:
            import requests as _rq
            return _rq.get(url, headers=headers, timeout=6)
        except Exception:
            return None

    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=3) as pool:
        f4 = pool.submit(_fetch, f"https://hzpsys.nidc.org.cn/hzpGS/ShowGsInfo?LX=4&ID={nidc_id}")
        f3 = pool.submit(_fetch, f"https://hzpsys.nidc.org.cn/hzpGS/ShowGsInfo?LX=3&ID={nidc_id}")
        f1 = pool.submit(_fetch, f"https://hzpsys.nidc.org.cn/hzpGS/ShowGsInfo?LX=1&ID={nidc_id}")
        r4, r3, r1 = f4.result(), f3.result(), f1.result()

    # 1. 解析 LX=4: 上市销售包装 (标签与包装图片附件)
    attachments = normalized.setdefault("attachments", {})
    pmt_list = []
    if r4 and r4.status_code == 200:
        from bs4 import BeautifulSoup
        soup4 = BeautifulSoup(r4.text, "html.parser")
        for tr in soup4.find_all("tr"):
            tds = tr.find_all("td")
            if len(tds) >= 3:
                a_tag = tr.find("a")
                if a_tag:
                    onclick = a_tag.get("onclick", "")
                    m_id = re.search(r'(\d{15,})', onclick)
                    if m_id:
                        fid = m_id.group(1)
                        fname = a_tag.get_text(strip=True)
                        fdate = tds[2].get_text(strip=True) if len(tds) > 2 else ""
                        pmt_list.append({
                            "id": fid,
                            "name": fname,
                            "date": fdate,
                            "url": f"https://hzpsys.nidc.org.cn/hzpGS/ShowPdf?ID={fid}"
                        })
    if pmt_list:
        attachments["pmt"] = pmt_list
        log_info(f"[SpecialCosmetic] 成功捕获《{normalized.get('product_name')}》上市销售包装图纸附件共 {len(pmt_list)} 份")

    # 2. 解析 LX=3: 产品执行标准规范与配方全成分
    if r3 and r3.status_code == 200:
        # 配方全成分
        m_pf = re.search(r'let pfqcf\s*=\s*(\[.*?\]);', r3.text, re.DOTALL)
        if m_pf:
            try:
                raw_items = json.loads(m_pf.group(1))
                formula_list = []
                for item in raw_items:
                    ylmc = item.get("YLMC", "").strip()
                    symd = item.get("SYMD", "").strip()
                    if ",," in ylmc:
                        parts = [p.strip() for p in ylmc.split(",,") if p.strip()]
                        for p in parts:
                            formula_list.append({"cname": p, "ename": f"使用目的: {symd}" if symd else ""})
                    else:
                        formula_list.append({"cname": ylmc, "ename": f"使用目的: {symd}" if symd else ""})
                if formula_list:
                    normalized["formula_list"] = formula_list
                    log_info(f"[SpecialCosmetic] 成功提取全配方成分明细，共 {len(formula_list)} 项原料")
            except Exception as e:
                log_warn(f"[SpecialCosmetic] 配方解析警告: {e}")

        # 使用方法、安全警示用语、贮存条件、使用期限
        from bs4 import BeautifulSoup
        soup3 = BeautifulSoup(r3.text, "html.parser")
        sections = {}
        curr_k = None
        for p in soup3.find_all("p"):
            txt = p.get_text(strip=True)
            if txt.startswith("【") and txt.endswith("】"):
                curr_k = txt[1:-1]
                sections[curr_k] = ""
            elif curr_k:
                if sections[curr_k]:
                    sections[curr_k] += "\n" + txt
                else:
                    sections[curr_k] = txt

        if sections.get("使用方法"):
            normalized["usage"] = f"【特殊用途分类】\n{normalized.get('efficacy_claims', '特殊用途化妆品')}\n\n【使用方法】\n{sections['使用方法']}"
        if sections.get("安全警示用语"):
            normalized["caution"] = sections["安全警示用语"]
        if sections.get("贮存条件"):
            curr_st = normalized.get("storage", "")
            normalized["storage"] = f"{curr_st}\n【贮存条件】{sections['贮存条件']}".strip()
        if sections.get("使用期限"):
            curr_sh = normalized.get("shelf_life", "")
            normalized["shelf_life"] = f"{curr_sh} (保质期: {sections['使用期限']})"

    # 3. 解析 LX=1: 功效宣称评价项目与人体试验
    if r1 and r1.status_code == 200:
        from bs4 import BeautifulSoup
        soup1 = BeautifulSoup(r1.text, "html.parser")
        test_items = []
        curr_test = {}
        for tr in soup1.find_all("tr"):
            tds = tr.find_all("td")
            if len(tds) >= 2:
                k = tds[0].get_text(strip=True)
                v = tds[1].get_text(strip=True)
                if "方法名称" in k:
                    curr_test["test_name"] = v
                elif "方法来源" in k:
                    curr_test["test_source"] = v
                elif "功效判定指标" in k:
                    curr_test["conclusion"] = v
                elif "试验起止日期" in k:
                    curr_test["test_period"] = v
                elif "人体功效评价试验简述" in k:
                    curr_test["test_summary"] = tds[-1].get_text(strip=True)

        if curr_test.get("test_name") or curr_test.get("conclusion"):
            test_items.append({
                "claim_name": normalized.get("efficacy_claims", "特殊化妆品功效"),
                "test_type": "人体功效评价试验",
                "test_desc": curr_test.get("test_name", "人体功效评价试验"),
                "test_conclusion": curr_test.get("conclusion", ""),
                "test_detail": curr_test.get("test_summary", "")
            })
            normalized["efficacy_info"]["test_items"] = test_items
            if curr_test.get("conclusion"):
                normalized["efficacy_info"]["conclusion"] = curr_test["conclusion"]
            log_info(f"[SpecialCosmetic] 成功解析人体功效试验评价项目与法定结论公示")

    return normalized


class SpecialCosmeticEnrichWorker(QThread):
    """特殊化妆品异步深度扩展工作线程：非阻塞穿透中检院/药监局库拉取上市销售包装与配方成分"""
    sig_done = Signal(dict)

    def __init__(self, base_data: dict, detail: dict):
        super().__init__()
        self.base_data = base_data
        self.detail = detail

    def run(self):
        try:
            enriched = enrich_special_cosmetic_data(self.base_data, self.detail)
            self.sig_done.emit(enriched)
        except Exception as e:
            log_warn(f"[SpecialCosmeticEnrichWorker] 深度扩展解析异常: {e}")
            self.sig_done.emit(self.base_data)


class NmpaQueryController(QObject):
    """全自动查询状态机控制器 (处理验证码获取、ddddocr 识别、列表检索、详情请求与批量并发归档)"""
    sig_status = Signal(str)
    sig_success = Signal(dict)
    sig_batch_success = Signal(list)
    sig_error = Signal(str)

    def __init__(self, engine: EmbeddedNmpaEngine):
        super().__init__()
        self.engine = engine
        self.ocr = ddddocr.DdddOcr(show_ad=False)
        self.record_no = ""
        self.gb = "G"
        self.attempt = 0
        self.max_retries = 6
        self.current_item = None
        self.current_prod_id = None
        self.detail_attempt = 0
        self.is_querying = False
        self.prefetch_queue = []
        self.prefetch_active = 0
        # 后台附件预取并发上限：多张图纸并行下载+渲染，避免串行等待转圈
        self.prefetch_max_concurrent = 4

    def _poll_js_var(self, var_name: str, callback, max_wait_sec=20.0, poll_interval_ms=150, on_timeout=None):
        """通用非阻塞轮询机制：检查 window.{var_name} 直至非空或超时"""
        start_time = time.time()

        def check():
            def on_eval(res_str):
                if res_str is not None and res_str != "":
                    # 取到结果，清理该 JS 变量避免状态残留
                    self.engine.run_js(f"window.{var_name} = null;")
                    callback(res_str)
                    return
                # 超时判定
                if time.time() - start_time > max_wait_sec:
                    self.engine.run_js(f"window.{var_name} = null;")
                    if on_timeout:
                        on_timeout()
                    else:
                        log_error(f"等待药监局接口响应超时: {var_name} (超过 {max_wait_sec}s)")
                        self._emit_error(f"等待药监局接口响应超时 ({var_name})，请检查网络。")
                    return
                # 未超时则继续轮询
                QTimer.singleShot(poll_interval_ms, check)

            self.engine.run_js(f"window.{var_name}", on_eval)

        check()

    def start_special_query(self, record_no: str):
        """发起单条特殊化妆品（国妆特字/特进字）检索"""
        if self.is_querying:
            return
        self.is_querying = True
        self.record_no = record_no.strip()
        self.sig_status.emit(f"正在检索特殊化妆品注册信息: 【{self.record_no}】...")
        log_info(f"发起特殊化妆品检索: 【{self.record_no}】")

        def _on_done(ok: bool, data_or_msg):
            self.is_querying = False
            if ok:
                log_success(f"特殊化妆品检索成功: 《{data_or_msg.get('product_name')}》")
                # 自动触发后台静默预提取包装图纸附件（完全非阻塞，逐个入库并由后台线程渲染）
                for k in ("pmt", "ltt", "sms"):
                    for item in (data_or_msg.get("attachments", {}).get(k) or []):
                        fid = str(item.get("id"))
                        url = item.get("url")
                        if fid and fid not in ATTACHMENT_CACHE and fid not in IN_PROGRESS_FIDS:
                            request_direct_download(fid, self.engine.get_cookie_dict_sync, None, url)
                self.sig_success.emit(data_or_msg)
            else:
                log_error(f"特殊化妆品检索未完成: {data_or_msg}")
                self._emit_error(data_or_msg)

        self.engine.query_special_cosmetic(self.record_no, _on_done)

    def start_batch_special_query(self, records: list):
        """发起批量特殊化妆品检索"""
        if self.is_querying:
            return
        self.is_querying = True
        self.batch_queue = list(records)
        self.batch_results = []
        self.batch_total = len(records)
        self.batch_current_idx = 0
        self.sig_status.emit(f"开始批量检索特殊化妆品，共 {self.batch_total} 款...")

        def _step_next():
            if self.batch_current_idx >= self.batch_total:
                self.is_querying = False
                log_success(f"批量特殊化妆品检索完成，成功采集 {len(self.batch_results)} 款档案。")
                self.sig_batch_success.emit(self.batch_results)
                return

            rec = self.batch_queue[self.batch_current_idx]
            self.sig_status.emit(f"正在检索第 ({self.batch_current_idx + 1}/{self.batch_total}) 款特殊化妆品: 【{rec}】...")

            def _on_item_done(ok, data_or_msg):
                if ok:
                    self.batch_results.append(data_or_msg)
                    for k in ("pmt", "ltt", "sms"):
                        for item in (data_or_msg.get("attachments", {}).get(k) or []):
                            fid = str(item.get("id"))
                            url = item.get("url")
                            if fid and fid not in ATTACHMENT_CACHE and fid not in IN_PROGRESS_FIDS:
                                request_direct_download(fid, self.engine.get_cookie_dict_sync, None, url)
                else:
                    log_warn(f"批量跳过未能检索到的特殊化妆品: {rec} ({data_or_msg})")
                self.batch_current_idx += 1
                QTimer.singleShot(150, _step_next)

            self.engine.query_special_cosmetic(rec, _on_item_done)

        _step_next()

    def start_query(self, record_no: str):
        if self.is_querying:
            return

        self.prefetch_queue.clear()
        self.prefetch_active = 0
        self.record_no = record_no.strip()
        self.gb = "J" if ("进字" in self.record_no or "J" in self.record_no.upper()) else "G"
        log_info(f"发起单条备案号检索: 【{self.record_no}】 (类别: {'进口' if self.gb == 'J' else '国产'})")

        if not self.engine.is_ready:
            self.is_querying = True
            self.sig_status.emit("引擎就绪中，正在初始化安全通道...")
            log_info("安全通道未就绪，开始初始化安全通道...")

            if not self.engine.is_reconfiguring:
                self.engine.initialize()

            wait_timer = QTimer(self)
            wait_timer.setSingleShot(True)

            def on_ready_during_wait(ok, desc):
                wait_timer.stop()
                try:
                    self.engine.sig_ready.disconnect(on_ready_during_wait)
                except Exception:
                    pass
                if ok:
                    self.attempt = 0
                    self.detail_attempt = 0
                    self.current_item = None
                    self.current_prod_id = None
                    log_success(f"安全通道已就绪: {desc}，开始检索流程...")
                    self._step_kaptcha_list()
                else:
                    log_error(f"安全通道初始化未完成: {desc}")
                    self._emit_error(f"安全通道初始化未完成: {desc}。请在「⚙️ 代理设置」中切换节点或直连。")

            def on_wait_timeout():
                try:
                    self.engine.sig_ready.disconnect(on_ready_during_wait)
                except Exception:
                    pass
                log_error("等待安全通道就绪超时 (65s)")
                self._emit_error("等待安全通道就绪超时。请检查网络或点击顶部「⚙️ 代理设置」重新连接。")

            wait_timer.timeout.connect(on_wait_timeout)
            wait_timer.start(65000)
            self.engine.sig_ready.connect(on_ready_during_wait)
            return

        self.is_querying = True
        self.attempt = 0
        self.detail_attempt = 0
        self.current_item = None
        self.current_prod_id = None
        self._step_kaptcha_list()

    def _emit_error(self, msg: str):
        self.is_querying = False
        log_error(f"检索失败终止: {msg}")
        self.sig_error.emit(msg)

    def _emit_success(self, data: dict):
        self.is_querying = False
        pname = data.get("product_name", "未知")
        log_success(f"检索圆满完成: 《{pname}》【{data.get('record_no')}】")
        self.sig_status.emit("查询完成！")
        self.sig_success.emit(data)

    def _step_kaptcha_list(self):
        self.attempt += 1
        if self.attempt > self.max_retries:
            log_error(f"列表验证码多次识别校验未通过 (尝试 {self.max_retries} 次)")
            self._emit_error("列表验证码多次识别校验未通过，请检查网络或稍后再试。")
            return

        msg = f"获取列表验证码 (第 {self.attempt}/{self.max_retries} 次)..."
        self.sig_status.emit(msg)
        log_info(msg)

        js = """(async () => {
            window.__kaptcha_l = null;
            try {
                const controller = new AbortController();
                const tid = setTimeout(() => controller.abort(), 12000);
                const r = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/kaptcha', { signal: controller.signal });
                clearTimeout(tid);
                const d = await r.json();
                window.__kaptcha_l = JSON.stringify({ok: true, data: d});
            } catch(e) {
                window.__kaptcha_l = JSON.stringify({ok: false, error: e.toString()});
            }
        })();"""
        self.engine.run_js(js)
        self._poll_js_var("__kaptcha_l", self._on_kaptcha_list, max_wait_sec=15.0,
                          on_timeout=lambda: self._step_kaptcha_list())

    def _on_kaptcha_list(self, res_str: str):
        try:
            res = json.loads(res_str)
            if not res.get("ok"):
                log_warn(f"列表验证码接口网络异常: {res.get('error')}")
                if self.attempt >= 2 and NetworkManager.load_config().get("mode") == "proxy":
                    self.sig_status.emit("检测到代理节点已失效，正在自动切换下一代理并重试...")
                    log_warn("检测到代理节点异常，自动切换下一代理...")
                    def on_retry_ready(ok, desc):
                        try:
                            self.engine.sig_ready.disconnect(on_retry_ready)
                        except Exception:
                            pass
                        if ok:
                            self._step_kaptcha_list()
                        else:
                            self._emit_error(f"代理重试切换未成功: {desc}。建议切换为直连模式。")
                    self.engine.sig_ready.connect(on_retry_ready)
                    self.engine.reconfigure_network()
                    return
                QTimer.singleShot(200, self._step_kaptcha_list)
                return

            d = res["data"]
            token = d.get("captchaKey")
            img_b64 = d.get("base64Img", "").split(",")[-1]
            code = self.ocr.classification(base64.b64decode(img_b64)).strip()
            log_info(f"列表验证码 OCR 识别成功: '{code}' (Key: {str(token)[:10]}...)")
            self._step_query_list(token, code)
        except Exception as e:
            log_error(f"列表验证码解析异常: {e}")
            QTimer.singleShot(200, self._step_kaptcha_list)

    def _step_query_list(self, token: str, code: str):
        msg = f"检索备案号【{self.record_no}】(验证码: {code})..."
        self.sig_status.emit(msg)
        log_info(msg)

        payload = {
            "prodName": "",
            "recordNo": self.record_no,
            "entName": "",
            "gb": self.gb,
            "token": token,
            "dataCode": code
        }
        js = f"""(async () => {{
            window.__query_l = null;
            try {{
                const controller = new AbortController();
                const tid = setTimeout(() => controller.abort(), 15000);
                const r = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/query', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json;charset=UTF-8'}},
                    body: JSON.stringify({json.dumps(payload)}),
                    signal: controller.signal
                }});
                clearTimeout(tid);
                const d = await r.json();
                window.__query_l = JSON.stringify({{ok: true, data: d}});
            }} catch(e) {{
                window.__query_l = JSON.stringify({{ok: false, error: e.toString()}});
            }}
        }})();"""
        self.engine.run_js(js)
        self._poll_js_var("__query_l", self._on_query_list, max_wait_sec=20.0,
                          on_timeout=lambda: self._step_kaptcha_list())

    def _on_query_list(self, res_str: str):
        try:
            res = json.loads(res_str)
            if not res.get("ok"):
                err = str(res.get("error", ""))
                # 412 重验证页面：fetch 返回 HTML 而非 JSON，r.json() 在页内抛错。
                # 此时 Cookie 已失效，重取 kaptcha 无用，需等引擎重就绪后从头来。
                if "<!DOCTYPE" in err or "Unexpected token" in err or "not valid JSON" in err:
                    log_warn("列表请求撞上 WAF 重验证 (412)，等待引擎重就绪后重试...")
                    QTimer.singleShot(200, self._step_kaptcha_list)
                    return
                log_warn(f"列表检索网络请求异常: {res.get('error')}")
                QTimer.singleShot(200, self._step_kaptcha_list)
                return
            data = res["data"]
            if isinstance(data, dict) and "msg" in data:
                log_warn(f"列表验证码校验未通过: {data.get('msg')}，正在自动重试...")
                QTimer.singleShot(200, self._step_kaptcha_list)
                return
            if isinstance(data, list):
                if len(data) == 0:
                    log_warn(f"未找到与备案编号【{self.record_no}】匹配的产品记录")
                    self._emit_error(f"未找到与备案编号【{self.record_no}】匹配的产品记录。")
                    return
                self.current_item = data[0]
                self.current_prod_id = self.current_item.get("id")
                pname = self.current_item.get("prodName", "")
                log_success(f"列表命中目标产品: 《{pname}》 (ID: {self.current_prod_id})")
                # 与详情验证码并行申请：两张图一次拿，OCR 一起解，省一次 RTT。
                # 详情 kaptcha 与列表 token 无依赖，可安全预取；若详情验证码先过期
                # （expire 300s，远大于列表 query 耗时），回落到原串行链路。
                self._step_kaptcha_detail_prefetch()
                return
            self._emit_error(f"返回数据异常: {str(data)[:100]}")
        except Exception as e:
            log_error(f"列表响应解析异常: {e}")
            self._emit_error(f"列表解析异常: {str(e)}")

    def _step_kaptcha_detail_prefetch(self):
        """列表命中后立即并行预取详情验证码（与 _step_kaptcha_detail 同接口）。
        命中即发起，不等列表 query 回包解析完成后的下一轮事件循环，省一次 RTT。
        失败时静默回落到原串行链路 _step_kaptcha_detail。"""
        prod_name = self.current_item.get("prodName", "")
        msg = f"已命中: 《{prod_name}》，正在读取档案（详情验证码并行预取中）..."
        self.sig_status.emit(msg)
        log_info(msg)
        js = """(async () => {
            window.__kaptcha_d = null;
            try {
                const controller = new AbortController();
                const tid = setTimeout(() => controller.abort(), 12000);
                const r = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/kaptcha', { signal: controller.signal });
                clearTimeout(tid);
                const d = await r.json();
                window.__kaptcha_d = JSON.stringify({ok: true, data: d});
            } catch(e) {
                window.__kaptcha_d = JSON.stringify({ok: false, error: e.toString()});
            }
        })();"""
        # 预取不计入 detail_attempt（失败回落串行链路时再计），避免误耗重试预算
        self.detail_attempt = max(0, self.detail_attempt)
        self.engine.run_js(js)
        self._poll_js_var("__kaptcha_d", self._on_kaptcha_detail, max_wait_sec=15.0,
                          on_timeout=lambda: self._step_kaptcha_detail())
    def _step_kaptcha_detail(self):
        self.detail_attempt += 1
        if self.detail_attempt > self.max_retries:
            log_error(f"详情验证码多次识别校验未通过 ({self.max_retries} 次)")
            self._emit_error("详情验证码多次识别校验未通过，请重试。")
            return

        prod_name = self.current_item.get("prodName", "")
        msg = f"已命中: 《{prod_name}》，正在读取档案..."
        self.sig_status.emit(msg)
        log_info(msg)

        js = """(async () => {
            window.__kaptcha_d = null;
            try {
                const controller = new AbortController();
                const tid = setTimeout(() => controller.abort(), 12000);
                const r = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/kaptcha', { signal: controller.signal });
                clearTimeout(tid);
                const d = await r.json();
                window.__kaptcha_d = JSON.stringify({ok: true, data: d});
            } catch(e) {
                window.__kaptcha_d = JSON.stringify({ok: false, error: e.toString()});
            }
        })();"""
        self.engine.run_js(js)
        self._poll_js_var("__kaptcha_d", self._on_kaptcha_detail, max_wait_sec=15.0,
                          on_timeout=lambda: self._step_kaptcha_detail())

    def _on_kaptcha_detail(self, res_str: str):
        try:
            res = json.loads(res_str)
            if not res.get("ok"):
                log_warn(f"详情验证码获取异常: {res.get('error')}")
                QTimer.singleShot(200, self._step_kaptcha_detail)
                return
            d = res["data"]
            token = d.get("captchaKey")
            img_b64 = d.get("base64Img", "").split(",")[-1]
            code = self.ocr.classification(base64.b64decode(img_b64)).strip()
            log_info(f"详情验证码 OCR 识别成功: '{code}' (Key: {str(token)[:10]}...)")
            self._step_query_detail(token, code)
        except Exception as e:
            log_error(f"详情验证码解析异常: {e}")
            QTimer.singleShot(200, self._step_kaptcha_detail)

    def _step_query_detail(self, token: str, code: str):
        payload = {
            "prodId": self.current_prod_id,
            "gb": self.gb,
            "token": token,
            "dataCode": code
        }
        gxxc_payload = {
            "prodId": self.current_prod_id,
            "gb": self.gb
        }
        log_info(f"正在拉取产品《{self.current_item.get('prodName')}》全量详情档案与法定功效宣称...")
        js = f"""(async () => {{
            window.__detail_res = null;
            try {{
                const controller = new AbortController();
                const tid = setTimeout(() => controller.abort(), 15000);
                const pProd = fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/getProdInfo', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json;charset=UTF-8'}},
                    body: JSON.stringify({json.dumps(payload)}),
                    signal: controller.signal
                }}).then(r => r.json());

                const pGxxc = fetch('/HZPBZCX/PTHZPBA-SERVER/gxxc/getGxxcInfo', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json;charset=UTF-8'}},
                    body: JSON.stringify({json.dumps(gxxc_payload)}),
                    signal: controller.signal
                }}).then(r => r.json()).catch(e => null);

                const [dProd, dGxxc] = await Promise.all([pProd, pGxxc]);
                clearTimeout(tid);
                window.__detail_res = JSON.stringify({{ok: true, data: dProd, gxxc: dGxxc}});
            }} catch(e) {{
                window.__detail_res = JSON.stringify({{ok: false, error: e.toString()}});
            }}
        }})();"""
        self.engine.run_js(js)
        self._poll_js_var("__detail_res", self._on_query_detail, max_wait_sec=20.0,
                          on_timeout=lambda: self._step_kaptcha_detail())

    def _on_query_detail(self, res_str: str):
        try:
            res = json.loads(res_str)
            if not res.get("ok"):
                log_warn(f"详情档案请求异常: {res.get('error')}")
                QTimer.singleShot(200, self._step_kaptcha_detail)
                return
            detail = res["data"]
            if isinstance(detail, dict) and (detail.get("msg") == "1" or "验证码" in str(detail.get("msg", ""))):
                log_warn(f"详情验证码校验未通过: {detail.get('msg')}，正在自动重试...")
                QTimer.singleShot(200, self._step_kaptcha_detail)
                return

            gxxc_raw = res.get("gxxc")
            gxxc_info = parse_gxxc_data(gxxc_raw)

            # 数据清洗与规整
            file_ids = detail.get("fileIdList") or {}
            dzbq_ids = detail.get("dzbq") or {}

            def format_list(ids):
                if not ids or not isinstance(ids, list):
                    return []
                return [{"id": x, "url": f"{PREVIEW_URL}{x}"} for x in ids if x]

            result_data = {
                "record_no": self.record_no,
                "product_name": detail.get("prodName", ""),
                "product_name_en": detail.get("prodNameEn", ""),
                "is_children": detail.get("sfetcp") == "是",
                "record_date": detail.get("recordDate", ""),
                "shelf_life": detail.get("syqx", ""),
                "status": "正常在售（有效）" if not detail.get("offdate") else f"已注销 ({detail.get('offdate')})",
                "enterprise": detail.get("entName", ""),
                "enterprise_addr": detail.get("entAddr", ""),
                "manufacturer": detail.get("productEnt", ""),
                "responsible_person": detail.get("jnzrrName", ""),
                "components": detail.get("component", ""),
                "formula_list": detail.get("formulaList", []),
                "usage": detail.get("syff", ""),
                "caution": detail.get("aqjsyy", ""),
                "storage": detail.get("zctj", ""),
                "history": detail.get("history", ""),
                "annual_report": detail.get("remark", ""),
                "efficacy_claims": gxxc_info.get("claims", "常规护理/基础修饰"),
                "efficacy_info": gxxc_info,
                "attachments": {
                    "pmt": format_list(file_ids.get("pmt")),
                    "ltt": format_list(file_ids.get("ltt")),
                    "sms": format_list(file_ids.get("sms")),
                    "dzbq": format_list(dzbq_ids.get("sms")),
                }
            }

            log_success(f"产品详情规整成功: 《{result_data['product_name']}》，配方包含 {len(result_data['formula_list'])} 项")

            # 立即发出成功信号，界面秒级呈现产品基本信息与配方成分 (杜绝任何主线程阻塞)
            self._emit_success(result_data)

            # 在后台静默预提取包装图纸附件（完全非阻塞，逐个入库并由后台线程渲染）
            all_fids = []
            for k in ("pmt", "ltt", "sms"):
                for fid in (file_ids.get(k) or []):
                    if fid and str(fid) not in ATTACHMENT_CACHE and str(fid) not in all_fids:
                        all_fids.append(str(fid))
            if all_fids:
                log_info(f"档案已规整，启动后台异步提取 {len(all_fids)} 份包装高清图纸...")
                self._start_background_prefetch(all_fids)
        except Exception as e:
            log_error(f"详情规整异常: {e}")
            self._emit_error(f"详情规整异常: {str(e)}")

    def start_batch_query(self, records: list[str]):
        if self.is_querying:
            return

        self.prefetch_queue.clear()
        self.prefetch_active = 0
        self.batch_records = [r.strip() for r in records if r.strip()]
        if not self.batch_records:
            return

        log_info(f"收到批量归档任务请求，待查询备案编号共 {len(self.batch_records)} 个: {self.batch_records}")

        if not self.engine.is_ready:
            self.is_querying = True
            self.sig_status.emit("引擎就绪中，正在初始化安全通道...")
            log_info("安全通道未就绪，开始初始化安全通道...")

            if not self.engine.is_reconfiguring:
                self.engine.initialize()

            wait_timer = QTimer(self)
            wait_timer.setSingleShot(True)

            def on_batch_ready_wait(ok, desc):
                wait_timer.stop()
                try:
                    self.engine.sig_ready.disconnect(on_batch_ready_wait)
                except Exception:
                    pass
                if ok:
                    self.batch_attempt = 0
                    log_success(f"安全通道就绪: {desc}，启动批量并发归档通道...")
                    self.sig_status.emit(f"启动并发归档通道，共 {len(self.batch_records)} 款产品...")
                    self._batch_step_kaptcha_list()
                else:
                    log_error(f"安全通道初始化未完成: {desc}")
                    self._emit_error(f"安全通道初始化未完成: {desc}。请在「⚙️ 代理设置」中切换模式或重试。")

            def on_batch_wait_timeout():
                try:
                    self.engine.sig_ready.disconnect(on_batch_ready_wait)
                except Exception:
                    pass
                log_error("等待安全通道就绪超时 (65s)")
                self._emit_error("等待安全通道就绪超时。请检查网络或点击顶部「⚙️ 代理设置」重新连接。")

            wait_timer.timeout.connect(on_batch_wait_timeout)
            wait_timer.start(65000)
            self.engine.sig_ready.connect(on_batch_ready_wait)
            return

        self.is_querying = True
        self.batch_attempt = 0
        log_info(f"安全通道正常，启动并发归档通道，共 {len(self.batch_records)} 款产品...")
        self.sig_status.emit(f"启动并发归档通道，共 {len(self.batch_records)} 款产品...")
        self._batch_step_kaptcha_list()

    def _batch_step_kaptcha_list(self):
        self.batch_attempt += 1
        if self.batch_attempt > self.max_retries:
            log_error(f"批量查询验证码已达最大尝试次数 ({self.max_retries})，终止检索")
            self._emit_error("批量查询验证码多次识别校验未通过，请检查网络或稍后重试。")
            return

        n = len(self.batch_records)
        msg = f"并发申请 {n} 组列表验证码 (第 {self.batch_attempt}/{self.max_retries} 次)..."
        self.sig_status.emit(msg)
        log_info(msg)

        js = f"""(async () => {{
            window.__ks_batch_l = null;
            const fetchK = async (idx) => {{
                const controller = new AbortController();
                const tid = setTimeout(() => controller.abort(), 12000);
                try {{
                    const r = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/kaptcha', {{ signal: controller.signal }});
                    clearTimeout(tid);
                    const d = await r.json();
                    return {{ idx, ok: true, data: d }};
                }} catch(e) {{
                    clearTimeout(tid);
                    return {{ idx, ok: false, error: e.toString() }};
                }}
            }};
            const ks = await Promise.all({list(range(n))}.map(fetchK));
            window.__ks_batch_l = JSON.stringify(ks);
        }})();"""
        self.engine.run_js(js)
        self._poll_js_var("__ks_batch_l", self._batch_on_kaptcha_list, max_wait_sec=20.0,
                          on_timeout=lambda: self._batch_step_kaptcha_list())

    def _batch_on_kaptcha_list(self, res_str: str):
        try:
            ks = json.loads(res_str)
            succ_k = sum(1 for item in ks if item.get("ok"))
            log_info(f"第 {self.batch_attempt} 次验证码获取响应: 成功 {succ_k}/{len(ks)}")

            if any(not item.get("ok") for item in ks):
                log_warn(f"部分验证码拉取失败，准备重试第 {self.batch_attempt + 1} 次...")
                if self.batch_attempt >= 2 and NetworkManager.load_config().get("mode") == "proxy":
                    self.sig_status.emit("检测到代理节点已失效，正在自动换取新代理并重载...")
                    log_warn("检测到代理节点异常，触发自动换 IP 重连...")
                    def on_batch_retry_ready(ok, desc):
                        try:
                            self.engine.sig_ready.disconnect(on_batch_retry_ready)
                        except Exception:
                            pass
                        if ok:
                            self._batch_step_kaptcha_list()
                        else:
                            self._emit_error(f"代理重试切换未成功: {desc}。建议切换为直连模式。")
                    self.engine.sig_ready.connect(on_batch_retry_ready)
                    self.engine.reconfigure_network()
                    return
                QTimer.singleShot(200, self._batch_step_kaptcha_list)
                return

            tasks = []
            for item in ks:
                idx = item["idx"]
                rec = self.batch_records[idx]
                d = item.get("data", {})
                token = d.get("captchaKey")
                img_b64 = d.get("base64Img", "").split(",")[-1]
                code = self.ocr.classification(base64.b64decode(img_b64)).strip()
                gb = "J" if ("进字" in rec or "J" in rec.upper()) else "G"
                log_info(f"[{idx+1}/{len(ks)}] 备案号【{rec}】OCR 识别结果: '{code}' (Token: {str(token)[:10]}...)")
                tasks.append({"idx": idx, "rec": rec, "token": token, "code": code, "gb": gb})

            self.sig_status.emit(f"验证码识别完成，并发检索 {len(tasks)} 款产品列表...")
            log_info(f"发送批量产品列表检索 POST 请求，共 {len(tasks)} 个任务...")

            js_tasks = json.dumps(tasks)
            js = f"""(async () => {{
                window.__batch_list_res = null;
                const tasks = {js_tasks};
                const doQ = async (t) => {{
                    const controller = new AbortController();
                    const tid = setTimeout(() => controller.abort(), 15000);
                    try {{
                        const payload = {{
                            prodName: '',
                            recordNo: t.rec,
                            entName: '',
                            gb: t.gb,
                            token: t.token,
                            dataCode: t.code
                        }};
                        const r = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/query', {{
                            method: 'POST',
                            headers: {{'Content-Type': 'application/json;charset=UTF-8'}},
                            body: JSON.stringify(payload),
                            signal: controller.signal
                        }});
                        clearTimeout(tid);
                        const d = await r.json();
                        return {{ idx: t.idx, rec: t.rec, ok: true, d: d }};
                    }} catch(e) {{
                        clearTimeout(tid);
                        return {{ idx: t.idx, rec: t.rec, ok: false, error: e.toString() }};
                    }}
                }};
                const results = [];
                for (let i = 0; i < tasks.length; i += 3) {{
                    const chunk = tasks.slice(i, i + 3);
                    const chunkRes = await Promise.all(chunk.map(doQ));
                    results.push(...chunkRes);
                }}
                window.__batch_list_res = JSON.stringify(results);
            }})();"""
            self.engine.run_js(js)
            self._poll_js_var("__batch_list_res", self._batch_on_list_res, max_wait_sec=25.0,
                              on_timeout=lambda: self._batch_step_kaptcha_list())
        except Exception as e:
            log_error(f"批量验证码解析异常: {e}")
            QTimer.singleShot(200, self._batch_step_kaptcha_list)

    def _batch_on_list_res(self, res_str: str):
        try:
            results = json.loads(res_str)
            hits = []
            captcha_fails = []
            not_found = []
            for r in results:
                rec = r["rec"]
                if not r.get("ok"):
                    log_warn(f"备案号【{rec}】列表查询网络异常: {r.get('error')}")
                    continue
                d = r.get("d")
                if isinstance(d, dict) and "msg" in d:
                    log_warn(f"备案号【{rec}】验证码校验未通过: {d.get('msg')}")
                    captcha_fails.append(rec)
                    continue
                if isinstance(d, list) and len(d) > 0:
                    item = d[0]
                    pname = item.get("prodName", "未知")
                    pid = item.get("id")
                    log_success(f"已命中备案号【{rec}】: 《{pname}》 (ID: {pid})")
                    hits.append({
                        "idx": r["idx"],
                        "rec": rec,
                        "prod_id": pid,
                        "prod_name": pname,
                        "gb": "J" if ("进字" in rec or "J" in rec.upper()) else "G"
                    })
                else:
                    log_warn(f"未找到与备案编号【{rec}】匹配的产品记录")
                    not_found.append(rec)

            if not hits:
                if captcha_fails and self.batch_attempt < self.max_retries:
                    log_warn(f"因验证码未通过重新发起检索 (第 {self.batch_attempt + 1} 次)...")
                    QTimer.singleShot(200, self._batch_step_kaptcha_list)
                log_error(f"批量检索未匹配到有效记录 (未找到: {not_found}, 验证码错误: {captcha_fails})")
                self._emit_error("批量检索未匹配到有效记录，请检查备案编号或重试。")
                return

            log_success(f"批量列表检索阶段完成，共命中 {len(hits)}/{len(self.batch_records)} 款产品，进入详情拉取阶段...")
            self._batch_step_kaptcha_detail(hits)
        except Exception as e:
            log_error(f"批量列表响应解析异常: {e}")
            self._emit_error(f"批量解析异常: {e}")

    def _batch_step_kaptcha_detail(self, hits: list):
        self.sig_status.emit(f"已命中 {len(hits)} 款产品，正在并发申请各产品详情验证码...")
        log_info(f"为 {len(hits)} 款命中产品并发申请详情验证码...")
        n = len(hits)
        js = f"""(async () => {{
            window.__ks_batch_d = null;
            const fetchK = async (idx) => {{
                const controller = new AbortController();
                const tid = setTimeout(() => controller.abort(), 12000);
                try {{
                    const r = await fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/kaptcha', {{ signal: controller.signal }});
                    clearTimeout(tid);
                    const d = await r.json();
                    return {{ idx, ok: true, data: d }};
                }} catch(e) {{
                    clearTimeout(tid);
                    return {{ idx, ok: false, error: e.toString() }};
                }}
            }};
            const ks = await Promise.all({list(range(n))}.map(fetchK));
            window.__ks_batch_d = JSON.stringify(ks);
        }})();"""
        self.engine.run_js(js)
        self._poll_js_var("__ks_batch_d", lambda s: self._batch_on_kaptcha_detail(s, hits), max_wait_sec=20.0,
                          on_timeout=lambda: self._batch_step_kaptcha_detail(hits))

    def _batch_on_kaptcha_detail(self, res_str: str, hits: list):
        try:
            ks = json.loads(res_str)
            tasks = []
            for i, h in enumerate(hits):
                k = ks[i]
                if not k.get("ok"):
                    log_warn(f"产品《{h['prod_name']}》详情验证码申请失败: {k.get('error')}")
                    continue
                token = k.get("data", {}).get("captchaKey")
                img_b64 = k.get("data", {}).get("base64Img", "").split(",")[-1]
                code = self.ocr.classification(base64.b64decode(img_b64)).strip()
                log_info(f"产品《{h['prod_name']}》详情验证码 OCR: '{code}' (Token: {str(token)[:10]}...)")
                tasks.append({
                    "idx": h["idx"],
                    "rec": h["rec"],
                    "prod_id": h["prod_id"],
                    "prod_name": h["prod_name"],
                    "token": token,
                    "code": code,
                    "gb": h["gb"]
                })

            if not tasks:
                log_warn("所有详情验证码申请均失败，重新获取...")
                QTimer.singleShot(200, lambda: self._batch_step_kaptcha_detail(hits))
                return

            self.sig_status.emit(f"正在拉取 {len(tasks)} 款产品的全量档案详情 (getProdInfo)...")
            log_info(f"正在发起 getProdInfo 请求 (共 {len(tasks)} 款产品，每批 3 个并发)...")

            js = f"""(async () => {{
                window.__batch_details_res = null;
                const tasks = {json.dumps(tasks)};
                const fetchOne = async (t) => {{
                    const controller = new AbortController();
                    const tid = setTimeout(() => controller.abort(), 15000);
                    try {{
                        const pProd = fetch('/HZPBZCX/PTHZPBA-SERVER/gsxxcx/getProdInfo', {{
                            method: 'POST',
                            headers: {{'Content-Type': 'application/json;charset=UTF-8'}},
                            body: JSON.stringify({{ prodId: t.prod_id, gb: t.gb, token: t.token, dataCode: t.code }}),
                            signal: controller.signal
                        }}).then(r => r.json());

                        const pGxxc = fetch('/HZPBZCX/PTHZPBA-SERVER/gxxc/getGxxcInfo', {{
                            method: 'POST',
                            headers: {{'Content-Type': 'application/json;charset=UTF-8'}},
                            body: JSON.stringify({{ prodId: t.prod_id, gb: t.gb }}),
                            signal: controller.signal
                        }}).then(r => r.json()).catch(e => null);

                        const [dProd, dGxxc] = await Promise.all([pProd, pGxxc]);
                        clearTimeout(tid);
                        return {{ rec: t.rec, name: t.prod_name, ok: true, d: dProd, gxxc: dGxxc }};
                    }} catch(e) {{
                        clearTimeout(tid);
                        return {{ rec: t.rec, name: t.prod_name, ok: false, error: e.toString() }};
                    }}
                }};
                const results = [];
                for (let i = 0; i < tasks.length; i += 3) {{
                    const chunk = tasks.slice(i, i + 3);
                    const chunkRes = await Promise.all(chunk.map(fetchOne));
                    results.push(...chunkRes);
                }}
                window.__batch_details_res = JSON.stringify(results);
            }})();"""
            self.engine.run_js(js)
            self._poll_js_var("__batch_details_res", self._batch_on_details_res, max_wait_sec=35.0,
                              on_timeout=lambda: (
                                  log_error("获取批量详情超时 (35s)"),
                                  self._emit_error("获取批量详情超时，请检查网络或在「⚙️ 代理设置」中重新提取新 IP 后再次重试。")
                              ))
        except Exception as e:
            log_error(f"批量详情任务构建异常: {e}")
            QTimer.singleShot(200, lambda: self._batch_step_kaptcha_detail(hits))

    def _batch_on_details_res(self, res_str: str):
        try:
            details_list = json.loads(res_str)
            all_results = []
            failed_items = []

            def format_list(ids):
                if not ids or not isinstance(ids, list):
                    return []
                return [{"id": x, "url": f"{PREVIEW_URL}{x}"} for x in ids if x]

            for item in details_list:
                rec = item["rec"]
                prod_name = item.get("name")
                if not item.get("ok"):
                    log_warn(f"产品《{prod_name}》({rec}) 详情请求失败: {item.get('error')}")
                    failed_items.append(rec)
                    continue

                detail = item.get("d", {})
                if isinstance(detail, dict) and (detail.get("msg") == "1" or "验证码" in str(detail.get("msg", ""))):
                    log_warn(f"产品《{prod_name}》({rec}) 详情验证码校验未通过: {detail.get('msg')}")
                    failed_items.append(rec)
                    continue

                file_ids = detail.get("fileIdList") or {}
                dzbq_ids = detail.get("dzbq") or {}

                gxxc_raw = item.get("gxxc")
                gxxc_info = parse_gxxc_data(gxxc_raw)

                res_dict = {
                    "record_no": rec,
                    "product_name": detail.get("prodName", prod_name),
                    "product_name_en": detail.get("prodNameEn", ""),
                    "is_children": detail.get("sfetcp") == "是",
                    "record_date": detail.get("recordDate", ""),
                    "shelf_life": detail.get("syqx", ""),
                    "status": "正常在售（有效）" if not detail.get("offdate") else f"已注销 ({detail.get('offdate')})",
                    "enterprise": detail.get("entName", ""),
                    "enterprise_addr": detail.get("entAddr", ""),
                    "manufacturer": detail.get("productEnt", ""),
                    "responsible_person": detail.get("jnzrrName", ""),
                    "components": detail.get("component", ""),
                    "formula_list": detail.get("formulaList", []),
                    "usage": detail.get("syff", ""),
                    "caution": detail.get("aqjsyy", ""),
                    "storage": detail.get("zctj", ""),
                    "history": detail.get("history", ""),
                    "annual_report": detail.get("remark", ""),
                    "efficacy_claims": gxxc_info.get("claims", "常规护理/基础修饰"),
                    "efficacy_info": gxxc_info,
                    "attachments": {
                        "pmt": format_list(file_ids.get("pmt")),
                        "ltt": format_list(file_ids.get("ltt")),
                        "sms": format_list(file_ids.get("sms")),
                        "dzbq": format_list(dzbq_ids.get("sms")),
                    }
                }
                all_results.append(res_dict)
                log_success(f"成功规整档案: 《{res_dict['product_name']}》({rec})，配方: {len(res_dict['formula_list'])} 项，图纸: {len(res_dict['attachments']['pmt'])} 张平面图/{len(res_dict['attachments']['ltt'])} 张立体图")

            if not all_results:
                log_error(f"批量详情获取全部失败 (失败列表: {failed_items})")
                self._emit_error("获取批量详情失败，详情验证码校验未通过或网络超时，请重试。")
                return

            log_success(f"批量详情规整完成，成功 {len(all_results)} 款产品！立即展示档案。")

            # 1. 立即发出批量成功信号，让界面毫秒级展示全部产品信息与下拉列表，彻底杜绝主界面卡死
            self._emit_batch_success(all_results)

            # 2. 在后台静默预提取包装图纸附件（完全非阻塞，逐个入库并由后台线程渲染）
            batch_fids = []
            for res_dict in all_results:
                atts = res_dict.get("attachments", {})
                for k in ("pmt", "ltt", "sms"):
                    for it in atts.get(k, []):
                        fid = it.get("id")
                        if fid and str(fid) not in ATTACHMENT_CACHE and str(fid) not in batch_fids:
                            batch_fids.append(str(fid))

            if batch_fids:
                log_info(f"档案已规整，启动后台异步提取 {len(batch_fids)} 份包装高清图纸...")
                self._start_background_prefetch(batch_fids)
        except Exception as e:
            log_error(f"批量数据规整异常: {e}")
            self._emit_error(f"批量数据规整异常: {e}")

    def _emit_batch_success(self, all_results: list):
        self.is_querying = False
        log_success(f"🎉 批量并发归档成功！共完成 {len(all_results)} 款产品。")
        self.sig_status.emit(f"🎉 批量并发归档成功！共完成 {len(all_results)} 款产品。")
        self.sig_batch_success.emit(all_results)

    def _start_background_prefetch(self, fids: list[str]):
        """后台静默提取包装图纸附件：直连优先（快），失败回落引擎代理通道。"""
        new_fids = [str(f) for f in fids if f and str(f) not in ATTACHMENT_CACHE and str(f) not in IN_PROGRESS_FIDS]
        if not new_fids:
            return
        for fid in new_fids:
            self._fetch_direct_first(fid)

    def _fetch_direct_first(self, fid: str):
        """直连优先：先 Python requests 直连，失败自动回落原代理通道。"""
        fid = str(fid)
        if fid in ATTACHMENT_CACHE or fid in IN_PROGRESS_FIDS:
            return
        started = request_direct_download(
            fid, self.engine.get_cookie_dict_sync, self._fetch_one_prefetch)
        if not started:
            return

    def _pump_prefetch_queue(self):
        """按并发上限启动预取任务（保留兼容：直连路径不经此队列）"""
        while self.prefetch_queue and self.prefetch_active < self.prefetch_max_concurrent:
            fid = str(self.prefetch_queue.pop(0))
            if fid in ATTACHMENT_CACHE:
                IN_PROGRESS_FIDS.discard(fid)
                continue
            # 直连优先：失败自动回落 _fetch_one_prefetch（代理通道）
            IN_PROGRESS_FIDS.discard(fid)
            self._fetch_direct_first(fid)

    def _release_prefetch_slot(self):
        self.prefetch_active = max(0, self.prefetch_active - 1)
        # 有空闲槽位就继续 pumped，未完成任务不占用轮询等待
        QTimer.singleShot(80, self._pump_prefetch_queue)

    def _fetch_one_prefetch(self, fid: str):
        fid = str(fid)
        if fid in ATTACHMENT_CACHE:
            return
        IN_PROGRESS_FIDS.add(fid)
        self.engine.run_js(f"window['__pf_{fid}'] = null;")

        js = f"""(async () => {{
            const fid = '{fid}';
            window['__pf_' + fid] = null;
            const controller = new AbortController();
            const tid = setTimeout(() => controller.abort(), 25000);
            try {{
                const r = await fetch('/HZPBZCX/PTHZPBA-SERVER/nmpafile/gsxxFilePreview?attachmentId=' + fid, {{
                    signal: controller.signal
                }});
                clearTimeout(tid);
                if (!r.ok) {{
                    window['__pf_' + fid] = JSON.stringify({{ ok: false, error: 'HTTP ' + r.status }});
                    return;
                }}
                const b = await r.blob();
                const rd = new FileReader();
                rd.onloadend = () => {{
                    window['__pf_' + fid] = JSON.stringify({{ ok: true, mime: b.type, data: rd.result }});
                }};
                rd.readAsDataURL(b);
            }} catch(e) {{
                clearTimeout(tid);
                window['__pf_' + fid] = JSON.stringify({{ ok: false, error: e.toString() }});
            }}
        }})();"""
        self.engine.run_js(js)
        QTimer.singleShot(150, lambda: self._poll_prefetch_fid(fid, 0))

    def _poll_prefetch_fid(self, fid: str, waited_ms: int = 0):
        def on_eval(res_str):
            if not res_str:
                if waited_ms < 25000:
                    QTimer.singleShot(200, lambda: self._poll_prefetch_fid(fid, waited_ms + 200))
                    return
                # 超时，清理并释放槽位
                self.engine.run_js(f"window['__pf_{fid}'] = null;")
                IN_PROGRESS_FIDS.discard(fid)
                log_warn(f"[Attachment Prefetch] 附件 {fid} 提取超时")
                self._release_prefetch_slot()
                return

            try:
                self.engine.run_js(f"window['__pf_{fid}'] = null;")
                d = json.loads(res_str)
                if d.get("ok"):
                    mime = d.get("mime", "")
                    data_url = d.get("data", "")
                    raw = base64.b64decode(data_url.split(",")[-1])
                    ATTACHMENT_CACHE[fid] = {"mime": mime, "raw": raw}
                    attachment_hub.sig_attachment_loaded.emit(fid)
                    request_thumbnail_worker(fid, raw, mime)
                    preheat_preview_worker(fid, raw, mime)
                    log_info(f"[Attachment Prefetch] 附件 {fid} 同步缓存成功 ({len(raw)/1024/1024:.1f}MB)")
                else:
                    log_warn(f"[Attachment Prefetch] 附件 {fid} 提取未完成: {d.get('error')}")
            except Exception as e:
                log_error(f"[Attachment Prefetch] 附件 {fid} 解析异常: {e}")
            finally:
                IN_PROGRESS_FIDS.discard(fid)
                self._release_prefetch_slot()

        self.engine.run_js(f"window['__pf_{fid}']", on_eval)


class ClickableLabel(QLabel):
    """可点击的缩略图标签"""
    clicked = Signal()

    def __init__(self, text=""):
        super().__init__(text)
        self.setCursor(Qt.PointingHandCursor)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(ev)


class SmoothImageViewer(QGraphicsView):
    """
    高性能超清图像画廊视口组件 (基于 QGraphicsView 场景图与局部视口裁剪加速)
    - 60/120 FPS 满帧丝滑抓手平移 (ScrollHandDrag)
    - 鼠标滚轮/触控板以鼠标光标所在点为焦点无级平滑缩放
    - 默认智能自适应窗口 (Fit to Window)，双击快速在适应与 1:1 原始尺寸间切换
    - 杜绝传统 QScrollArea + QLabel 造成的全屏重绘卡顿与掉帧
    """
    sig_scale_changed = Signal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.pixmap_item = QGraphicsPixmapItem()
        self.scene.addItem(self.pixmap_item)

        if QOpenGLWidget is not None:
            try:
                gl_widget = QOpenGLWidget()
                self.setViewport(gl_widget)
            except Exception as e:
                print(f"[SmoothImageViewer] QOpenGLWidget init fallback: {e}")

        self.setRenderHint(QPainter.SmoothPixmapTransform, True)
        self.setRenderHint(QPainter.Antialiasing, True)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self.setViewportUpdateMode(QGraphicsView.SmartViewportUpdate)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setFrameShape(QFrame.NoFrame)

        # 质感深灰背景突出图纸边界与质感
        self.setBackgroundBrush(QBrush(QColor("#18181B")))

        self._zoom_factor = 1.0
        self._current_pixmap = None
        self._is_fit_mode = True

    def set_pixmap(self, pixmap: QPixmap, keep_view: bool = False):
        if not pixmap or pixmap.isNull():
            return
        self._current_pixmap = pixmap
        self.pixmap_item.setPixmap(pixmap)
        self.scene.setSceneRect(QRectF(pixmap.rect()))
        if not keep_view:
            self.fit_to_window()
        else:
            self.sig_scale_changed.emit(self._zoom_factor)

    def fit_to_window(self):
        """自适应缩放到当前视口窗口尺寸，完整呈现整张图纸"""
        if not self._current_pixmap or self._current_pixmap.isNull():
            return
        self.resetTransform()
        rect = self.scene.sceneRect()
        if rect.isEmpty():
            return
        vw = max(10, self.viewport().width() - 32)
        vh = max(10, self.viewport().height() - 32)
        sw = rect.width()
        sh = rect.height()
        factor = min(vw / sw, vh / sh, 1.0)
        self.scale(factor, factor)
        self._zoom_factor = factor
        self._is_fit_mode = True
        self.sig_scale_changed.emit(self._zoom_factor)

    def reset_zoom(self):
        """重置为 100% 原始尺寸 (1:1 像素级细节)"""
        if not self._current_pixmap or self._current_pixmap.isNull():
            return
        self.resetTransform()
        self._zoom_factor = 1.0
        self._is_fit_mode = False
        self.sig_scale_changed.emit(self._zoom_factor)

    def zoom_in(self):
        self.zoom_by(1.25)

    def zoom_out(self):
        self.zoom_by(0.8)

    def zoom_by(self, factor: float):
        new_factor = self._zoom_factor * factor
        if 0.05 <= new_factor <= 15.0:
            self.scale(factor, factor)
            self._zoom_factor = new_factor
            self._is_fit_mode = False
            self.sig_scale_changed.emit(self._zoom_factor)

    def rotate_clockwise(self):
        """顺时针旋转 90 度"""
        self.rotate(90)

    def wheelEvent(self, event):
        """滚轮以光标所在点平滑缩放"""
        delta = event.angleDelta().y()
        if delta != 0:
            factor = 1.15 if delta > 0 else 0.85
            self.zoom_by(factor)
            event.accept()
        else:
            super().wheelEvent(event)

    def mouseDoubleClickEvent(self, event):
        """双击在自适应窗口与 1:1 原始尺寸之间切换"""
        if event.button() == Qt.LeftButton:
            if self._is_fit_mode:
                self.reset_zoom()
            else:
                self.fit_to_window()
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._is_fit_mode:
            self.fit_to_window()


class ImagePreviewDialog(QDialog):
    """图纸与高清附件大图预览弹窗 (支持 GPU 局部加速丝滑平移、滚轮缩放、自适应与多页浏览)"""
    def __init__(self, title: str, raw_data: bytes, mime_type: str, file_id: str, parent=None):
        super().__init__(parent)
        self.title_text = title
        self.raw_data = raw_data
        self.mime_type = mime_type
        self.file_id = str(file_id)
        self.doc = None
        self.current_page = 0
        self.total_pages = 1

        self.setWindowTitle(f"附件查看 - {self.title_text}")
        self.resize(960, 780)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        # 顶部工具栏
        top_bar = QHBoxLayout()
        top_bar.setSpacing(8)

        title_lbl = QLabel(f"<b>{self.title_text}</b>")
        title_lbl.setStyleSheet("font-size: 14px; color: #1E293B;")
        top_bar.addWidget(title_lbl)

        id_lbl = QLabel(f"(ID: {self.file_id})")
        id_lbl.setStyleSheet("font-size: 12px; color: #64748B;")
        top_bar.addWidget(id_lbl)

        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color: #3B82F6; font-size: 12px; font-weight: 500; margin-left: 6px;")
        top_bar.addWidget(self.lbl_status)

        top_bar.addStretch()

        # 视图缩放与控制按钮组
        control_style = """
            QPushButton {
                background-color: #F1F5F9; color: #334155;
                border: 1px solid #E2E8F0; border-radius: 6px;
                padding: 5px 10px; font-size: 12px; font-weight: 500;
            }
            QPushButton:hover { background-color: #E2E8F0; color: #0F172A; }
            QPushButton:pressed { background-color: #CBD5E1; }
        """

        self.btn_fit = QPushButton("适应窗口")
        self.btn_fit.setCursor(Qt.PointingHandCursor)
        self.btn_fit.setStyleSheet(control_style)
        self.btn_fit.clicked.connect(self._on_fit_clicked)
        top_bar.addWidget(self.btn_fit)

        self.btn_orig = QPushButton("1:1 原图")
        self.btn_orig.setCursor(Qt.PointingHandCursor)
        self.btn_orig.setStyleSheet(control_style)
        self.btn_orig.clicked.connect(self._on_orig_clicked)
        top_bar.addWidget(self.btn_orig)

        self.btn_zoom_out = QPushButton("➖")
        self.btn_zoom_out.setToolTip("缩小 (滚轮向后)")
        self.btn_zoom_out.setCursor(Qt.PointingHandCursor)
        self.btn_zoom_out.setStyleSheet(control_style)
        self.btn_zoom_out.clicked.connect(self._on_zoom_out_clicked)
        top_bar.addWidget(self.btn_zoom_out)

        self.lbl_zoom = QLabel("100%")
        self.lbl_zoom.setStyleSheet("font-size: 12px; color: #475569; font-weight: 600; min-width: 44px;")
        self.lbl_zoom.setAlignment(Qt.AlignCenter)
        top_bar.addWidget(self.lbl_zoom)

        self.btn_zoom_in = QPushButton("➕")
        self.btn_zoom_in.setToolTip("放大 (滚轮向前)")
        self.btn_zoom_in.setCursor(Qt.PointingHandCursor)
        self.btn_zoom_in.setStyleSheet(control_style)
        self.btn_zoom_in.clicked.connect(self._on_zoom_in_clicked)
        top_bar.addWidget(self.btn_zoom_in)

        self.btn_rotate = QPushButton("🔄 旋转90°")
        self.btn_rotate.setCursor(Qt.PointingHandCursor)
        self.btn_rotate.setStyleSheet(control_style)
        self.btn_rotate.clicked.connect(self._on_rotate_clicked)
        top_bar.addWidget(self.btn_rotate)

        # PDF 多页控制
        self.btn_prev = QPushButton("◀ 上一页")
        self.btn_next = QPushButton("下一页 ▶")
        self.lbl_page = QLabel("1 / 1")
        self.btn_prev.setCursor(Qt.PointingHandCursor)
        self.btn_next.setCursor(Qt.PointingHandCursor)
        self.btn_prev.setStyleSheet(control_style)
        self.btn_next.setStyleSheet(control_style)
        self.lbl_page.setStyleSheet("color: #475569; font-weight: bold; padding: 0 6px; font-size: 12px;")
        self.btn_prev.clicked.connect(self.prev_page)
        self.btn_next.clicked.connect(self.next_page)
        top_bar.addWidget(self.btn_prev)
        top_bar.addWidget(self.lbl_page)
        top_bar.addWidget(self.btn_next)

        btn_save = QPushButton("保存到本地")
        btn_save.setCursor(Qt.PointingHandCursor)
        btn_save.setStyleSheet("""
            QPushButton {
                background-color: #007AFF; color: #FFFFFF;
                border: none; border-radius: 6px; padding: 6px 14px;
                font-size: 12px; font-weight: bold;
            }
            QPushButton:hover { background-color: #0062CC; }
            QPushButton:pressed { background-color: #0051A8; }
        """)
        btn_save.clicked.connect(self.save_file)
        top_bar.addWidget(btn_save)

        layout.addLayout(top_bar)

        # 高性能视口区
        self.viewer = SmoothImageViewer(self)
        self.viewer.sig_scale_changed.connect(self._on_viewer_scale_changed)
        self.viewer.setStyleSheet("border: 1px solid #CBD5E1; border-radius: 8px;")
        layout.addWidget(self.viewer, stretch=1)

        # 底部状态与操作手势提示
        bottom_bar = QHBoxLayout()
        hint_lbl = QLabel("💡 提示：按住鼠标左键可自由拖拽平移，滚轮以光标为中心缩放，双击在适应全屏与1:1细节间切换")
        hint_lbl.setStyleSheet("color: #94A3B8; font-size: 11px;")
        bottom_bar.addWidget(hint_lbl)
        bottom_bar.addStretch()
        layout.addLayout(bottom_bar)

        # 立即展示已有缩略图作为占位 (实现 0 延迟秒开弹窗，无任何卡顿)
        if self.file_id in THUMBNAIL_CACHE:
            thumb_pix, kind, _ = THUMBNAIL_CACHE[self.file_id]
            if thumb_pix and not thumb_pix.isNull():
                self.viewer.set_pixmap(thumb_pix)

        self.load_content()

    def _on_viewer_scale_changed(self, factor: float):
        pct = int(round(factor * 100))
        self.lbl_zoom.setText(f"{pct}%")

    def _on_fit_clicked(self):
        self.viewer.fit_to_window()

    def _on_orig_clicked(self):
        self.viewer.reset_zoom()

    def _on_zoom_in_clicked(self):
        self.viewer.zoom_in()

    def _on_zoom_out_clicked(self):
        self.viewer.zoom_out()

    def _on_rotate_clicked(self):
        self.viewer.rotate_clockwise()

    def load_content(self):
        if not self.raw_data:
            self.lbl_status.setText("无文件数据")
            return

        cache_key = (self.file_id, self.current_page)
        if cache_key in PREVIEW_CACHE:
            self.viewer.set_pixmap(PREVIEW_CACHE[cache_key], keep_view=False)
            self.lbl_status.setText("")
            self._update_page_controls()
            return

        self.lbl_status.setText("🔍 正在渲染高清视图...")
        worker = PreviewWorker(self.raw_data, self.mime_type, self.current_page)
        ACTIVE_WORKERS.add(worker)

        def on_done(page_idx, qimg, total_pages):
            ACTIVE_WORKERS.discard(worker)
            self._on_preview_finished(page_idx, qimg, total_pages)

        def on_err(page_idx, err_msg):
            ACTIVE_WORKERS.discard(worker)
            self._on_preview_error(page_idx, err_msg)

        worker.signals.finished.connect(on_done)
        worker.signals.error.connect(on_err)
        QThreadPool.globalInstance().start(worker)

    def _on_preview_finished(self, page_idx: int, qimg: QImage, total_pages: int):
        self.total_pages = total_pages
        if qimg and not qimg.isNull():
            pix = QPixmap.fromImage(qimg)
            PREVIEW_CACHE[(self.file_id, page_idx)] = pix
            if page_idx == self.current_page:
                self.viewer.set_pixmap(pix, keep_view=False)
                self.lbl_status.setText(f"✨ 高清已就绪 ({pix.width()}×{pix.height()})")
                self.lbl_status.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 500; margin-left: 6px;")

        self._update_page_controls()

    def _on_preview_error(self, page_idx: int, err_msg: str):
        self.lbl_status.setText(f"高清渲染提示: {err_msg}")

    def _update_page_controls(self):
        if self.total_pages > 1:
            self.btn_prev.show()
            self.btn_next.show()
            self.lbl_page.show()
            self.lbl_page.setText(f"{self.current_page + 1} / {self.total_pages}")
            self.btn_prev.setEnabled(self.current_page > 0)
            self.btn_next.setEnabled(self.current_page < self.total_pages - 1)
        else:
            self.btn_prev.hide()
            self.btn_next.hide()
            self.lbl_page.hide()

    def prev_page(self):
        if self.current_page > 0:
            self.current_page -= 1
            self.load_content()

    def next_page(self):
        if self.current_page < self.total_pages - 1:
            self.current_page += 1
            self.load_content()

    def save_file(self):
        is_pdf = "pdf" in self.mime_type or self.raw_data.startswith(b"%PDF")
        ext = ".pdf" if is_pdf else ".jpg"
        path, _ = QFileDialog.getSaveFileName(self, "保存文件", f"{self.title_text}_{self.file_id}{ext}")
        if path:
            with open(path, "wb") as f:
                f.write(self.raw_data)
            QMessageBox.information(self, "成功", f"文件已保存至:\n{path}")


class ProxySettingsDialog(QDialog):
    """网络通道与动态代理配置对话框"""
    def __init__(self, parent=None, on_applied=None):
        super().__init__(parent)
        self.on_applied = on_applied
        self.setWindowTitle("网络通道与动态代理设置")
        self.setFixedSize(600, 560)
        self.setModal(True)
        self.cfg = NetworkManager.load_config()
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)

        # 头部说明
        header = QLabel("⚙️ 备案查询通道设置")
        header.setStyleSheet("font-size: 16px; font-weight: 700; color: #0F172A;")
        layout.addWidget(header)

        sub = QLabel("药监局 NMPA 对高频查询具备严格 IP 防护。推荐优先使用【原生直连】；若本机 IP 受限可随时无缝切换为【动态代理】。")
        sub.setStyleSheet("font-size: 12px; color: #64748B; line-height: 1.4;")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        # 模式选择
        mode_box = QGroupBox("工作模式")
        mode_box.setStyleSheet("""
            QGroupBox {
                font-size: 12px;
                font-weight: 600;
                color: #334155;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                margin-top: 8px;
                padding-top: 14px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
            }
        """)
        mode_layout = QVBoxLayout(mode_box)
        mode_layout.setSpacing(10)
        mode_layout.setContentsMargins(14, 12, 14, 14)

        self.radio_direct = QRadioButton("🌐 原生直连模式 (默认推荐，直接通过本机网络发起请求，无需消耗代理额度)")
        self.radio_proxy = QRadioButton("⚡ 动态代理 API 模式 (可选，从服务商接口自动拉取高匿 IP 防封)")

        radio_style = """
            QRadioButton {
                font-size: 12px;
                color: #1E293B;
                spacing: 8px;
            }
            QRadioButton::indicator {
                width: 16px;
                height: 16px;
            }
        """
        self.radio_direct.setStyleSheet(radio_style)
        self.radio_proxy.setStyleSheet(radio_style)

        current_mode = self.cfg.get("mode", "direct")
        if current_mode == "proxy":
            self.radio_proxy.setChecked(True)
        else:
            self.radio_direct.setChecked(True)

        mode_layout.addWidget(self.radio_direct)
        mode_layout.addWidget(self.radio_proxy)
        layout.addWidget(mode_box)

        # API 地址输入区 (始终保持交互可用，方便用户随时查看与配置备用代理)
        self.api_box = QGroupBox("动态代理提取接口 (API URL)")
        self.api_box.setStyleSheet("""
            QGroupBox {
                font-size: 12px;
                font-weight: 600;
                color: #334155;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                margin-top: 8px;
                padding-top: 14px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
            }
        """)
        api_layout = QVBoxLayout(self.api_box)
        api_layout.setSpacing(8)
        api_layout.setContentsMargins(14, 12, 14, 14)

        self.input_api = QLineEdit()
        self.input_api.setFixedHeight(36)
        self.input_api.setPlaceholderText("请输入代理 API 提取链接，如: https://api.douyadaili.com/proxy/...")
        initial_api = (self.cfg.get("api_url") or "").strip()
        if not initial_api:
            initial_api = DEFAULT_PROXY_API
        self.input_api.setText(initial_api)
        self.input_api.setCursorPosition(0)
        self.input_api.setClearButtonEnabled(True)
        self.input_api.setStyleSheet("""
            QLineEdit {
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 6px 32px 6px 12px;
                font-size: 12px;
                font-family: Menlo, Monaco, Consolas, monospace;
                background-color: #FFFFFF;
                color: #0F172A;
            }
            QLineEdit:hover {
                border-color: #94A3B8;
            }
            QLineEdit:focus {
                border: 1.5px solid #007AFF;
                background-color: #FFFFFF;
            }
        """)
        api_layout.addWidget(self.input_api)

        # 辅助快捷操作行
        action_row = QHBoxLayout()
        action_row.setSpacing(12)

        btn_reset_default = QPushButton("↺ 填入官方推荐不限流 API")
        btn_reset_default.setCursor(Qt.PointingHandCursor)
        btn_reset_default.setStyleSheet("""
            QPushButton {
                border: none;
                color: #007AFF;
                font-size: 11px;
                font-weight: 500;
                text-align: left;
                padding: 2px 0;
            }
            QPushButton:hover {
                color: #0056B3;
                text-decoration: underline;
            }
        """)
        btn_reset_default.clicked.connect(self._reset_to_default_api)
        action_row.addWidget(btn_reset_default)

        btn_quick_test_api = QPushButton("⚡ 仅测试此 API 提取")
        btn_quick_test_api.setCursor(Qt.PointingHandCursor)
        btn_quick_test_api.setStyleSheet("""
            QPushButton {
                border: none;
                color: #475569;
                font-size: 11px;
                text-align: left;
                padding: 2px 0;
            }
            QPushButton:hover {
                color: #0F172A;
                text-decoration: underline;
            }
        """)
        btn_quick_test_api.clicked.connect(self._test_proxy_api_only)
        action_row.addWidget(btn_quick_test_api)

        action_row.addStretch()
        api_layout.addLayout(action_row)

        self.lbl_api_hint = QLabel()
        self.lbl_api_hint.setStyleSheet("font-size: 11px; color: #64748B;")
        self.lbl_api_hint.setWordWrap(True)
        api_layout.addWidget(self.lbl_api_hint)

        layout.addWidget(self.api_box)

        # 探测结果反馈面板
        self.card_status = QFrame()
        self.card_status.setStyleSheet("""
            QFrame {
                background-color: #F8FAFC;
                border: 1px solid #E2E8F0;
                border-radius: 6px;
                padding: 8px 12px;
            }
        """)
        card_layout = QVBoxLayout(self.card_status)
        card_layout.setContentsMargins(6, 6, 6, 6)
        last_node = self.cfg.get("last_node", "本机直连")
        self.lbl_feedback = QLabel(f"当前节点记录: {last_node} (就绪)")
        self.lbl_feedback.setStyleSheet("font-size: 11px; color: #475569;")
        self.lbl_feedback.setWordWrap(True)
        card_layout.addWidget(self.lbl_feedback)
        layout.addWidget(self.card_status)

        # 版本更新与同步源配置 (选填)
        update_box = QGroupBox("版本同步源 (开发者/更新通道设置)")
        update_box.setStyleSheet("""
            QGroupBox {
                font-size: 12px;
                font-weight: 600;
                color: #334155;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                margin-top: 4px;
                padding-top: 12px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
            }
        """)
        up_layout = QVBoxLayout(update_box)
        up_layout.setContentsMargins(12, 10, 12, 10)
        up_layout.setSpacing(6)

        self.input_update_url = QLineEdit()
        self.input_update_url.setFixedHeight(30)
        self.input_update_url.setPlaceholderText("留空使用默认源，或填入您的 Gitee / GitHub / 自建服务器 manifest.json 链接")
        self.input_update_url.setText(self.cfg.get("update_server_url", ""))
        self.input_update_url.setStyleSheet("""
            QLineEdit {
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 4px 10px;
                font-size: 11px;
                background-color: #FFFFFF;
                color: #0F172A;
            }
        """)
        up_layout.addWidget(self.input_update_url)
        layout.addWidget(update_box)

        # 底部操作栏
        btn_bar = QHBoxLayout()
        self.btn_test = QPushButton("⚡ 测试连通性")
        self.btn_test.setFixedHeight(34)
        self.btn_test.setCursor(Qt.PointingHandCursor)
        self.btn_test.setStyleSheet("""
            QPushButton {
                background-color: #F1F5F9;
                color: #1E293B;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 0 14px;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #E2E8F0;
            }
        """)
        self.btn_test.clicked.connect(self.do_test)

        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setFixedHeight(34)
        self.btn_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_cancel.setStyleSheet("""
            QPushButton {
                background-color: #F1F5F9;
                color: #64748B;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 0 14px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #E2E8F0;
            }
        """)
        self.btn_cancel.clicked.connect(self.reject)

        self.btn_apply = QPushButton("💾 保存并立即应用")
        self.btn_apply.setFixedHeight(34)
        self.btn_apply.setCursor(Qt.PointingHandCursor)
        self.btn_apply.setStyleSheet("""
            QPushButton {
                background-color: #007AFF;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 0 16px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #0062CC;
            }
        """)
        self.btn_apply.clicked.connect(self.do_apply)

        btn_bar.addWidget(self.btn_test)
        btn_bar.addStretch()
        btn_bar.addWidget(self.btn_cancel)
        btn_bar.addWidget(self.btn_apply)
        layout.addLayout(btn_bar)

        # 联动控制模式反馈
        self.radio_proxy.toggled.connect(self._on_mode_changed)
        self.radio_direct.toggled.connect(self._on_mode_changed)
        self._on_mode_changed()

    def _reset_to_default_api(self):
        self.input_api.setText(DEFAULT_PROXY_API)
        self.input_api.setCursorPosition(0)
        self.input_api.setFocus()
        self.lbl_feedback.setText("↺ 已重置为官方推荐不限流 API 地址")
        self.lbl_feedback.setStyleSheet("font-size: 11px; color: #2563EB;")

    def _test_proxy_api_only(self):
        api_url = self.input_api.text().strip()
        if not api_url:
            self.lbl_feedback.setText("❌ 请先输入有效的代理 API 链接！")
            self.lbl_feedback.setStyleSheet("font-size: 11px; color: #DC2626;")
            return

        self.btn_test.setEnabled(False)
        self.lbl_feedback.setText("⏳ 正在请求 API 提取 IP 并测试与 NMPA 连通性...")
        self.lbl_feedback.setStyleSheet("font-size: 11px; color: #4338CA;")
        QApplication.processEvents()

        ok, msg, node = NetworkManager.test_proxy_api(api_url)
        self.btn_test.setEnabled(True)
        if ok:
            self.lbl_feedback.setText(f"✅ 代理 API 探测成功！\n代理节点: {node}\n{msg}")
            self.lbl_feedback.setStyleSheet("font-size: 11px; color: #16A34A; font-weight: 500;")
        else:
            self.lbl_feedback.setText(f"❌ 代理 API 探测未通过:\n{msg}")
            self.lbl_feedback.setStyleSheet("font-size: 11px; color: #DC2626; font-weight: 500;")

    def _on_mode_changed(self):
        is_direct = self.radio_direct.isChecked()
        # 注意：API 输入框始终保持启用，方便用户查看与维护配置
        if is_direct:
            self.btn_test.setText("⚡ 测试本机直连连通性")
            self.lbl_feedback.setText("🌐 当前模式: 原生直连模式 (不使用代理，直接通过本机网络发起请求)")
            self.lbl_feedback.setStyleSheet("font-size: 11px; color: #2563EB;")
            self.lbl_api_hint.setText("💡 当前处于直连模式。此接口配置已留存备用，可随时编辑或切换为代理模式。")
            self.lbl_api_hint.setStyleSheet("font-size: 11px; color: #64748B;")
        else:
            self.btn_test.setText("⚡ 提取并测试代理连通性")
            last_node = self.cfg.get("last_node", "无")
            self.lbl_feedback.setText(f"当前节点记录: {last_node} (就绪)")
            self.lbl_feedback.setStyleSheet("font-size: 11px; color: #475569;")
            self.lbl_api_hint.setText("⚡ 已启用代理模式。查询药监局时将自动通过该 API 提取高匿动态代理。")
            self.lbl_api_hint.setStyleSheet("font-size: 11px; color: #D97706; font-weight: 500;")

    def do_test(self):
        if self.radio_direct.isChecked():
            self.btn_test.setEnabled(False)
            self.lbl_feedback.setText("⏳ 正在探测本机与国家药监局安全入口的直连连通性...")
            self.lbl_feedback.setStyleSheet("font-size: 11px; color: #4338CA;")
            QApplication.processEvents()
            ok, msg = NetworkManager.test_direct_connection()
            self.btn_test.setEnabled(True)
            if ok:
                self.lbl_feedback.setText(f"✅ 直连探测成功！\n{msg}")
                self.lbl_feedback.setStyleSheet("font-size: 11px; color: #16A34A; font-weight: 500;")
            else:
                self.lbl_feedback.setText(f"❌ 直连探测未通过:\n{msg}")
                self.lbl_feedback.setStyleSheet("font-size: 11px; color: #DC2626; font-weight: 500;")
            return

        self._test_proxy_api_only()

    def do_apply(self):
        mode = "direct" if self.radio_direct.isChecked() else "proxy"
        api_url = self.input_api.text().strip()
        if not api_url:
            api_url = DEFAULT_PROXY_API
        if mode == "proxy" and not api_url:
            QMessageBox.warning(self, "提示", "代理模式下请输入有效的代理 API 地址。")
            return

        cfg = {
            "mode": mode,
            "api_url": api_url,
            "last_node": "本机直连" if mode == "direct" else self.cfg.get("last_node", ""),
            "update_server_url": self.input_update_url.text().strip()
        }
        NetworkManager.save_config(cfg)

        if self.on_applied:
            self.on_applied(mode, api_url)

        self.accept()


class AttachmentCard(QFrame):
    """图纸与附件卡片组件 (支持高清首页缩略渲染与点击全尺寸浏览)"""
    def __init__(self, title: str, file_id: str, url: str, engine: EmbeddedNmpaEngine):
        super().__init__()
        self.title = title
        self.file_id = str(file_id)
        self.url = url
        self.engine = engine
        self.raw_data = None
        self.mime_type = ""
        self.poll_count = 0
        self.init_ui()

        # 监听全局事件总线
        attachment_hub.sig_thumbnail_ready.connect(self._on_hub_thumbnail_ready)
        attachment_hub.sig_attachment_loaded.connect(self._on_hub_attachment_loaded)

        # 0. 优先命中已渲染缩略图 (跨卡片切换 0 延迟秒开，彻底解决切换卡顿)
        if self.file_id in THUMBNAIL_CACHE:
            pix, kind, size_mb = THUMBNAIL_CACHE[self.file_id]
            if self.file_id in ATTACHMENT_CACHE:
                cached = ATTACHMENT_CACHE[self.file_id]
                self.raw_data = cached["raw"]
                self.mime_type = cached["mime"]
            self._apply_thumbnail(pix, kind, size_mb)
        # 1. 命中原始文件缓存，异步生成缩略图 (在后台线程计算，不卡主线程)
        elif self.file_id in ATTACHMENT_CACHE:
            cached = ATTACHMENT_CACHE[self.file_id]
            self.raw_data = cached["raw"]
            self.mime_type = cached["mime"]
            self.preview_lbl.setText("正在生成缩略图...")
            request_thumbnail_worker(self.file_id, self.raw_data, self.mime_type)
        # 2. 检查是否在后台下载队列中
        elif self.file_id in IN_PROGRESS_FIDS:
            self.preview_lbl.setText("正在下载图纸...")
        # 3. 独立触发加载
        else:
            self.load_thumbnail()

    def cleanup(self):
        """断开全局总线连接，防止已销毁控件被后台事件唤醒触发野指针访问"""
        try:
            attachment_hub.sig_thumbnail_ready.disconnect(self._on_hub_thumbnail_ready)
        except Exception:
            pass
        try:
            attachment_hub.sig_attachment_loaded.disconnect(self._on_hub_attachment_loaded)
        except Exception:
            pass

    def init_ui(self):
        self.setFrameShape(QFrame.StyledPanel)
        self.setStyleSheet("""
            AttachmentCard {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 12px;
                padding: 12px;
            }
            AttachmentCard:hover {
                border-color: #007AFF;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        # 顶部标题栏与类型标识
        head_layout = QHBoxLayout()
        title_label = QLabel(self.title)
        title_label.setFont(QFont("PingFang SC", 12, QFont.Bold))
        title_label.setStyleSheet("color: #0F172A;")
        title_label.setToolTip(self.title)
        title_label.setWordWrap(True)
        head_layout.addWidget(title_label, stretch=1)

        id_label = QLabel(f"ID: {self.file_id}")
        id_label.setFont(QFont("PingFang SC", 10))
        id_label.setStyleSheet("color: #94A3B8; font-family: monospace;")
        head_layout.addWidget(id_label)
        layout.addLayout(head_layout)

        # 缩略预览容器 (240x150 黄金视口比例)
        self.preview_lbl = ClickableLabel("正在加载图纸缩略图...")
        self.preview_lbl.setAlignment(Qt.AlignCenter)
        self.preview_lbl.setFixedSize(240, 150)
        self.preview_lbl.setToolTip("点击放大查看高清大图 (支持手势拖拽缩放)")
        self.preview_lbl.setStyleSheet("""
            background-color: #F8FAFC;
            border-radius: 8px;
            border: 1px solid #E2E8F0;
            color: #94A3B8;
            font-size: 11px;
        """)
        self.preview_lbl.clicked.connect(self.on_preview_clicked)
        layout.addWidget(self.preview_lbl, alignment=Qt.AlignCenter)

        # 按钮栏 (大图查看 + 保存附件 + 浏览器)
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(6)

        btn_view = QPushButton("🔍 查看大图")
        btn_view.setCursor(Qt.PointingHandCursor)
        btn_view.setStyleSheet("""
            QPushButton {
                background-color: #EFF6FF;
                color: #2563EB;
                border: 1px solid #BFDBFE;
                border-radius: 6px;
                padding: 6px 10px;
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #DBEAFE;
                color: #1D4ED8;
            }
        """)
        btn_view.clicked.connect(self.on_preview_clicked)

        self.btn_save = QPushButton("💾 下载原图")
        self.btn_save.setCursor(Qt.PointingHandCursor)
        self.btn_save.setStyleSheet("""
            QPushButton {
                background-color: #007AFF;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 6px 10px;
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #0062CC;
            }
        """)
        self.btn_save.clicked.connect(self.save_image)

        btn_open = QPushButton("🌐")
        btn_open.setToolTip("在浏览器中直接打开附件")
        btn_open.setCursor(Qt.PointingHandCursor)
        btn_open.setFixedWidth(30)
        btn_open.setStyleSheet("""
            QPushButton {
                background-color: #F1F5F9;
                color: #475569;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 6px 0px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #E2E8F0;
                color: #0F172A;
            }
        """)
        btn_open.clicked.connect(self.open_in_browser)

        btn_layout.addWidget(btn_view, stretch=1)
        btn_layout.addWidget(self.btn_save, stretch=1)
        btn_layout.addWidget(btn_open)
        layout.addLayout(btn_layout)

    def _on_hub_thumbnail_ready(self, fid: str):
        try:
            if fid == self.file_id and self.file_id in THUMBNAIL_CACHE:
                pix, kind, size_mb = THUMBNAIL_CACHE[self.file_id]
                if self.file_id in ATTACHMENT_CACHE:
                    cached = ATTACHMENT_CACHE[self.file_id]
                    self.raw_data = cached["raw"]
                    self.mime_type = cached["mime"]
                self._apply_thumbnail(pix, kind, size_mb)
        except RuntimeError:
            pass

    def _on_hub_attachment_loaded(self, fid: str):
        try:
            if fid == self.file_id and self.file_id in ATTACHMENT_CACHE:
                cached = ATTACHMENT_CACHE[self.file_id]
                self.raw_data = cached["raw"]
                self.mime_type = cached["mime"]
                if self.file_id not in THUMBNAIL_CACHE:
                    self.preview_lbl.setText("正在生成缩略图...")
        except RuntimeError:
            pass

    def _apply_thumbnail(self, pix: QPixmap, kind: str, size_mb: float):
        if pix and not pix.isNull():
            self.preview_lbl.setPixmap(pix)
            self.preview_lbl.setStyleSheet("""
                background-color: #FFFFFF;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
            """)
            if kind.startswith("pdf_"):
                pages = kind.split("_")[1]
                self.btn_save.setText(f"下载PDF ({pages}页·{size_mb:.1f}M)")
            else:
                self.btn_save.setText(f"下载原图 ({size_mb:.1f}M)")
        else:
            if "pdf" in self.mime_type or (self.raw_data and self.raw_data.startswith(b"%PDF")):
                self.preview_lbl.setText(f"📄 备案PDF文件\n({size_mb:.1f} MB)\n点击打开")
                self.btn_save.setText(f"下载PDF ({size_mb:.1f}M)")
            else:
                self.preview_lbl.setText(f"📎 图纸附件\n({size_mb:.1f} MB)\n点击下载查看")
                self.btn_save.setText(f"下载附件 ({size_mb:.1f}M)")

    def on_preview_clicked(self):
        if self.raw_data or self.file_id in ATTACHMENT_CACHE:
            self.show_large_preview()
        else:
            self.load_thumbnail()

    def load_thumbnail(self):
        if self.file_id in THUMBNAIL_CACHE:
            pix, kind, size_mb = THUMBNAIL_CACHE[self.file_id]
            if self.file_id in ATTACHMENT_CACHE:
                cached = ATTACHMENT_CACHE[self.file_id]
                self.raw_data = cached["raw"]
                self.mime_type = cached["mime"]
            self._apply_thumbnail(pix, kind, size_mb)
            return

        if self.file_id in ATTACHMENT_CACHE:
            cached = ATTACHMENT_CACHE[self.file_id]
            self.raw_data = cached["raw"]
            self.mime_type = cached["mime"]
            self.preview_lbl.setText("正在生成缩略图...")
            request_thumbnail_worker(self.file_id, self.raw_data, self.mime_type)
            return

        if self.file_id in IN_PROGRESS_FIDS:
            self.preview_lbl.setText("正在下载图纸...")
            return

        # 检查通道就绪状态 (若是外部直接URL则免等待引擎就绪)
        is_external_url = bool(self.url and self.url.startswith("http") and "nmpafile" not in self.url)
        if not is_external_url and not self.engine.is_ready:
            self.preview_lbl.setText("正在等待安全通道...")
            def on_ready(ok, _):
                try:
                    self.engine.sig_ready.disconnect(on_ready)
                except Exception:
                    pass
                if ok:
                    self._do_fetch_thumbnail()
                else:
                    self.preview_lbl.setText("可在浏览器查看\n(点击重新加载)")

            self.engine.sig_ready.connect(on_ready)
            if not self.engine.is_reconfiguring:
                self.engine.initialize()
            return

        self.preview_lbl.setText("正在下载图纸 (直连)...")
        started = request_direct_download(
            self.file_id, self.engine.get_cookie_dict_sync, self._do_fetch_thumbnail, self.url)
        if not started:
            self.preview_lbl.setText("正在下载图纸...")

    def _do_fetch_thumbnail(self, fid=None):
        # 直连失败回落到此（代理通道）：需引擎就绪，否则等待
        if not self.engine.is_ready:
            self.preview_lbl.setText("正在等待安全通道...")
            def on_ready(ok, _):
                try:
                    self.engine.sig_ready.disconnect(on_ready)
                except Exception:
                    pass
                if ok:
                    self._do_fetch_thumbnail_proxy()
                else:
                    self.preview_lbl.setText("可在浏览器查看\n(点击重新加载)")
            self.engine.sig_ready.connect(on_ready)
            if not self.engine.is_reconfiguring:
                self.engine.initialize()
            return
        self._do_fetch_thumbnail_proxy()

    def _do_fetch_thumbnail_proxy(self):
        self.poll_count = 0
        self.preview_lbl.setText("正在下载图纸 (代理)...")
        fid = self.file_id

        # 核心：必须先重置 JS 内存中的结果变量，严禁复用旧报错状态！
        self.engine.run_js(f"window['__f_{fid}'] = null;")

        js = f"""(async () => {{
            const fid = '{fid}';
            window['__f_' + fid] = null;
            const controller = new AbortController();
            const tid = setTimeout(() => controller.abort(), 35000);
            try {{
                const r = await fetch('/HZPBZCX/PTHZPBA-SERVER/nmpafile/gsxxFilePreview?attachmentId=' + fid, {{
                    signal: controller.signal
                }});
                clearTimeout(tid);
                if (!r.ok) {{
                    window['__f_' + fid] = JSON.stringify({{ok: false, error: 'HTTP ' + r.status}});
                    return;
                }}
                const b = await r.blob();
                const rd = new FileReader();
                rd.onloadend = () => {{
                    window['__f_' + fid] = JSON.stringify({{ok: true, mime: b.type, data: rd.result}});
                }};
                rd.readAsDataURL(b);
            }} catch(e) {{
                clearTimeout(tid);
                window['__f_' + fid] = JSON.stringify({{ok: false, error: e.toString()}});
            }}
        }})();"""
        self.engine.run_js(js)
        QTimer.singleShot(400, self._poll_thumbnail)

    def _poll_thumbnail(self):
        self.engine.run_js(f"window['__f_{self.file_id}']", self._on_thumbnail_ready)

    def _on_thumbnail_ready(self, res_str: str):
        if not res_str:
            self.poll_count += 1
            if self.poll_count < 70:  # 允许最大 35 秒轮询
                elapsed = int(self.poll_count * 0.5)
                self.preview_lbl.setText(f"正在下载图纸 ({elapsed}s)...")
                QTimer.singleShot(500, self._poll_thumbnail)
                return
            self.engine.run_js(f"window['__f_{self.file_id}'] = null;")
            IN_PROGRESS_FIDS.discard(self.file_id)
            self.preview_lbl.setText("可在浏览器查看\n(点击重新加载)")
            log_warn(f"[AttachmentCard] 附件 {self.file_id} 下载超时 (35s)")
            return

        try:
            d = json.loads(res_str)
            if not d.get("ok"):
                err = d.get("error", "未知错误")
                log_warn(f"[AttachmentCard] 附件 {self.file_id} 加载未完成: {err}")
                self.preview_lbl.setText("可在浏览器查看\n(点击重新加载)")
                return
            mime = d.get("mime", "")
            self.mime_type = mime
            data_url = d.get("data", "")
            raw = base64.b64decode(data_url.split(",")[-1])
            self.raw_data = raw

            # 存入全局缓存，保证后续跨卡片切换秒开
            ATTACHMENT_CACHE[self.file_id] = {"mime": mime, "raw": raw}
            attachment_hub.sig_attachment_loaded.emit(self.file_id)
            log_info(f"[AttachmentCard] 附件 {self.file_id} 单独加载成功: {len(raw)} bytes, mime={mime}")

            self.preview_lbl.setText("正在生成缩略图...")
            request_thumbnail_worker(self.file_id, raw, mime)
            preheat_preview_worker(self.file_id, raw, mime)
        except Exception as e:
            log_error(f"[AttachmentCard] 解析异常: {e}")
            self.preview_lbl.setText("可在浏览器查看\n(数据解析异常)")
        finally:
            IN_PROGRESS_FIDS.discard(self.file_id)
            self.engine.run_js(f"window['__f_{self.file_id}'] = null;")

    def _render_thumbnail(self, raw: bytes, mime: str):
        self.preview_lbl.setText("正在生成缩略图...")
        request_thumbnail_worker(self.file_id, raw, mime)

    def show_large_preview(self):
        """点击缩略图弹出全尺寸高清预览对话框"""
        raw = self.raw_data
        mime = self.mime_type
        if not raw and self.file_id in ATTACHMENT_CACHE:
            cached = ATTACHMENT_CACHE[self.file_id]
            raw = cached["raw"]
            mime = cached["mime"]
            self.raw_data = raw
            self.mime_type = mime

        if raw:
            dlg = ImagePreviewDialog(self.title, raw, mime, self.file_id, self)
            dlg.exec()
        else:
            QDesktopServices.openUrl(QUrl(self.url))

    def open_in_browser(self):
        QDesktopServices.openUrl(QUrl(self.url))

    def save_image(self):
        is_pdf = "pdf" in self.mime_type or (self.raw_data and self.raw_data.startswith(b"%PDF"))
        ext = ".pdf" if is_pdf else ".jpg"
        clean_title = re.sub(r'[\/:*?"<>|\r\n\t]', '_', self.title).strip()
        if clean_title.lower().endswith(ext.lower()):
            clean_title = clean_title[:-len(ext)].strip()
        default_filename = f"{clean_title}_{self.file_id}{ext}"
        save_path, _ = QFileDialog.getSaveFileName(
            self, "保存附件", default_filename, f"Files (*{ext} *.*)"
        )
        if save_path:
            try:
                if self.raw_data:
                    with open(save_path, "wb") as f:
                        f.write(self.raw_data)
                    QMessageBox.information(self, "保存成功", f"附件已成功保存至:\n{save_path}")
                else:
                    QDesktopServices.openUrl(QUrl(self.url))
            except Exception as e:
                QMessageBox.critical(self, "保存失败", f"保存附件失败: {str(e)}")


class MainWindow(QMainWindow):
    """主应用程序窗口"""
    def __init__(self):
        super().__init__()
        self.current_data = None
        self.raw_logs = []
        self.engine = EmbeddedNmpaEngine(self)
        self.controller = NmpaQueryController(self.engine)

        self.init_ui()
        self.setup_signals()

        # 启动内置引擎与网络
        self.progress_bar.show()
        self.engine.initialize()

        # 启动后后台静默检查更新 (仅在有新版本时轻量提示)
        QTimer.singleShot(4000, lambda: check_for_updates_interactive(self, silent_if_latest=True))

    def init_ui(self):
        self.setWindowTitle("化妆品备案档案速查助手 (NMPA Cosmetics Viewer)")
        self.resize(1080, 780)
        self.setMinimumSize(920, 640)

        # 全局 macOS 现代化极简主题样式
        self.setStyleSheet("""
            QMainWindow {
                background-color: #F8FAFC;
            }
            QWidget {
                font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "PingFang SC", "Segoe UI", "Helvetica Neue", sans-serif;
            }
            QTabWidget::pane {
                border: 1px solid #E2E8F0;
                border-radius: 12px;
                background-color: #FFFFFF;
                top: 0px;
            }
            QTabBar {
                background: transparent;
                qproperty-drawBase: 0;
            }
            QTabBar::tab {
                background-color: #F1F5F9;
                color: #475569;
                padding: 9px 20px;
                font-size: 13px;
                font-weight: 600;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                margin-right: 6px;
                margin-bottom: 8px;
            }
            QTabBar::tab:selected {
                background-color: #007AFF;
                color: #FFFFFF;
                border-color: #007AFF;
            }
            QTabBar::tab:hover:!selected {
                background-color: #E2E8F0;
                color: #0F172A;
            }
            QScrollBar:vertical {
                border: none;
                background: transparent;
                width: 8px;
                margin: 0;
            }
            QScrollBar::handle:vertical {
                background: #CBD5E1;
                border-radius: 4px;
                min-height: 24px;
            }
            QScrollBar::handle:vertical:hover {
                background: #94A3B8;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(22, 18, 22, 18)
        main_layout.setSpacing(14)

        # -----------------------------
        # 顶部工具栏与搜索区 (现代化卡片容器)
        # -----------------------------
        search_card = QFrame()
        search_card.setObjectName("search_card")
        search_card.setStyleSheet("""
            QFrame#search_card {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 12px;
            }
        """)
        top_bar = QHBoxLayout(search_card)
        top_bar.setContentsMargins(10, 8, 10, 8)
        top_bar.setSpacing(10)

        # 查询类别下拉框
        self.combo_type = QComboBox()
        self.combo_type.addItem("💄 普通化妆品 (网备字)", "general")
        self.combo_type.addItem("⭐ 特殊化妆品 (特字/特进)", "special")
        self.combo_type.addItem("🛍️ 电商素材采集 (1688 / 抖音)", "1688")
        self.combo_type.setFixedHeight(40)
        self.combo_type.setStyleSheet("""
            QComboBox {
                background-color: #F8FAFC;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                padding: 0 12px;
                font-size: 13px;
                font-weight: 600;
                color: #1E293B;
                min-width: 180px;
            }
            QComboBox:hover {
                background-color: #F1F5F9;
                border-color: #94A3B8;
            }
            QComboBox:focus {
                border-color: #007AFF;
                background-color: #FFFFFF;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
        """)
        self.combo_type.currentIndexChanged.connect(self._on_type_changed)

        # 搜索输入框
        self.input_record = QLineEdit()
        self.input_record.setPlaceholderText("输入备案编号，支持多个空格/换行分隔批量并发查询 (如: 沪G... 粤G...)...")
        self.input_record.setText("浙G妆网备字2022023901")
        self.input_record.setFixedHeight(40)
        self.input_record.setStyleSheet("""
            QLineEdit {
                background-color: #F8FAFC;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                padding: 0 14px;
                font-size: 13px;
                color: #0F172A;
            }
            QLineEdit:focus {
                border: 1.5px solid #007AFF;
                background-color: #FFFFFF;
            }
        """)
        self.input_record.returnPressed.connect(self.start_query)
        self.input_record.textChanged.connect(self._on_input_text_changed)

        # 查询按钮
        self.btn_search = QPushButton("⚡ 通道初始化中...")
        self.btn_search.setFixedHeight(40)
        self.btn_search.setEnabled(False)
        self.btn_search.setCursor(Qt.PointingHandCursor)
        self.btn_search.setToolTip("正在建立安全通道与瑞数环境，通道就绪后即可查询")
        self.btn_search.setStyleSheet("""
            QPushButton {
                background-color: #007AFF;
                color: #FFFFFF;
                border: none;
                border-radius: 8px;
                padding: 0 20px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #0062CC;
            }
            QPushButton:pressed {
                background-color: #004F9F;
            }
            QPushButton:disabled {
                background-color: #CBD5E1;
                color: #94A3B8;
            }
        """)
        self.btn_search.clicked.connect(self.start_query)

        btn_outline_style = """
            QPushButton {
                background-color: #F8FAFC;
                color: #334155;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                padding: 0 14px;
                font-size: 13px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #F1F5F9;
                color: #0F172A;
                border-color: #94A3B8;
            }
            QPushButton:disabled {
                color: #94A3B8;
                border-color: #E2E8F0;
                background-color: #F8FAFC;
            }
        """

        # 复制档案摘要按钮
        self.btn_copy_summary = QPushButton("📋 复制摘要")
        self.btn_copy_summary.setFixedHeight(40)
        self.btn_copy_summary.setEnabled(False)
        self.btn_copy_summary.setCursor(Qt.PointingHandCursor)
        self.btn_copy_summary.setStyleSheet(btn_outline_style)
        self.btn_copy_summary.clicked.connect(self.copy_summary)

        # 导出 JSON 按钮
        self.btn_export_json = QPushButton("💾 导出JSON")
        self.btn_export_json.setFixedHeight(40)
        self.btn_export_json.setEnabled(False)
        self.btn_export_json.setCursor(Qt.PointingHandCursor)
        self.btn_export_json.setStyleSheet(btn_outline_style)
        self.btn_export_json.clicked.connect(self.export_json)

        # 代理与通道配置按钮
        self.btn_proxy_settings = QPushButton("⚙️ 网络通道")
        self.btn_proxy_settings.setFixedHeight(40)
        self.btn_proxy_settings.setCursor(Qt.PointingHandCursor)
        self.btn_proxy_settings.setStyleSheet(btn_outline_style)
        self.btn_proxy_settings.clicked.connect(self.open_proxy_settings)

        # 检查更新按钮
        self.btn_check_update = QPushButton("🔄 检查更新")
        self.btn_check_update.setFixedHeight(40)
        self.btn_check_update.setCursor(Qt.PointingHandCursor)
        self.btn_check_update.setStyleSheet(btn_outline_style)
        self.btn_check_update.clicked.connect(lambda: check_for_updates_interactive(self, silent_if_latest=False))

        top_bar.addWidget(self.combo_type)
        top_bar.addWidget(self.input_record, stretch=1)
        top_bar.addWidget(self.btn_search)
        top_bar.addWidget(self.btn_proxy_settings)
        top_bar.addWidget(self.btn_check_update)
        top_bar.addWidget(self.btn_copy_summary)
        top_bar.addWidget(self.btn_export_json)
        main_layout.addWidget(search_card)

        # 状态指示与进度条栏
        status_bar_layout = QHBoxLayout()
        self.lbl_status = QLabel("正在启动内置安全环境与破盾通道...")
        self.lbl_status.setStyleSheet("color: #64748B; font-size: 12px;")

        self.lbl_ver_badge = QLabel(f"v{get_current_app_version()}")
        self.lbl_ver_badge.setCursor(Qt.PointingHandCursor)
        self.lbl_ver_badge.setToolTip("点击检查新版本与功能同步")
        self.lbl_ver_badge.setStyleSheet("""
            QLabel {
                background-color: #F1F5F9;
                color: #475569;
                font-size: 11px;
                font-weight: 600;
                padding: 4px 8px;
                border-radius: 4px;
                border: 1px solid #CBD5E1;
            }
            QLabel:hover {
                background-color: #E2E8F0;
                color: #0F172A;
            }
        """)
        self.lbl_ver_badge.mousePressEvent = lambda e: check_for_updates_interactive(self, silent_if_latest=False)

        self.lbl_net_badge = QLabel("⚡ 正在探测通道...")
        self.lbl_net_badge.setCursor(Qt.PointingHandCursor)
        self.lbl_net_badge.setToolTip("点击打开网络通道与动态代理设置")
        self.lbl_net_badge.setStyleSheet("""
            QLabel {
                background-color: #E0E7FF;
                color: #4338CA;
                font-size: 11px;
                font-weight: 600;
                padding: 4px 10px;
                border-radius: 4px;
            }
            QLabel:hover {
                background-color: #C7D2FE;
            }
        """)
        self.lbl_net_badge.mousePressEvent = lambda e: self.open_proxy_settings()

        status_bar_layout.addWidget(self.lbl_status)
        status_bar_layout.addStretch()
        status_bar_layout.addWidget(self.lbl_ver_badge)
        status_bar_layout.addWidget(self.lbl_net_badge)
        main_layout.addLayout(status_bar_layout)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(3)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setRange(0, 0)  # 循环进度
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: none;
                background-color: #E2E8F0;
                border-radius: 1px;
            }
            QProgressBar::chunk {
                background-color: #007AFF;
                border-radius: 1px;
            }
        """)
        self.progress_bar.hide()
        main_layout.addWidget(self.progress_bar)

        # -----------------------------
        # 批量查询导航切换栏 (默认隐藏)
        # -----------------------------
        self.batch_bar = QFrame()
        self.batch_bar.setStyleSheet("""
            QFrame {
                background-color: #F8FAFC;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                padding: 4px 10px;
            }
        """)
        batch_layout = QHBoxLayout(self.batch_bar)
        batch_layout.setContentsMargins(6, 4, 6, 4)
        batch_layout.setSpacing(10)

        self.lbl_batch_title = QLabel("📦 批量档案 (共 0 项):")
        self.lbl_batch_title.setStyleSheet("font-size: 13px; font-weight: 600; color: #1E293B;")
        batch_layout.addWidget(self.lbl_batch_title)

        self.combo_batch = QComboBox()
        self.combo_batch.setFixedHeight(32)
        self.combo_batch.setCursor(Qt.PointingHandCursor)
        self.combo_batch.setStyleSheet("""
            QComboBox {
                background-color: #FFFFFF;
                border: 1px solid #94A3B8;
                border-radius: 6px;
                padding: 2px 10px;
                font-size: 13px;
                font-weight: 500;
                color: #0F172A;
            }
            QComboBox::drop-down {
                border: none;
                width: 22px;
            }
        """)
        self.combo_batch.currentIndexChanged.connect(self.on_batch_item_selected)
        batch_layout.addWidget(self.combo_batch, stretch=1)

        self.btn_batch_export_all = QPushButton("💾 批量导出所有JSON")
        self.btn_batch_export_all.setFixedHeight(32)
        self.btn_batch_export_all.setCursor(Qt.PointingHandCursor)
        self.btn_batch_export_all.setStyleSheet("""
            QPushButton {
                background-color: #007AFF;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 0 14px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #0062CC;
            }
        """)
        self.btn_batch_export_all.clicked.connect(self.export_batch_json)
        batch_layout.addWidget(self.btn_batch_export_all)

        self.batch_bar.hide()
        main_layout.addWidget(self.batch_bar)

        # -----------------------------
        # 主内容多标签页
        # -----------------------------
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs, stretch=1)

        # Tab 1: 备案基本信息
        self.tab_basic = QWidget()
        self.setup_basic_tab()
        self.tabs.addTab(self.tab_basic, "📋 备案基本信息")

        # Tab 2: 功效宣称与评价 (新增专属核心公示选项卡)
        self.tab_efficacy_widget = QWidget()
        self.setup_efficacy_tab()
        self.tabs.addTab(self.tab_efficacy_widget, "✨ 功效宣称与评价")

        # Tab 3: 全配方成分明细
        self.tab_components = QWidget()
        self.setup_components_tab()
        self.tabs.addTab(self.tab_components, "🧪 全配方成分明细")

        # Tab 3: 包装图纸与画廊
        self.tab_gallery = QWidget()
        self.setup_gallery_tab()
        self.tabs.addTab(self.tab_gallery, "🖼️ 包装图纸与画廊")

        # Tab 4: 变更与生命周期轨迹
        self.tab_history = QWidget()
        self.setup_history_tab()
        self.tabs.addTab(self.tab_history, "📜 变更与生命周期轨迹")

        # Tab 5: 电商 (1688 / 抖音) 商品图影素材采集与下载
        from tab_1688 import Tab1688Widget
        self.tab_1688 = Tab1688Widget(self)
        self.tabs.addTab(self.tab_1688, "🛍️ 电商素材提取 (1688/抖音)")

        # Tab 6: 运行日志与诊断
        self.tab_logs = QWidget()
        self.setup_logs_tab()
        self.tabs.addTab(self.tab_logs, "🖥️ 运行日志")

    def setup_signals(self):
        self.engine.sig_ready.connect(self.on_engine_ready)
        self.engine.sig_status.connect(self.on_engine_status)
        self.controller.sig_status.connect(self.on_controller_status)
        self.controller.sig_success.connect(self.on_controller_success)
        self.controller.sig_batch_success.connect(self.on_controller_batch_success)
        self.controller.sig_error.connect(self.on_controller_error)
        AppLogger.get().sig_log.connect(self.append_log)

    def on_engine_status(self, msg: str):
        if self.controller.is_querying and not self.engine.is_ready:
            self.lbl_status.setText(f"通道初始化: {msg}")
        elif not self.controller.is_querying:
            self.lbl_status.setText(msg)

    def open_proxy_settings(self):
        dlg = ProxySettingsDialog(self, on_applied=self.apply_proxy_settings)
        dlg.exec()

    def apply_proxy_settings(self, mode: str, api_url: str):
        self.lbl_status.setText("正在切换网络通道并重载安全环境...")
        self.lbl_net_badge.setText("⚡ 切换通道中...")
        self.lbl_net_badge.setStyleSheet("""
            QLabel {
                background-color: #FEF3C7;
                color: #B45309;
                font-size: 11px;
                font-weight: 600;
                padding: 4px 10px;
                border-radius: 4px;
            }
        """)
        self.btn_search.setText("⚡ 通道切换中...")
        self.btn_search.setEnabled(False)
        self.progress_bar.show()
        self.engine.initialize(mode, api_url)

    def on_engine_ready(self, ready: bool, net_desc: str):
        self.progress_bar.hide()
        if ready:
            self.btn_search.setText("一键查询")
            self.btn_search.setEnabled(True)
            self.btn_search.setToolTip("")
            self.lbl_status.setText("系统就绪，可随时输入备案编号进行查询。")
            self.lbl_net_badge.setText(f"🌐 {net_desc}")
            self.lbl_net_badge.setToolTip("网络通道正常，点击打开代理与网络设置")
            self.lbl_net_badge.setStyleSheet("""
                QLabel {
                    background-color: #E0E7FF;
                    color: #4338CA;
                    font-size: 11px;
                    font-weight: 600;
                    padding: 4px 10px;
                    border-radius: 4px;
                }
                QLabel:hover {
                    background-color: #C7D2FE;
                }
            """)
        else:
            self.btn_search.setText("🔄 重新连接通道")
            self.btn_search.setEnabled(True)
            self.btn_search.setToolTip("点击重新探测与初始化安全通道")
            self.lbl_status.setText(f"❌ 通道未就绪: {net_desc} (点击「重新连接」或设置重试)")
            self.lbl_net_badge.setText("⚠️ 通道异常 (点击设置/重试)")
            self.lbl_net_badge.setToolTip("通道连接失败，点击切换直连或重试代理")
            self.lbl_net_badge.setStyleSheet("""
                QLabel {
                    background-color: #FEE2E2;
                    color: #B91C1C;
                    font-size: 11px;
                    font-weight: 600;
                    padding: 4px 10px;
                    border-radius: 4px;
                }
                QLabel:hover {
                    background-color: #FECACA;
                }
            """)

    def setup_basic_tab(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        # 顶部核心提要横幅卡片 (Hero Card)
        self.hero_card = QFrame()
        self.hero_card.setObjectName("hero_card")
        self.hero_card.setStyleSheet("""
            QFrame#hero_card {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #F8FAFC, stop:1 #EFF6FF);
                border: 1px solid #DBEAFE;
                border-radius: 12px;
            }
        """)
        hero_lay = QVBoxLayout(self.hero_card)
        hero_lay.setSpacing(8)
        hero_lay.setContentsMargins(18, 16, 18, 16)

        # 标题与状态徽章行
        h_row1 = QHBoxLayout()
        self.hero_title = QLabel("化妆品档案速查助手")
        self.hero_title.setFont(QFont("PingFang SC", 16, QFont.Bold))
        self.hero_title.setStyleSheet("color: #0F172A;")
        self.hero_title.setTextInteractionFlags(Qt.TextSelectableByMouse)
        h_row1.addWidget(self.hero_title, stretch=1)

        self.hero_badge_status = QLabel("● 待查询")
        self.hero_badge_status.setStyleSheet("""
            background-color: #E2E8F0;
            color: #475569;
            font-size: 12px;
            font-weight: 600;
            padding: 4px 14px;
            border-radius: 12px;
        """)
        h_row1.addWidget(self.hero_badge_status)
        hero_lay.addLayout(h_row1)

        # 英文名与编号行
        h_row2 = QHBoxLayout()
        self.hero_subtitle = QLabel("请在上方输入备案编号或特殊文号，点击一键查询或回车")
        self.hero_subtitle.setStyleSheet("color: #64748B; font-size: 13px;")
        self.hero_subtitle.setTextInteractionFlags(Qt.TextSelectableByMouse)
        h_row2.addWidget(self.hero_subtitle, stretch=1)

        self.hero_badge_rec = QLabel("备案编号: -")
        self.hero_badge_rec.setStyleSheet("""
            background-color: #FFFFFF;
            color: #1E293B;
            border: 1px solid #CBD5E1;
            font-size: 11px;
            font-weight: 600;
            padding: 3px 10px;
            border-radius: 6px;
        """)
        self.hero_badge_rec.setTextInteractionFlags(Qt.TextSelectableByMouse)
        h_row2.addWidget(self.hero_badge_rec)
        hero_lay.addLayout(h_row2)

        # 核心功能快速直达按钮行
        h_row3 = QHBoxLayout()
        h_row3.setSpacing(10)
        self.btn_hero_gallery = QPushButton("🖼️ 上市包装与图纸PDF ➜")
        self.btn_hero_gallery.setCursor(Qt.PointingHandCursor)
        self.btn_hero_gallery.setStyleSheet("""
            QPushButton {
                background-color: #EFF6FF;
                color: #1D4ED8;
                border: 1px solid #BFDBFE;
                border-radius: 6px;
                padding: 4px 12px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #DBEAFE;
                color: #1E40AF;
            }
        """)
        self.btn_hero_gallery.clicked.connect(lambda: self.tabs.setCurrentWidget(self.tab_gallery))

        self.btn_hero_components = QPushButton("🧪 全配方成分明细 ➜")
        self.btn_hero_components.setCursor(Qt.PointingHandCursor)
        self.btn_hero_components.setStyleSheet("""
            QPushButton {
                background-color: #F8FAFC;
                color: #475569;
                border: 1px solid #E2E8F0;
                border-radius: 6px;
                padding: 4px 12px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #F1F5F9;
                color: #0F172A;
            }
        """)
        self.btn_hero_components.clicked.connect(lambda: self.tabs.setCurrentWidget(self.tab_components))

        self.btn_hero_efficacy = QPushButton("✨ 功效宣称与评价 ➜")
        self.btn_hero_efficacy.setCursor(Qt.PointingHandCursor)
        self.btn_hero_efficacy.setStyleSheet("""
            QPushButton {
                background-color: #F8FAFC;
                color: #475569;
                border: 1px solid #E2E8F0;
                border-radius: 6px;
                padding: 4px 12px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #F1F5F9;
                color: #0F172A;
            }
        """)
        self.btn_hero_efficacy.clicked.connect(lambda: self.tabs.setCurrentWidget(self.tab_efficacy_widget))

        h_row3.addWidget(self.btn_hero_gallery)
        h_row3.addWidget(self.btn_hero_components)
        h_row3.addWidget(self.btn_hero_efficacy)
        h_row3.addStretch()
        hero_lay.addLayout(h_row3)

        layout.addWidget(self.hero_card)

        grid = QGridLayout()
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(8)

        def make_field(title):
            card = QFrame()
            card.setStyleSheet("""
                QFrame {
                    background-color: #F8FAFC;
                    border: 1px solid #E2E8F0;
                    border-radius: 8px;
                    padding: 4px 10px;
                }
            """)
            c_lay = QVBoxLayout(card)
            c_lay.setContentsMargins(4, 4, 4, 4)
            c_lay.setSpacing(2)
            lbl_t = QLabel(title)
            lbl_t.setStyleSheet("color: #64748B; font-size: 11px; font-weight: bold;")
            lbl_v = QLabel("-")
            lbl_v.setStyleSheet("color: #0F172A; font-size: 13px; font-weight: 500;")
            lbl_v.setWordWrap(True)
            lbl_v.setTextInteractionFlags(Qt.TextSelectableByMouse)
            c_lay.addWidget(lbl_t)
            c_lay.addWidget(lbl_v)
            card.title_lbl = lbl_t
            return card, lbl_v

        self.card_prod, self.val_prod = make_field("产品中文名称")
        self.card_prod_en, self.val_prod_en = make_field("产品英文名称")
        self.card_rec_no, self.val_rec_no = make_field("备案编号")
        self.card_rec_date, self.val_rec_date = make_field("备案通过日期")
        self.card_status, self.val_status = make_field("当前备案状态")
        self.card_children, self.val_children = make_field("是否儿童化妆品")
        self.card_shelf, self.val_shelf = make_field("使用期限 / 保质期")
        self.card_ent, self.val_ent = make_field("备案人 / 企业名称")
        self.card_ent_addr, self.val_ent_addr = make_field("备案人地址")
        self.card_mfr, self.val_mfr = make_field("生产企业与地址 (受托/自主)")

        self.card_efficacy, self.val_efficacy = make_field("✨ 功效宣称与评价依据 (国家药监局法定公示)")
        self.card_efficacy.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #F0FDF4, stop:1 #ECFDF5);
                border: 1px solid #A7F3D0;
                border-radius: 8px;
                padding: 6px 12px;
            }
        """)
        self.card_efficacy.title_lbl.setStyleSheet("color: #065F46; font-size: 11px; font-weight: bold;")
        self.val_efficacy.setStyleSheet("color: #064E3B; font-size: 13px; font-weight: 500; line-height: 1.5;")

        # Quick link button inside card_efficacy
        self.btn_goto_eff = QPushButton("🔍 查看完整功效评价试验与依据报告 (前往专属选项卡) ➜")
        self.btn_goto_eff.setCursor(Qt.PointingHandCursor)
        self.btn_goto_eff.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 12px;
                font-weight: 600;
                margin-top: 6px;
            }
            QPushButton:hover {
                background-color: #047857;
            }
        """)
        self.btn_goto_eff.clicked.connect(lambda: self.tabs.setCurrentWidget(self.tab_efficacy_widget))
        self.card_efficacy.layout().addWidget(self.btn_goto_eff)

        grid.addWidget(self.card_prod, 0, 0, 1, 2)
        grid.addWidget(self.card_rec_no, 1, 0)
        grid.addWidget(self.card_rec_date, 1, 1)
        grid.addWidget(self.card_status, 2, 0)
        grid.addWidget(self.card_children, 2, 1)
        grid.addWidget(self.card_efficacy, 3, 0, 1, 2)
        grid.addWidget(self.card_shelf, 4, 0)
        grid.addWidget(self.card_prod_en, 4, 1)
        grid.addWidget(self.card_ent, 5, 0, 1, 2)
        grid.addWidget(self.card_ent_addr, 6, 0, 1, 2)
        grid.addWidget(self.card_mfr, 7, 0, 1, 2)

        layout.addLayout(grid)

        # 包装图纸与上市销售PDF专属展示横幅卡片 (直接在基本信息页一览无余，杜绝切Tab盲区)
        self.card_pdf_banner = QFrame()
        self.card_pdf_banner.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #F0FDF4, stop:1 #EFF6FF);
                border: 1.5px solid #93C5FD;
                border-radius: 10px;
                padding: 12px 16px;
            }
        """)
        self.card_pdf_layout = QVBoxLayout(self.card_pdf_banner)
        self.card_pdf_layout.setContentsMargins(12, 10, 12, 10)
        self.card_pdf_layout.setSpacing(8)

        # 头部标题行
        pdf_h_row = QHBoxLayout()
        self.lbl_pdf_banner_title = QLabel("📦 上市销售包装与标签电子件公示 (PDF / 包装图纸)")
        self.lbl_pdf_banner_title.setStyleSheet("font-size: 14px; font-weight: bold; color: #1E3A8A;")
        pdf_h_row.addWidget(self.lbl_pdf_banner_title, stretch=1)

        self.btn_goto_gallery_all = QPushButton("🖼️ 查看全部高清缩略画廊 ➜")
        self.btn_goto_gallery_all.setCursor(Qt.PointingHandCursor)
        self.btn_goto_gallery_all.setStyleSheet("""
            QPushButton {
                background-color: #2563EB;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #1D4ED8;
            }
        """)
        self.btn_goto_gallery_all.clicked.connect(lambda: self.tabs.setCurrentWidget(self.tab_gallery))
        pdf_h_row.addWidget(self.btn_goto_gallery_all)
        self.card_pdf_layout.addLayout(pdf_h_row)

        # 文件列表动态容器
        self.container_pdf_items = QWidget()
        self.layout_pdf_items = QVBoxLayout(self.container_pdf_items)
        self.layout_pdf_items.setContentsMargins(0, 4, 0, 0)
        self.layout_pdf_items.setSpacing(6)
        self.card_pdf_layout.addWidget(self.container_pdf_items)

        self.card_pdf_banner.hide()
        layout.addWidget(self.card_pdf_banner)

        # 使用方法与安全警示
        self.card_usage, self.val_usage = make_field("使用方法与贮存条件")
        self.card_caution, self.val_caution = make_field("安全警示用语与注意事项")
        layout.addWidget(self.card_usage)
        layout.addWidget(self.card_caution)

        # 底部醒目横幅：针对习惯滑到最底部的用户，杜绝漏看功效信息
        self.card_bottom_eff = QFrame()
        self.card_bottom_eff.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ECFDF5, stop:1 #F0FDF4);
                border: 1px dashed #059669;
                border-radius: 8px;
                padding: 10px 16px;
            }
        """)
        b_eff_lay = QHBoxLayout(self.card_bottom_eff)
        self.lbl_bottom_eff_text = QLabel("✨ 本产品法定功效宣称公示已提取，包含官方评价结论与人体/消费者测试依据。")
        self.lbl_bottom_eff_text.setStyleSheet("color: #065F46; font-size: 12px; font-weight: 600;")
        self.btn_bottom_goto_eff = QPushButton("前往「✨ 功效宣称与评价」 ➜")
        self.btn_bottom_goto_eff.setCursor(Qt.PointingHandCursor)
        self.btn_bottom_goto_eff.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #047857;
            }
        """)
        self.btn_bottom_goto_eff.clicked.connect(lambda: self.tabs.setCurrentWidget(self.tab_efficacy_widget))
        b_eff_lay.addWidget(self.lbl_bottom_eff_text, stretch=1)
        b_eff_lay.addWidget(self.btn_bottom_goto_eff)
        layout.addWidget(self.card_bottom_eff)

        layout.addStretch()
        self.scroll_basic = scroll
        self.scroll_basic.setWidget(container)

        t_lay = QVBoxLayout(self.tab_basic)
        t_lay.setContentsMargins(0, 0, 0, 0)
        t_lay.addWidget(self.scroll_basic)

    def setup_efficacy_tab(self):
        """构建「✨ 功效宣称与评价」专属全功能选项卡"""
        layout = QVBoxLayout(self.tab_efficacy_widget)
        layout.setContentsMargins(0, 0, 0, 0)

        self.scroll_efficacy = QScrollArea()
        self.scroll_efficacy.setWidgetResizable(True)
        self.scroll_efficacy.setStyleSheet("QScrollArea { border: none; background-color: transparent; }")

        container = QWidget()
        c_lay = QVBoxLayout(container)
        c_lay.setContentsMargins(20, 20, 20, 20)
        c_lay.setSpacing(14)

        # 1. 顶部 Header 横幅卡片
        top_card = QFrame()
        top_card.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ECFDF5, stop:1 #F0FDF4);
                border: 1px solid #A7F3D0;
                border-radius: 10px;
                padding: 12px 18px;
            }
        """)
        top_lay = QHBoxLayout(top_card)
        top_info = QVBoxLayout()
        t_title = QLabel("✨ 国家药监局法定功效宣称与评价依据公示")
        t_title.setStyleSheet("color: #065F46; font-size: 16px; font-weight: bold;")
        t_sub = QLabel("依据《化妆品监督管理条例》及《化妆品功效宣称评价规范》国家法定公开数据 (中检院/药监局实时同步)")
        t_sub.setStyleSheet("color: #047857; font-size: 12px;")
        top_info.addWidget(t_title)
        top_info.addWidget(t_sub)
        top_lay.addLayout(top_info, stretch=1)

        self.btn_copy_eff_report = QPushButton("📋 一键复制功效全案报告")
        self.btn_copy_eff_report.setCursor(Qt.PointingHandCursor)
        self.btn_copy_eff_report.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                color: #FFFFFF;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #047857;
            }
        """)
        self.btn_copy_eff_report.clicked.connect(self.copy_efficacy_report)
        top_lay.addWidget(self.btn_copy_eff_report)
        c_lay.addWidget(top_card)

        # 2. 核心宣称与评价结论卡片
        claim_card = QFrame()
        claim_card.setStyleSheet("""
            QFrame {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 10px;
                padding: 14px 18px;
            }
        """)
        cl_lay = QVBoxLayout(claim_card)
        cl_lay.setSpacing(10)

        # 功效标签流
        lbl_c1 = QLabel("🏷️ 申报法定功效宣称 (标签):")
        lbl_c1.setStyleSheet("color: #475569; font-size: 12px; font-weight: bold;")
        cl_lay.addWidget(lbl_c1)

        self.eff_tags_widget = QWidget()
        self.eff_tags_layout = QHBoxLayout(self.eff_tags_widget)
        self.eff_tags_layout.setContentsMargins(0, 0, 0, 0)
        self.eff_tags_layout.setSpacing(8)
        self.eff_tags_layout.addStretch()
        cl_lay.addWidget(self.eff_tags_widget)

        # 评价结论
        lbl_c2 = QLabel("📌 官方评价结论:")
        lbl_c2.setStyleSheet("color: #475569; font-size: 12px; font-weight: bold;")
        cl_lay.addWidget(lbl_c2)

        self.eff_conclusion_lbl = QLabel("-")
        self.eff_conclusion_lbl.setStyleSheet("""
            QLabel {
                background-color: #F8FAFC;
                border: 1px solid #E2E8F0;
                border-radius: 6px;
                color: #0F172A;
                font-size: 13px;
                font-weight: 500;
                padding: 8px 12px;
                line-height: 1.5;
            }
        """)
        self.eff_conclusion_lbl.setWordWrap(True)
        self.eff_conclusion_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        cl_lay.addWidget(self.eff_conclusion_lbl)

        # 四维分类指标
        lbl_c3 = QLabel("📊 产品属性与分类指标:")
        lbl_c3.setStyleSheet("color: #475569; font-size: 12px; font-weight: bold;")
        cl_lay.addWidget(lbl_c3)

        attr_grid = QGridLayout()
        attr_grid.setHorizontalSpacing(14)
        attr_grid.setVerticalSpacing(8)

        def make_attr_box(title):
            box = QFrame()
            box.setStyleSheet("""
                QFrame {
                    background-color: #F8FAFC;
                    border: 1px solid #E2E8F0;
                    border-radius: 6px;
                    padding: 6px 10px;
                }
            """)
            b_l = QVBoxLayout(box)
            b_l.setContentsMargins(4, 2, 4, 2)
            b_l.setSpacing(2)
            t = QLabel(title)
            t.setStyleSheet("color: #64748B; font-size: 11px;")
            v = QLabel("-")
            v.setStyleSheet("color: #0F172A; font-size: 12px; font-weight: 600;")
            v.setTextInteractionFlags(Qt.TextSelectableByMouse)
            b_l.addWidget(t)
            b_l.addWidget(v)
            return box, v

        box1, self.eff_val_body_part = make_attr_box("🎯 作用部位")
        box2, self.eff_val_dosage_form = make_attr_box("🧴 产品剂型")
        box3, self.eff_val_usage_type = make_attr_box("🚿 使用方式")
        box4, self.eff_val_target_users = make_attr_box("👥 适用人群")
        attr_grid.addWidget(box1, 0, 0)
        attr_grid.addWidget(box2, 0, 1)
        attr_grid.addWidget(box3, 0, 2)
        attr_grid.addWidget(box4, 0, 3)
        cl_lay.addLayout(attr_grid)

        c_lay.addWidget(claim_card)

        # 3. 详细试验评价依据与项目明细
        sec_lbl = QLabel("🔬 功效宣称评价依据与试验项目明细")
        sec_lbl.setStyleSheet("color: #1E293B; font-size: 14px; font-weight: bold;")
        c_lay.addWidget(sec_lbl)

        self.eff_items_container = QWidget()
        self.eff_items_layout = QVBoxLayout(self.eff_items_container)
        self.eff_items_layout.setContentsMargins(0, 0, 0, 0)
        self.eff_items_layout.setSpacing(10)
        c_lay.addWidget(self.eff_items_container)

        c_lay.addStretch()
        self.scroll_efficacy.setWidget(container)
        layout.addWidget(self.scroll_efficacy)

    def setup_components_tab(self):
        layout = QVBoxLayout(self.tab_components)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # 顶部工具与筛选栏
        comp_top_bar = QHBoxLayout()
        comp_top_bar.setSpacing(10)

        self.lbl_comp_count = QLabel("🧪 全配方成分明细")
        self.lbl_comp_count.setFont(QFont("PingFang SC", 13, QFont.Bold))
        self.lbl_comp_count.setStyleSheet("color: #0F172A;")
        comp_top_bar.addWidget(self.lbl_comp_count)

        self.input_comp_filter = QLineEdit()
        self.input_comp_filter.setPlaceholderText("🔍 快速筛选成分名称 (例如: 烟酰胺、水、甘油)...")
        self.input_comp_filter.setFixedHeight(34)
        self.input_comp_filter.setStyleSheet("""
            QLineEdit {
                background-color: #F8FAFC;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 0 10px;
                font-size: 12px;
                color: #1E293B;
            }
            QLineEdit:focus {
                border-color: #007AFF;
                background-color: #FFFFFF;
            }
        """)
        self.input_comp_filter.textChanged.connect(self._filter_components)
        comp_top_bar.addWidget(self.input_comp_filter, stretch=1)

        self.btn_copy_formula = QPushButton("📋 复制成分")
        self.btn_copy_formula.setFixedHeight(34)
        self.btn_copy_formula.setCursor(Qt.PointingHandCursor)
        self.btn_copy_formula.setStyleSheet("""
            QPushButton {
                background-color: #F1F5F9;
                color: #334155;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 0 12px;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #E2E8F0;
                color: #0F172A;
            }
        """)
        self.btn_copy_formula.clicked.connect(self.copy_formula)
        comp_top_bar.addWidget(self.btn_copy_formula)
        layout.addLayout(comp_top_bar)

        self.txt_components = QTextEdit()
        self.txt_components.setReadOnly(True)
        self.txt_components.setPlaceholderText("查询后将在此处完整展示产品全配方成分列表...")
        self.txt_components.setStyleSheet("""
            QTextEdit {
                background-color: #F8FAFC;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                padding: 14px;
                font-size: 13px;
                line-height: 1.6;
                color: #1E293B;
            }
        """)
        layout.addWidget(self.txt_components)

    def setup_gallery_tab(self):
        layout = QVBoxLayout(self.tab_gallery)
        layout.setContentsMargins(20, 20, 20, 20)

        self.scroll_gallery = QScrollArea()
        self.scroll_gallery.setWidgetResizable(True)
        self.scroll_gallery.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        self.gallery_container = QWidget()
        self.gallery_layout = QGridLayout(self.gallery_container)
        self.gallery_layout.setSpacing(16)
        self.gallery_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)

        self.scroll_gallery.setWidget(self.gallery_container)
        layout.addWidget(self.scroll_gallery)

        # 默认空态提示
        self.lbl_no_gallery = QLabel("暂未查询到图纸附件。请在上方输入备案号进行检索。")
        self.lbl_no_gallery.setAlignment(Qt.AlignCenter)
        self.lbl_no_gallery.setStyleSheet("color: #94A3B8; font-size: 13px;")
        layout.addWidget(self.lbl_no_gallery)

    def setup_history_tab(self):
        layout = QVBoxLayout(self.tab_history)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        lbl = QLabel("备案变更生命周期轨迹:")
        lbl.setFont(QFont("PingFang SC", 12, QFont.Bold))
        layout.addWidget(lbl)

        self.txt_history = QTextEdit()
        self.txt_history.setReadOnly(True)
        self.txt_history.setPlaceholderText("在此处展示首次备案、变更记录、注销轨迹及年度报告提交记录...")
        self.txt_history.setStyleSheet("""
            QTextEdit {
                background-color: #F8FAFC;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                padding: 14px;
                font-size: 13px;
                color: #334155;
            }
        """)
        layout.addWidget(self.txt_history)

    def setup_logs_tab(self):
        layout = QVBoxLayout(self.tab_logs)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # 顶部工具与过滤栏
        top_bar = QHBoxLayout()
        top_bar.setSpacing(10)

        lbl_filter = QLabel("级别:")
        lbl_filter.setStyleSheet("font-size: 13px; font-weight: 600; color: #334155;")
        top_bar.addWidget(lbl_filter)

        self.combo_log_level = QComboBox()
        self.combo_log_level.addItems(["全部级别", "INFO", "WARN", "ERROR", "SUCCESS"])
        self.combo_log_level.setFixedHeight(30)
        self.combo_log_level.setStyleSheet("""
            QComboBox {
                background-color: #FFFFFF;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 2px 10px;
                font-size: 12px;
                color: #0F172A;
            }
        """)
        self.combo_log_level.currentIndexChanged.connect(self.filter_logs)
        top_bar.addWidget(self.combo_log_level)

        self.input_log_search = QLineEdit()
        self.input_log_search.setPlaceholderText("🔍 搜索日志关键字 (如 kaptcha, 403, 500, token, 超时)...")
        self.input_log_search.setFixedHeight(30)
        self.input_log_search.setStyleSheet("""
            QLineEdit {
                background-color: #FFFFFF;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 0 10px;
                font-size: 12px;
                color: #0F172A;
            }
        """)
        self.input_log_search.textChanged.connect(self.filter_logs)
        top_bar.addWidget(self.input_log_search, stretch=1)

        self.chk_auto_scroll = QCheckBox("自动滚动")
        self.chk_auto_scroll.setChecked(True)
        self.chk_auto_scroll.setStyleSheet("font-size: 12px; color: #475569;")
        top_bar.addWidget(self.chk_auto_scroll)

        self.btn_copy_logs = QPushButton("📋 复制全部")
        self.btn_copy_logs.setFixedHeight(30)
        self.btn_copy_logs.setStyleSheet("""
            QPushButton {
                background-color: #F1F5F9;
                color: #334155;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 0 12px;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:hover { background-color: #E2E8F0; }
        """)
        self.btn_copy_logs.clicked.connect(self.copy_logs_to_clipboard)
        top_bar.addWidget(self.btn_copy_logs)

        self.btn_clear_logs = QPushButton("🗑️ 清空显示")
        self.btn_clear_logs.setFixedHeight(30)
        self.btn_clear_logs.setStyleSheet("""
            QPushButton {
                background-color: #F1F5F9;
                color: #334155;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 0 12px;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:hover { background-color: #E2E8F0; }
        """)
        self.btn_clear_logs.clicked.connect(self.clear_logs)
        top_bar.addWidget(self.btn_clear_logs)

        self.btn_open_logfile = QPushButton("📁 打开日志文件")
        self.btn_open_logfile.setFixedHeight(30)
        self.btn_open_logfile.setStyleSheet("""
            QPushButton {
                background-color: #F1F5F9;
                color: #334155;
                border: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 0 12px;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:hover { background-color: #E2E8F0; }
        """)
        self.btn_open_logfile.clicked.connect(self.open_log_file)
        top_bar.addWidget(self.btn_open_logfile)

        layout.addLayout(top_bar)

        # 终端风格日志控制台
        self.txt_logs = QTextEdit()
        self.txt_logs.setReadOnly(True)
        self.txt_logs.setStyleSheet("""
            QTextEdit {
                background-color: #0F172A;
                color: #E2E8F0;
                font-family: 'SF Mono', 'Menlo', 'Consolas', 'Courier New', monospace;
                font-size: 12px;
                line-height: 1.4;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 12px;
            }
        """)
        layout.addWidget(self.txt_logs, stretch=1)

    def _format_log_html(self, timestamp: str, level: str, msg: str) -> str:
        color_map = {
            "INFO": "#38BDF8",      # 亮天蓝
            "WARN": "#FBBF24",      # 暖橙黄
            "ERROR": "#F87171",     # 鲜明红
            "SUCCESS": "#4ADE80",   # 清爽绿
        }
        badge_color = color_map.get(level.upper(), "#94A3B8")
        escaped_msg = (
            str(msg).replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace('"', "&quot;")
        )
        return (
            f'<div style="margin: 2px 0; font-family: monospace;">'
            f'<span style="color: #64748B;">[{timestamp}]</span> '
            f'<span style="color: {badge_color}; font-weight: bold;">[{level.upper():<7}]</span> '
            f'<span style="color: #F1F5F9;">{escaped_msg}</span>'
            f'</div>'
        )

    def _is_log_visible(self, log_item: dict) -> bool:
        sel_level = self.combo_log_level.currentText()
        if sel_level != "全部级别" and log_item["level"] != sel_level:
            return False
        search_kw = self.input_log_search.text().strip().lower()
        if search_kw:
            full_text = f"{log_item['timestamp']} {log_item['level']} {log_item['msg']}".lower()
            if search_kw not in full_text:
                return False
        return True

    def append_log(self, timestamp: str, level: str, msg: str):
        item = {"timestamp": timestamp, "level": level, "msg": msg}
        self.raw_logs.append(item)
        if len(self.raw_logs) > 5000:
            self.raw_logs.pop(0)

        if self._is_log_visible(item):
            html = self._format_log_html(timestamp, level, msg)
            self.txt_logs.append(html)
            if self.chk_auto_scroll.isChecked():
                self.txt_logs.moveCursor(QTextCursor.End)

    def filter_logs(self):
        self.txt_logs.clear()
        matching_html = []
        for item in self.raw_logs:
            if self._is_log_visible(item):
                matching_html.append(self._format_log_html(item["timestamp"], item["level"], item["msg"]))
        if matching_html:
            self.txt_logs.setHtml("".join(matching_html))
            if self.chk_auto_scroll.isChecked():
                self.txt_logs.moveCursor(QTextCursor.End)

    def copy_logs_to_clipboard(self):
        lines = [f"[{x['timestamp']}] [{x['level']}] {x['msg']}" for x in self.raw_logs]
        text = "\n".join(lines)
        QGuiApplication.clipboard().setText(text)
        self.lbl_status.setText(f"📋 已复制 {len(lines)} 条日志到系统剪贴板")

    def clear_logs(self):
        self.raw_logs.clear()
        self.txt_logs.clear()
        self.lbl_status.setText("已清空当前运行日志显示")

    def open_log_file(self):
        if os.path.exists(LOG_FILE):
            QDesktopServices.openUrl(QUrl.fromLocalFile(LOG_FILE))
        else:
            QMessageBox.information(self, "提示", f"日志文件尚未生成: {LOG_FILE}")

    def _filter_components(self, query: str):
        q = query.strip().lower()
        raw_text = getattr(self, "raw_components_text", "")
        if not raw_text:
            return
        if not q:
            self.txt_components.setPlainText(raw_text)
            self.lbl_comp_count.setText("🧪 全配方成分明细")
            return

        lines = raw_text.split("\n")
        matched = []
        matched_count = 0
        for line in lines:
            if not line.strip():
                matched.append("")
            elif line.startswith("【") or q in line.lower():
                matched.append(line)
                if not line.startswith("【"):
                    matched_count += 1
        self.txt_components.setPlainText("\n".join(matched))
        self.lbl_comp_count.setText(f"🧪 筛选出 {matched_count} 项匹配成分")

    def copy_formula(self):
        text = self.txt_components.toPlainText().strip()
        if text:
            QGuiApplication.clipboard().setText(text)
            self.lbl_status.setText("📋 配方成分明细已复制到系统剪贴板")
            QMessageBox.information(self, "复制成功", "配方成分列表已成功复制到系统剪贴板！")

    def _on_type_changed(self, index: int):
        qtype = self.combo_type.currentData()
        idx_basic = self.tabs.indexOf(self.tab_basic)
        idx_eff = self.tabs.indexOf(self.tab_efficacy_widget)
        idx_comp = self.tabs.indexOf(self.tab_components)
        idx_gal = self.tabs.indexOf(self.tab_gallery)
        idx_hist = self.tabs.indexOf(self.tab_history)

        if qtype == "special":
            self.input_record.setPlaceholderText("输入特殊化妆品批准文号或产品名称，支持空格/换行批量并发查询 (如: 国妆特字20245464、国妆特进字J...)...")
            if idx_basic >= 0: self.tabs.setTabText(idx_basic, "⭐ 特殊化妆品注册信息")
            if idx_eff >= 0: self.tabs.setTabText(idx_eff, "✨ 功效宣称与评价")
            if idx_comp >= 0: self.tabs.setTabText(idx_comp, "🧪 注册标准与全配方成分")
            if idx_gal >= 0: self.tabs.setTabText(idx_gal, "🖼️ 上市销售包装与图纸PDF")
            if idx_hist >= 0: self.tabs.setTabText(idx_hist, "📜 注册审批与全周期轨迹")
        elif qtype == "1688":
            self.input_record.setPlaceholderText("输入 1688 或 抖音商品链接 / 分享文案 (支持自动识别)...")
            self.tabs.setCurrentWidget(self.tab_1688)
        else:
            self.input_record.setPlaceholderText("输入备案编号，支持多个空格/换行分隔批量并发查询 (如: 沪G... 粤G...)...")
            if idx_basic >= 0: self.tabs.setTabText(idx_basic, "📋 备案基本信息")
            if idx_eff >= 0: self.tabs.setTabText(idx_eff, "✨ 功效宣称与评价")
            if idx_comp >= 0: self.tabs.setTabText(idx_comp, "🧪 全配方成分明细")
            if idx_gal >= 0: self.tabs.setTabText(idx_gal, "🖼️ 包装图纸与画廊")
            if idx_hist >= 0: self.tabs.setTabText(idx_hist, "📜 变更与生命周期轨迹")

    def _on_input_text_changed(self, text: str):
        t = text.strip()
        if not t:
            return
        # 智能识别 1688 或 抖音链接 -> 自动切换到电商素材采集
        is_ecommerce = (
            ("1688" in t and ("http" in t or "/offer/" in t or (t.isdigit() and len(t) >= 10))) or
            any(k in t for k in ["jinritemai.com", "douyin.com", "iesdouyin.com"])
        )
        if is_ecommerce:
            if self.combo_type.currentData() != "1688":
                self.combo_type.blockSignals(True)
                idx = self.combo_type.findData("1688")
                if idx >= 0:
                    self.combo_type.setCurrentIndex(idx)
                self.combo_type.blockSignals(False)
                self._on_type_changed(idx)
        # 智能识别特字/特进字 -> 自动切换到特殊化妆品
        elif any(k in t for k in ["特字", "特进", "国妆特"]):
            if self.combo_type.currentData() != "special":
                self.combo_type.blockSignals(True)
                idx = self.combo_type.findData("special")
                if idx >= 0:
                    self.combo_type.setCurrentIndex(idx)
                self.combo_type.blockSignals(False)
                self._on_type_changed(idx)
        # 智能识别普通网备字 -> 自动切换到普通化妆品
        elif "网备" in t or re.search(r"[\u4e00-\u9fa5][GJgj]妆网备", t):
            if self.combo_type.currentData() != "general":
                self.combo_type.blockSignals(True)
                idx = self.combo_type.findData("general")
                if idx >= 0:
                    self.combo_type.setCurrentIndex(idx)
                self.combo_type.blockSignals(False)
                self._on_type_changed(idx)

    def start_query(self):
        query_type = self.combo_type.currentData()
        text_raw = self.input_record.text().strip()

        is_ecommerce = (
            query_type == "1688" or
            "1688.com" in text_raw or
            any(k in text_raw for k in ["jinritemai.com", "douyin.com", "iesdouyin.com"])
        )
        if is_ecommerce:
            self.tabs.setCurrentWidget(self.tab_1688)
            if text_raw:
                self.tab_1688.input_url.setText(text_raw)
                self.tab_1688.start_extract()
            return

        is_special_query = (
            query_type == "special" or
            any(k in text_raw for k in ["特字", "特进", "国妆特"])
        )
        if is_special_query:
            idx = self.combo_type.findData("special")
            if idx >= 0 and self.combo_type.currentIndex() != idx:
                self.combo_type.blockSignals(True)
                self.combo_type.setCurrentIndex(idx)
                self.combo_type.blockSignals(False)
                self._on_type_changed(idx)

            text = self.input_record.text().strip()
            if not text:
                QMessageBox.warning(self, "提示", "请输入特殊化妆品批准文号或产品名称！")
                return

            parts = [x.strip() for x in re.split(r"[\s,;，；\n]+", text) if x.strip()]
            if not parts:
                QMessageBox.warning(self, "提示", "未识别到有效的查询内容，请确认输入格式。")
                return

            if len(parts) > 1:
                self.btn_search.setEnabled(False)
                self.progress_bar.show()
                self.lbl_status.setText(f"正在并发检索 {len(parts)} 款特殊化妆品...")
                self.controller.start_batch_special_query(parts)
            else:
                self.batch_bar.hide()
                self.btn_search.setEnabled(False)
                self.progress_bar.show()
                self.lbl_status.setText("正在连接国家药监局特殊化妆品库...")
                self.controller.start_special_query(parts[0])
            return

        if not self.engine.is_ready:
            if self.engine.is_reconfiguring:
                self.lbl_status.setText("⏳ 安全通道正在建立中，请稍候就绪后再试...")
                return
            else:
                self.lbl_status.setText("正在重新初始化安全通道与探测连通性...")
                self.progress_bar.show()
                self.btn_search.setText("⚡ 通道初始化中...")
                self.btn_search.setEnabled(False)
                self.engine.initialize()
                return

        text = self.input_record.text().strip()
        if not text:
            QMessageBox.warning(self, "提示", "请输入有效的化妆品备案编号！")
            return

        parts = [x.strip() for x in re.split(r"[\s,;，；\n]+", text) if x.strip()]

        # 友好的前缀缺失检查（例如漏掉了 "粤G" 变成 "妆网备字2023519949"）
        for p in parts:
            if p.startswith("妆网备字"):
                QMessageBox.warning(
                    self,
                    "编号格式不完整",
                    f"检测到备案编号【{p}】缺少省份与国别代号前缀（例如：粤G{p}）。\n\n国家药监局需根据完整省份代号检索，请补全前缀后再试！"
                )
                return

        records = []
        for p in parts:
            m = re.search(r"[\u4e00-\u9fa5A-Za-z0-9]+[GJgj]妆网备字\d+", p)
            if m:
                records.append(m.group(0))
            else:
                records.append(p)

        if len(records) > 1:
            self.btn_search.setEnabled(False)
            self.progress_bar.show()
            self.lbl_status.setText(f"正在并发检索 {len(records)} 款产品...")
            self.controller.start_batch_query(records)
        elif len(records) == 1:
            self.batch_bar.hide()
            self.btn_search.setEnabled(False)
            self.progress_bar.show()
            self.lbl_status.setText("正在连接国家药监局服务...")
            self.controller.start_query(records[0])
        else:
            QMessageBox.warning(self, "提示", "未识别到有效的备案编号，请确认输入格式。")

    def on_controller_status(self, msg: str):
        self.lbl_status.setText(msg)

    def on_controller_error(self, err_msg: str):
        self.progress_bar.hide()
        self.btn_search.setEnabled(True)
        if self.engine.is_ready:
            self.btn_search.setText("一键查询")
        else:
            self.btn_search.setText("🔄 重新连接通道")
        self.lbl_status.setText("查询未通过")
        log_error(f"查询处理异常中断: {err_msg}")

        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("查询未完成")
        msg_box.setIcon(QMessageBox.Critical)
        tip = "\n\n💡 提示：\n1. 若网络慢或接口响应延迟，可点击下方「🖥️ 查看诊断日志」排查底层通讯与状态码。\n2. 若因 IP 触发风控或被暂时拉黑，可点击「⚙️ 代理设置」重新提取新 IP 后再次重试。"
        msg_box.setText(f"{err_msg}{tip}")

        btn_view_logs = msg_box.addButton("🖥️ 查看诊断日志", QMessageBox.ActionRole)
        btn_proxy = msg_box.addButton("⚙️ 代理设置", QMessageBox.ActionRole)
        btn_ok = msg_box.addButton("确定", QMessageBox.AcceptRole)
        msg_box.setDefaultButton(btn_ok)

        msg_box.exec()
        if msg_box.clickedButton() == btn_view_logs:
            self.tabs.setCurrentWidget(self.tab_logs)
        elif msg_box.clickedButton() == btn_proxy:
            self.open_proxy_settings()

    def on_controller_batch_success(self, all_data: list):
        self.progress_bar.hide()
        self.btn_search.setEnabled(True)
        self.btn_search.setText("一键查询")
        self.batch_results = all_data

        if not all_data:
            self.lbl_status.setText("批量查询未返回有效产品")
            return

        self.combo_batch.blockSignals(True)
        self.combo_batch.clear()
        for idx, item in enumerate(all_data, 1):
            rec = item.get("record_no", "")
            name = item.get("product_name", "未知")
            self.combo_batch.addItem(f"[{idx}/{len(all_data)}] 《{name}》 ({rec})")
        self.combo_batch.blockSignals(False)

        self.lbl_batch_title.setText(f"📦 批量并发归档 (共 {len(all_data)} 项):")
        self.batch_bar.show()
        self.lbl_status.setText(f"🎉 批量并发查询完成！共成功提取 {len(all_data)} 款产品档案。")

        # 默认展示第 1 项
        self.on_controller_success(all_data[0])

    def on_batch_item_selected(self, index: int):
        if hasattr(self, "batch_results") and 0 <= index < len(self.batch_results):
            self.on_controller_success(self.batch_results[index])

    def export_batch_json(self):
        if not hasattr(self, "batch_results") or not self.batch_results:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "批量导出所有档案 JSON", "nmpa_batch_archives.json", "JSON Files (*.json)"
        )
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.batch_results, f, ensure_ascii=False, indent=2)
            QMessageBox.information(self, "导出成功", f"共 {len(self.batch_results)} 款产品档案已成功导出至:\n{path}")

    def on_controller_success(self, data: dict):
        self.progress_bar.hide()
        self.btn_search.setEnabled(True)
        self.btn_search.setText("一键查询")
        self.lbl_status.setText(f"查询成功: 《{data['product_name']}》")
        self.current_data = data
        self.btn_copy_summary.setEnabled(True)
        self.btn_export_json.setEnabled(True)

        is_special = bool(data.get("is_special"))

        # 动态适配卡片标题（普通备案 vs 特殊注册）
        self.card_rec_no.title_lbl.setText("注册证编号" if is_special else "备案编号")
        self.card_rec_date.title_lbl.setText("批准日期" if is_special else "备案通过日期")
        self.card_status.title_lbl.setText("注册批件状态" if is_special else "当前备案状态")
        self.card_children.title_lbl.setText("产品类别属性" if is_special else "是否儿童化妆品")
        self.card_shelf.title_lbl.setText("注册有效期限" if is_special else "使用期限 / 保质期")
        self.card_ent.title_lbl.setText("注册人 / 企业名称" if is_special else "备案人 / 企业名称")
        self.card_ent_addr.title_lbl.setText("注册人地址" if is_special else "备案人地址")
        self.card_efficacy.title_lbl.setText("✨ 特殊用途分类与功效公示" if is_special else "✨ 功效宣称与评价依据 (国家药监局法定公示)")

        # 1. 动态更新顶部 Hero 横幅卡片
        self.hero_title.setText(data.get("product_name") or "-")
        self.hero_subtitle.setText(data.get("product_name_en") or "无英文申报名称")
        self.hero_badge_rec.setText(f"{'注册证号' if is_special else '备案编号'}: {data.get('record_no') or '-'}")

        status = data.get("status") or "-"
        if "注销" in status or "过期" in status:
            self.hero_badge_status.setText(f"● {status}")
            self.hero_badge_status.setStyleSheet("background-color: #FEE2E2; color: #DC2626; border: 1px solid #FCA5A5; font-size: 12px; font-weight: 600; padding: 4px 14px; border-radius: 12px;")
        elif is_special:
            self.hero_badge_status.setText(f"⭐ {status}")
            self.hero_badge_status.setStyleSheet("background-color: #FEF3C7; color: #B45309; border: 1px solid #FDE68A; font-size: 12px; font-weight: 600; padding: 4px 14px; border-radius: 12px;")
        else:
            self.hero_badge_status.setText(f"● {status}")
            self.hero_badge_status.setStyleSheet("background-color: #DCFCE7; color: #16A34A; border: 1px solid #86EFAC; font-size: 12px; font-weight: 600; padding: 4px 14px; border-radius: 12px;")

        # 填充 Tab 1
        self.val_prod.setText(data.get("product_name") or "-")
        self.val_prod_en.setText(data.get("product_name_en") or "无")
        self.val_rec_no.setText(data.get("record_no") or "-")
        self.val_rec_date.setText(data.get("record_date") or "-")
        self.val_status.setText(data.get("status") or "-")
        if is_special:
            self.val_children.setText("进口特殊化妆品" if data.get("is_imported") else "国产特殊化妆品")
        else:
            self.val_children.setText("是" if data.get("is_children") else "否")
        self.val_shelf.setText(data.get("shelf_life") or "-")
        self.val_ent.setText(data.get("enterprise") or "-")
        self.val_ent_addr.setText(data.get("enterprise_addr") or "-")

        mfr_text = (data.get("manufacturer") or "").replace("<br>", "\n").strip()
        self.val_mfr.setText(mfr_text or "-")

        # 功效宣称与评价依据 (Tab 1 摘要卡)
        eff_info = data.get("efficacy_info") or {}
        eff_claims = eff_info.get("claims") or data.get("efficacy_claims") or "常规基础护理/未单独声明功效"
        eff_conclusion = eff_info.get("conclusion") or "按规范免予提交摘要或合规备案"
        meta_parts = []
        if eff_info.get("body_part"):
            meta_parts.append(f"部位: {eff_info.get('body_part')}")
        if eff_info.get("dosage_form"):
            meta_parts.append(f"剂型: {eff_info.get('dosage_form')}")
        if eff_info.get("usage_type"):
            meta_parts.append(f"使用: {eff_info.get('usage_type')}")
        if eff_info.get("target_users"):
            meta_parts.append(f"人群: {eff_info.get('target_users')}")
        meta_str = " | ".join(meta_parts)

        eff_disp = f"【宣称功效】 {eff_claims}\n【评价结论】 {eff_conclusion}"
        if meta_str:
            eff_disp += f"\n【分类属性】 {meta_str}"
        self.val_efficacy.setText(eff_disp)

        usage_full = f"【使用方法】\n{data.get('usage') or '无'}\n\n【贮存条件】\n{data.get('storage') or '干燥阴凉处'}"
        self.val_usage.setText(usage_full)
        self.val_caution.setText(data.get("caution") or "暂无警示用语")

        # 填充 Tab 2 (成分配方 / 注册技术标准)
        comp_text = (data.get("components") or "").replace("<br>", "\n\n").strip()
        formula_list = data.get("formula_list", [])
        if formula_list:
            f_lines = ["【配方成分详细列表】"]
            for idx, item in enumerate(formula_list, 1):
                cname = item.get("cname", "")
                ename = item.get("ename", "")
                f_lines.append(f"{idx}. {cname} ({ename})" if ename else f"{idx}. {cname}")
            comp_text = "\n".join(f_lines) + "\n\n" + comp_text

        self.raw_components_text = comp_text or ""
        self.input_comp_filter.blockSignals(True)
        self.input_comp_filter.clear()
        self.input_comp_filter.blockSignals(False)
        self.txt_components.setPlainText(comp_text or ("暂无注册技术标准与配方数据。" if is_special else "暂无成分配方数据。"))
        if formula_list:
            self.lbl_comp_count.setText(f"🧪 全配方成分明细 (共 {len(formula_list)} 项)")
        else:
            self.lbl_comp_count.setText("🧪 全配方成分明细")

        # 填充 Tab 3 (图纸附件画廊 / 公示文件)
        self.lbl_no_gallery.hide()
        while self.gallery_layout.count():
            item = self.gallery_layout.takeAt(0)
            if item.widget():
                w = item.widget()
                if hasattr(w, "cleanup"):
                    try:
                        w.cleanup()
                    except Exception:
                        pass
                w.setParent(None)
                w.deleteLater()

        col = 0
        row = 0
        total_attachments = 0
        attachments = data.get("attachments") or {}

        # 平面图 / 上市销售包装
        for i, item in enumerate(attachments.get("pmt") or []):
            fname = item.get("name")
            fdate = item.get("date")
            if fname:
                card_title = f"{fname} ({fdate})" if fdate else fname
            else:
                card_title = f"上市销售包装 #{i+1}" if is_special else f"包装平面图 #{i+1}"
            card = AttachmentCard(card_title, item["id"], item["url"], self.engine)
            self.gallery_layout.addWidget(card, row, col)
            col += 1
            if col >= 3:
                col = 0
                row += 1
            total_attachments += 1

        # 立体图
        for i, item in enumerate(attachments.get("ltt") or []):
            fname = item.get("name")
            fdate = item.get("date")
            if fname:
                card_title = f"{fname} ({fdate})" if fdate else fname
            else:
                card_title = f"实物立体图 #{i+1}"
            card = AttachmentCard(card_title, item["id"], item["url"], self.engine)
            self.gallery_layout.addWidget(card, row, col)
            col += 1
            if col >= 3:
                col = 0
                row += 1
            total_attachments += 1

        # 说明书
        for i, item in enumerate(attachments.get("sms") or []):
            fname = item.get("name")
            fdate = item.get("date")
            if fname:
                card_title = f"{fname} ({fdate})" if fdate else fname
            else:
                card_title = f"纸质说明书 #{i+1}"
            card = AttachmentCard(card_title, item["id"], item["url"], self.engine)
            self.gallery_layout.addWidget(card, row, col)
            col += 1
            if col >= 3:
                col = 0
                row += 1
            total_attachments += 1

        # 动态更新画廊选项卡角标数量
        gallery_tab_idx = self.tabs.indexOf(self.tab_gallery)
        if gallery_tab_idx >= 0:
            if is_special:
                tab_label = f"🖼️ 上市销售包装与图纸PDF ({total_attachments})" if total_attachments > 0 else "🖼️ 上市销售包装与图纸PDF"
            else:
                tab_label = f"🖼️ 包装图纸与画廊 ({total_attachments})" if total_attachments > 0 else "🖼️ 包装图纸与画廊"
            self.tabs.setTabText(gallery_tab_idx, tab_label)

        # 1.1 更新顶部 Hero 卡片快速直达按钮文案与角标
        if hasattr(self, "btn_hero_gallery"):
            if is_special:
                self.btn_hero_gallery.setText(f"🖼️ 上市包装与图纸PDF ({total_attachments}份) ➜" if total_attachments > 0 else "🖼️ 上市包装与图纸 (0份)")
                f_count = len(formula_list)
                self.btn_hero_components.setText(f"🧪 全配方成分明细 ({f_count}项) ➜" if f_count > 0 else "🧪 全配方成分明细 ➜")
                self.btn_hero_efficacy.setText("✨ 特殊用途分类与功效公示 ➜")
            else:
                self.btn_hero_gallery.setText(f"🖼️ 包装图纸与画廊 ({total_attachments}张) ➜")
                self.btn_hero_components.setText("🧪 全配方成分明细 ➜")
                self.btn_hero_efficacy.setText("✨ 功效宣称与评价依据 ➜")

        # 1.2 动态装配 Tab 1 中的卡片: self.card_pdf_banner (直接呈现在基本信息页，用户一眼可见)
        if hasattr(self, "card_pdf_banner") and hasattr(self, "layout_pdf_items"):
            while self.layout_pdf_items.count():
                it = self.layout_pdf_items.takeAt(0)
                if it.widget():
                    it.widget().deleteLater()

            all_att_items = []
            for att in (attachments.get("pmt") or []):
                all_att_items.append(att)
            for att in (attachments.get("ltt") or []):
                all_att_items.append(att)
            for att in (attachments.get("sms") or []):
                all_att_items.append(att)

            if all_att_items:
                self.lbl_pdf_banner_title.setText(
                    f"📦 药监局/中检院官方公示：已捕获 {len(all_att_items)} 份上市销售包装与标签电子件 (PDF/包装图纸)"
                    if is_special else
                    f"📦 药监局备案档案图纸：已捕获 {len(all_att_items)} 份包装平面图/立体图"
                )
                for att in all_att_items:
                    row_widget = QFrame()
                    row_widget.setStyleSheet("""
                        QFrame {
                            background-color: #FFFFFF;
                            border: 1px solid #CBD5E1;
                            border-radius: 6px;
                            padding: 6px 12px;
                        }
                        QFrame:hover {
                            border-color: #3B82F6;
                            background-color: #F8FAFC;
                        }
                    """)
                    r_lay = QHBoxLayout(row_widget)
                    r_lay.setContentsMargins(6, 4, 6, 4)
                    r_lay.setSpacing(10)

                    att_name = att.get("name") or f"包装图纸附件 ({att.get('id')})"
                    att_date = att.get("date", "")
                    att_fid = str(att.get("id"))
                    att_url = att.get("url", "")

                    date_text = f"  (报备日期: {att_date})" if att_date else ""
                    lbl_fname = QLabel(f"📄  {att_name}{date_text}")
                    lbl_fname.setFont(QFont("PingFang SC", 12, QFont.Bold))
                    lbl_fname.setStyleSheet("color: #0F172A;")
                    lbl_fname.setTextInteractionFlags(Qt.TextSelectableByMouse)
                    r_lay.addWidget(lbl_fname, stretch=1)

                    # 快速大图预览按钮
                    btn_pv = QPushButton("🔍 快速预览")
                    btn_pv.setCursor(Qt.PointingHandCursor)
                    btn_pv.setStyleSheet("""
                        QPushButton {
                            background-color: #EFF6FF; color: #2563EB;
                            border: 1px solid #BFDBFE; border-radius: 5px;
                            padding: 4px 10px; font-size: 11px; font-weight: 600;
                        }
                        QPushButton:hover { background-color: #DBEAFE; }
                    """)
                    def _make_preview_cb(f_id=att_fid, f_title=att_name, f_url=att_url):
                        def _cb():
                            if f_id in ATTACHMENT_CACHE:
                                cached = ATTACHMENT_CACHE[f_id]
                                dlg = ImagePreviewDialog(f_title, cached["raw"], cached["mime"], f_id, self)
                                dlg.exec()
                            else:
                                QDesktopServices.openUrl(QUrl(f_url))
                        return _cb
                    btn_pv.clicked.connect(_make_preview_cb(att_fid, att_name, att_url))
                    r_lay.addWidget(btn_pv)

                    # 下载按钮
                    btn_dl = QPushButton("💾 下载原件")
                    btn_dl.setCursor(Qt.PointingHandCursor)
                    btn_dl.setStyleSheet("""
                        QPushButton {
                            background-color: #007AFF; color: #FFFFFF;
                            border: none; border-radius: 5px;
                            padding: 4px 10px; font-size: 11px; font-weight: 600;
                        }
                        QPushButton:hover { background-color: #0062CC; }
                    """)
                    def _make_download_cb(f_id=att_fid, f_title=att_name, f_url=att_url):
                        def _cb():
                            if f_id in ATTACHMENT_CACHE:
                                cached = ATTACHMENT_CACHE[f_id]
                                raw = cached["raw"]
                                mime = cached["mime"]
                                is_pdf = "pdf" in mime or raw.startswith(b"%PDF")
                                ext = ".pdf" if is_pdf else ".jpg"
                                clean_name = re.sub(r'[\/:*?"<>|\r\n\t]', '_', f_title).strip()
                                if clean_name.lower().endswith(ext.lower()):
                                    clean_name = clean_name[:-len(ext)].strip()
                                def_name = f"{clean_name}_{f_id}{ext}"
                                p, _ = QFileDialog.getSaveFileName(self, "保存附件", def_name, f"Files (*{ext} *.*)")
                                if p:
                                    with open(p, "wb") as f_out:
                                        f_out.write(raw)
                                    QMessageBox.information(self, "保存成功", f"文件已成功保存至:\n{p}")
                            else:
                                QDesktopServices.openUrl(QUrl(f_url))
                        return _cb
                    btn_dl.clicked.connect(_make_download_cb(att_fid, att_name, att_url))
                    r_lay.addWidget(btn_dl)

                    # 浏览器直达
                    btn_br = QPushButton("🌐")
                    btn_br.setToolTip("在浏览器中直接打开附件")
                    btn_br.setCursor(Qt.PointingHandCursor)
                    btn_br.setFixedWidth(28)
                    btn_br.setStyleSheet("""
                        QPushButton {
                            background-color: #F1F5F9; color: #475569;
                            border: 1px solid #CBD5E1; border-radius: 5px;
                            padding: 4px 0px; font-size: 11px;
                        }
                        QPushButton:hover { background-color: #E2E8F0; }
                    """)
                    btn_br.clicked.connect(lambda _, u=att_url: QDesktopServices.openUrl(QUrl(u)))
                    r_lay.addWidget(btn_br)

                    self.layout_pdf_items.addWidget(row_widget)

                self.card_pdf_banner.show()
            else:
                self.card_pdf_banner.hide()

        if total_attachments == 0:
            if is_special:
                spec_details = data.get("special_details") or {}
                claim_url = spec_details.get("claim_url", "")
                tag_pdf = spec_details.get("tag_pdf", "")
                std_pdf = spec_details.get("std_pdf", "")
                extra_msg = ""
                if claim_url:
                    extra_msg += f"\n\n🔗 功效宣称依据公示链接 (已收录在「变更与生命周期轨迹」):\n{claim_url}"
                if tag_pdf:
                    extra_msg += f"\n\n🏷️ 产品标签公示文件: {tag_pdf}"
                if std_pdf:
                    extra_msg += f"\n\n📑 执行标准规范: {std_pdf}"
                self.lbl_no_gallery.setText(
                    f"⭐ 该特殊化妆品在药监局中检院系统（LX=4 上市销售包装）中暂未查询到上传的包装图纸文件。\n（注：新获批或尚未正式上市销售的产品可能尚未由企业上传销售包装电子件）{extra_msg}"
                )
            else:
                self.lbl_no_gallery.setText("该产品备案档案中未包含图片与图纸附件。")
            self.lbl_no_gallery.show()

        # 填充 Tab 4 (历史轨迹与功效公示)
        hist_text = (data.get("history") or "").replace("<br>", "\n").strip()
        ann_text = (data.get("annual_report") or "").replace("<br>", "\n").strip()
        full_hist = f"【备案生命周期轨迹】\n{hist_text or '无变更记录'}\n\n【年度报告情况】\n{ann_text or '正常'}"

        eff_summary = (data.get("efficacy_info") or {}).get("eval_summary", "")
        if eff_summary:
            full_hist += f"\n\n【功效宣称评价依据与项目摘要 (法定公示)】\n{eff_summary}"

        self.txt_history.setPlainText(full_hist)

        # 填充 Tab 2 (专属功效宣称与评价全景选项卡)
        self.render_efficacy_tab(data)

        # 更新 Tab 1 底部功效引导卡
        eff_claims_text = eff_info.get("claims") or "常规基础护理/免予公布摘要"
        self.lbl_bottom_eff_text.setText(f"✨ 本产品法定功效宣称: 【{eff_claims_text}】 | 包含官方评价结论与试验依据报告。")

        # 重置所有滚动条回到最顶端，彻底根除用户停留旧滚动位置错觉
        if hasattr(self, "scroll_basic") and self.scroll_basic:
            self.scroll_basic.verticalScrollBar().setValue(0)
        if hasattr(self, "scroll_efficacy") and self.scroll_efficacy:
            self.scroll_efficacy.verticalScrollBar().setValue(0)
        if hasattr(self, "txt_components") and self.txt_components:
            self.txt_components.verticalScrollBar().setValue(0)
        if hasattr(self, "txt_history") and self.txt_history:
            self.txt_history.verticalScrollBar().setValue(0)

    def render_efficacy_tab(self, data: dict):
        """将查询到的功效与试验数据渲染到专属的功效选项卡"""
        eff_info = data.get("efficacy_info") or {}
        claims_list = eff_info.get("claims_list") or []
        if not claims_list and eff_info.get("claims"):
            claims_list = [eff_info.get("claims")]

        # 1. 渲染功效标签 chips
        while self.eff_tags_layout.count() > 1:
            item = self.eff_tags_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        for c_text in claims_list:
            if not c_text:
                continue
            badge = QLabel(f" {c_text} ")
            badge.setStyleSheet("""
                QLabel {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #DCFCE7, stop:1 #D1FAE5);
                    color: #065F46;
                    border: 1px solid #86EFAC;
                    border-radius: 6px;
                    font-size: 13px;
                    font-weight: 600;
                    padding: 4px 12px;
                }
            """)
            self.eff_tags_layout.insertWidget(self.eff_tags_layout.count() - 1, badge)

        # 2. 渲染结论与属性
        self.eff_conclusion_lbl.setText(eff_info.get("conclusion") or "按规范免予提交摘要或已完成合规备案")
        self.eff_val_body_part.setText(eff_info.get("body_part") or "全身体表")
        self.eff_val_dosage_form.setText(eff_info.get("dosage_form") or "常规剂型")
        self.eff_val_usage_type.setText(eff_info.get("usage_type") or "驻留/淋洗")
        self.eff_val_target_users.setText(eff_info.get("target_users") or "普通人群")

        # 3. 渲染详细试验卡片
        while self.eff_items_layout.count():
            item = self.eff_items_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        test_items = eff_info.get("test_items") or []
        if not test_items:
            empty_card = QFrame()
            empty_card.setStyleSheet("""
                QFrame {
                    background-color: #F8FAFC;
                    border: 1px dashed #CBD5E1;
                    border-radius: 8px;
                    padding: 18px;
                }
            """)
            e_lay = QVBoxLayout(empty_card)
            if data.get("is_special"):
                e_title = QLabel("⭐ 国家特殊化妆品注册技术审评")
                e_title.setStyleSheet("color: #B45309; font-size: 13px; font-weight: bold;")
                e_msg = QLabel("本产品为国家特殊化妆品注册管理，已通过国家中检院综合技术审评核发批准文件。\n相关功效依据摘要与产品技术要求已在国家特殊化妆品公示系统建档备案。")
                e_msg.setStyleSheet("color: #475569; font-size: 12px; line-height: 1.6;")
            else:
                e_title = QLabel("ℹ️ 功效评价摘要公布说明")
                e_title.setStyleSheet("color: #475569; font-size: 13px; font-weight: bold;")
                e_msg = QLabel("依据国家药监局《化妆品监督管理条例》及《化妆品功效宣称评价规范》规定：\n"
                                "1. 仅具有清洁、卸妆、修饰等基础物理作用的产品，按法规免予提交人体功效试验评价摘要。\n"
                                "2. 2021年5月1日《规范》实施前已完成备案的产品，根据过渡期要求由企业自行留档备查，药监局公开平台未收录独立评价摘要。")
                e_msg.setStyleSheet("color: #64748B; font-size: 12px; line-height: 1.6;")
            e_lay.addWidget(e_title)
            e_lay.addWidget(e_msg)
            self.eff_items_layout.addWidget(empty_card)
        else:
            for item in test_items:
                t_card = QFrame()
                t_card.setStyleSheet("""
                    QFrame {
                        background-color: #FFFFFF;
                        border: 1px solid #E2E8F0;
                        border-left: 4px solid #10B981;
                        border-radius: 8px;
                        padding: 12px 16px;
                    }
                """)
                tc_lay = QVBoxLayout(t_card)
                tc_lay.setSpacing(6)

                c_badge_lay = QHBoxLayout()
                c_title = QLabel(f"● 宣称功效: 【{item.get('claim', '综合功效')}】")
                c_title.setStyleSheet("color: #065F46; font-size: 13px; font-weight: bold;")
                c_badge_lay.addWidget(c_title, stretch=1)
                tc_lay.addLayout(c_badge_lay)

                tests = item.get("tests") or []
                if tests:
                    for t in tests:
                        t_box = QFrame()
                        t_box.setStyleSheet("background-color: #F8FAFC; border: 1px solid #F1F5F9; border-radius: 6px; padding: 8px 12px;")
                        tb_lay = QVBoxLayout(t_box)
                        tb_lay.setSpacing(4)
                        m_lbl = QLabel(f"【{t.get('type_name', '评价项目')}】 {t.get('method', '')}")
                        m_lbl.setStyleSheet("color: #1E293B; font-size: 12px; font-weight: bold;")
                        r_lbl = QLabel(t.get("result", "已完成合规评价"))
                        r_lbl.setStyleSheet("color: #334155; font-size: 12px; line-height: 1.6;")
                        r_lbl.setWordWrap(True)
                        r_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
                        tb_lay.addWidget(m_lbl)
                        tb_lay.addWidget(r_lbl)
                        tc_lay.addWidget(t_box)
                elif item.get("desc"):
                    desc_lbl = QLabel(f"评价说明: {item.get('desc')}")
                    desc_lbl.setStyleSheet("color: #475569; font-size: 12px;")
                    desc_lbl.setWordWrap(True)
                    tc_lay.addWidget(desc_lbl)

                self.eff_items_layout.addWidget(t_card)

    def copy_efficacy_report(self):
        """一键复制当前产品的功效宣称与评价全案报告至系统剪贴板"""
        if not hasattr(self, "current_data") or not self.current_data:
            QMessageBox.information(self, "提示", "请先检索化妆品备案档案，再复制功效报告。")
            return
        data = self.current_data
        pname = data.get("product_name") or "-"
        rec = data.get("record_no") or "-"
        eff_info = data.get("efficacy_info") or {}

        report_lines = [
            f"【化妆品法定功效宣称与评价依据报告】",
            f"产品中文名称: {pname}",
            f"备案编号/批件号: {rec}",
            f"备案企业: {data.get('enterprise') or '-'}",
            "-" * 45,
            f"【申报功效宣称】: {eff_info.get('claims') or '常规护理'}",
            f"【官方评价结论】: {eff_info.get('conclusion') or '合规免予公布摘要'}",
            f"【分类属性】: 作用部位: {eff_info.get('body_part') or '-'} | 剂型: {eff_info.get('dosage_form') or '-'} | 使用方式: {eff_info.get('usage_type') or '-'} | 适用人群: {eff_info.get('target_users') or '-'}"
        ]
        eval_sum = eff_info.get("eval_summary")
        if eval_sum:
            report_lines.append("\n【功效评价依据与试验项目明细】\n" + eval_sum)
        else:
            report_lines.append("\n【功效评价摘要说明】\n依规免于提交人体功效试验摘要或常规日常护理留档备查。")

        full_text = "\n".join(report_lines)
        QGuiApplication.clipboard().setText(full_text)
        QMessageBox.information(self, "复制成功", f"已成功将《{pname}》的法定功效宣称与评价全案复制到剪贴板！")

    def copy_summary(self):
        if not self.current_data:
            return
        d = self.current_data
        is_sp = bool(d.get("is_special"))
        rec_title = "注册证号" if is_sp else "备案编号"
        ent_title = "注册企业" if is_sp else "备案企业"
        date_title = "批准日期" if is_sp else "备案日期"
        att = d.get("attachments") or {}
        pmt_len = len(att.get("pmt") or [])
        ltt_len = len(att.get("ltt") or [])
        eff_claims = d.get("efficacy_claims") or (d.get("efficacy_info") or {}).get("claims") or ""
        eff_line = f"【功效宣称】 {eff_claims}\n" if eff_claims else ""
        if is_sp:
            summary = (
                f"【产品名称】 {d.get('product_name')}\n"
                f"【{rec_title}】 {d.get('record_no')}\n"
                f"【{ent_title}】 {d.get('enterprise')}\n"
                f"{eff_line}"
                f"【{date_title}】 {d.get('record_date')}\n"
                f"【注册状态】 {d.get('status')}\n"
                f"【有效期限】 {d.get('shelf_life')}\n"
            )
        else:
            summary = (
                f"【产品名称】 {d.get('product_name')}\n"
                f"【{rec_title}】 {d.get('record_no')}\n"
                f"【{ent_title}】 {d.get('enterprise')}\n"
                f"{eff_line}"
                f"【{date_title}】 {d.get('record_date')}\n"
                f"【当前状态】 {d.get('status')}\n"
                f"【图纸数量】 平面图 {pmt_len} 张, 立体图 {ltt_len} 张\n"
            )
        QGuiApplication.clipboard().setText(summary)
        QMessageBox.information(self, "复制成功", "产品档案摘要已复制到系统剪贴板！")

    def export_json(self):
        if not self.current_data:
            return
        default_name = f"{self.current_data['record_no']}_{self.current_data['product_name']}.json"
        path, _ = QFileDialog.getSaveFileName(self, "导出档案 JSON", default_name, "JSON Files (*.json)")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.current_data, f, ensure_ascii=False, indent=2)
            QMessageBox.information(self, "导出成功", f"档案已成功导出至:\n{path}")

    def closeEvent(self, event):
        try:
            # 停止更新检查线程，防止退出时线程尚在执行引发 QThread::~QThread fatal abort 闪退
            if hasattr(self, "_update_check_thread") and self._update_check_thread:
                if self._update_check_thread.isRunning():
                    self._update_check_thread.wait(500)
            # 停止代理探针线程
            if hasattr(self, "_probe_worker") and self._probe_worker:
                if self._probe_worker.isRunning():
                    self._probe_worker.wait(500)
        except Exception:
            pass
        super().closeEvent(event)


def setup_exception_handler():
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        import traceback
        err_msg = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        log_error(f"未捕获全局异常:\n{err_msg}")
    sys.excepthook = handle_exception


def main():
    setup_exception_handler()
    # QtWebEngine 需要在 QApplication 实例化前设置共享 OpenGL 上下文，防止特定机器上 WebEngine 崩溃闪退
    QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
    # 彻底解除 Qt 图像加载内存限制 (默认 256MB 极易被备案超高分辨率图纸打爆)
    QImageReader.setAllocationLimit(2048)

    app = QApplication(sys.argv)
    app.setApplicationName("NMPA Cosmetic Archive Viewer")

    font = QFont("PingFang SC", 12)
    app.setFont(font)

    window = MainWindow()
    window.show()
    try:
        from updater import mark_launch_success
        mark_launch_success()
    except Exception:
        pass
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
