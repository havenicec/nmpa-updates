#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1688 商品数据与图片视频解析引擎
基于独立 QtWebEngine Chromium 会话，支持 Cookie 导入、滑块与扫码交互、高频主动探测与秒级极速提取
"""

import re
import json
import os
import time
import urllib.request
from typing import Optional, Dict
from PySide6.QtCore import QObject, Signal, QUrl, QTimer
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage, QWebEngineSettings

from cookie_1688 import inject_cookies_to_profile, get_local_chrome_1688_cookies


def parse_1688_offer_url(raw_url: str) -> str:
    """提取规范化的 1688 商品页面 URL"""
    if not raw_url:
        return ""
    raw = raw_url.strip()

    # 纯数字视为 offerId
    if raw.isdigit():
        return f"https://detail.1688.com/offer/{raw}.html"

    # 匹配 /offer/(\d+).html
    m = re.search(r'/offer/(\d+)\.html', raw)
    if m:
        return f"https://detail.1688.com/offer/{m.group(1)}.html"

    # 匹配 offerId=(\d+) 或 id=(\d+)
    m = re.search(r'(?:offerId|offer_id|id)=(\d+)', raw)
    if m:
        return f"https://detail.1688.com/offer/{m.group(1)}.html"

    return raw


JS_EXTRACTOR_SCRIPT = """
(function() {
    var result = {
        success: false,
        title: '',
        offerId: '',
        companyName: '',
        priceRange: '',
        video: null,
        mainImages: [],
        skuImages: [],
        detailImages: [],
        isBlocked: false,
        blockReason: ''
    };

    var currentHref = window.location.href;
    if (currentHref.includes('_____tmd_____/punish') || document.title.includes('验证码拦截')) {
        result.isBlocked = true;
        result.blockReason = 'captcha';
        return JSON.stringify(result);
    }
    if (currentHref.includes('login.1688.com') || currentHref.includes('login.taobao.com') || document.title.includes('登录')) {
        result.isBlocked = true;
        result.blockReason = 'login';
        return JSON.stringify(result);
    }

    // 1. 尝试从新版 1688 context 数据结构提取 (最为准确完整)
    var globalData = window.context?.result?.global?.globalData;
    var model = globalData?.model;
    var offerDetail = model?.offerDetail;
    var gallery = window.context?.result?.data?.gallery?.fields;
    var productTitle = window.context?.result?.data?.productTitle?.fields;

    if (offerDetail) {
        result.success = true;
        result.title = offerDetail.subject || productTitle?.title || document.title;
        result.offerId = String(offerDetail.offerId || '');
        if (offerDetail.detailUrl) {
            result.detailUrl = offerDetail.detailUrl;
        }
        if (productTitle?.shopInfo?.companyName) {
            result.companyName = productTitle.shopInfo.companyName;
        }

        // 价格范围
        var mainPrice = window.context?.result?.data?.mainPrice?.fields;
        if (mainPrice && mainPrice.priceDisplay) {
            result.priceRange = mainPrice.priceDisplay;
        }

        // 视频
        if (offerDetail.wirelessVideo && offerDetail.wirelessVideo.videoUrls) {
            result.video = {
                title: offerDetail.wirelessVideo.title || '主图视频',
                url: offerDetail.wirelessVideo.videoUrls.android || offerDetail.wirelessVideo.videoUrls.ios,
                cover: offerDetail.wirelessVideo.coverUrl
            };
        } else if (gallery && gallery.video) {
            result.video = {
                title: gallery.video.title || '主图视频',
                url: gallery.video.videoUrl,
                cover: gallery.video.coverUrl
            };
        }

        // 主图与画廊图
        var mainList = offerDetail.mainImageList || [];
        mainList.forEach(item => {
            var u = item.fullPathImageURI || item.imageURI;
            if (u && !result.mainImages.includes(u)) result.mainImages.push(u);
        });
        if (result.mainImages.length === 0 && gallery && gallery.mainImage) {
            gallery.mainImage.forEach(u => {
                if (u && !result.mainImages.includes(u)) result.mainImages.push(u);
            });
        }
        if (gallery && gallery.offerImgList) {
            gallery.offerImgList.forEach(u => {
                if (u && !result.mainImages.includes(u)) result.mainImages.push(u);
            });
        }

        // SKU 规格图
        if (offerDetail.skuProps) {
            offerDetail.skuProps.forEach(prop => {
                var pName = prop.prop;
                if (prop.value) {
                    prop.value.forEach(v => {
                        if (v.imageUrl) {
                            result.skuImages.push({
                                prop: pName,
                                name: v.name || '规格',
                                url: v.imageUrl
                            });
                        }
                    });
                }
            });
        }
    }

    // 2. 详情描述图提取 (优先从 offer_details.content 富文本中提取)
    var contentHtml = window.offer_details?.content || '';
    if (contentHtml) {
        var parser = new DOMParser();
        var doc = parser.parseFromString(contentHtml, 'text/html');
        doc.querySelectorAll('img').forEach(img => {
            var src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-lazyload-src');
            if (src && !result.detailImages.includes(src)) {
                result.detailImages.push(src);
            }
        });
    }

    // 3. 兜底策略: 如果通过 context 没有完全提取全，扫描真实 DOM 节点补充
    if (!result.title) {
        var titleEl = document.querySelector('.title-text') || document.querySelector('h1') || document.querySelector('.d-title');
        if (titleEl) result.title = titleEl.innerText.trim();
        else result.title = document.title.replace(' - 阿里巴巴', '').trim();
    }

    // 兜底补录主图
    if (result.mainImages.length === 0) {
        document.querySelectorAll('.tab-trigger img, .vertical-img img, [class*="gallery"] img').forEach(img => {
            var src = img.getAttribute('src') || img.getAttribute('data-src');
            if (src && src.includes('alicdn.com') && !result.mainImages.includes(src)) {
                result.mainImages.push(src);
            }
        });
    }

    // 兜底补录详情图
    if (result.detailImages.length === 0) {
        var descContainer = document.querySelector('.content-detail') || document.querySelector('#detail-desc') || document.querySelector('[data-role="desc"]');
        if (descContainer) {
            descContainer.querySelectorAll('img').forEach(img => {
                var src = img.getAttribute('src') || img.getAttribute('data-src');
                if (src && src.includes('alicdn.com') && !result.detailImages.includes(src)) {
                    result.detailImages.push(src);
                }
            });
        }
    }

    if (result.mainImages.length > 0 || result.skuImages.length > 0 || result.detailImages.length > 0) {
        result.success = true;
    }

    return JSON.stringify(result);
})()
"""

JS_PROBE_SCRIPT = """
(function(targetId) {
    var curHref = window.location.href;
    if (curHref.includes('_____tmd_____/punish') || document.title.includes('验证码拦截')) {
        return 'captcha';
    }
    if (curHref.includes('login.1688.com') || curHref.includes('login.taobao.com')) {
        return 'login';
    }
    // 关键校验：页面 URL 必须已切换到目标商品，且不能仍停留在旧商品
    if (targetId && !curHref.includes(targetId)) {
        return 'waiting';
    }
    var offerDetail = window.context?.result?.global?.globalData?.model?.offerDetail;
    if (offerDetail) {
        var currentOfferId = String(offerDetail.offerId || '');
        if (targetId && currentOfferId && currentOfferId !== targetId) {
            // 这是上一个商品的残留缓存数据，继续等待新商品挂载
            return 'waiting';
        }
        if (offerDetail.subject || (offerDetail.mainImageList && offerDetail.mainImageList.length > 0)) {
            return 'ready';
        }
    }
    return 'waiting';
})("%s")
"""


class Alibaba1688Engine(QObject):
    """1688 专属爬取与交互服务 (已优化高频主动探测与极速解析)"""
    sig_status = Signal(str)
    sig_loading = Signal(bool)
    sig_success = Signal(dict)
    sig_error = Signal(str)
    sig_need_interaction = Signal(str, str)  # (type: 'captcha' | 'login', msg)
    sig_cookie_synced = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.profile = QWebEngineProfile("1688_isolated_storage", self)
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        self.profile.setHttpUserAgent(
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
        )

        self.page = QWebEnginePage(self.profile, self)
        # 极速解析模式：提取时禁用图片加载，极大节省网络带宽与等待时间
        self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.AutoLoadImages, False)

        self.view = QWebEngineView()
        self.view.setPage(self.page)
        self.view.resize(1024, 768)

        self.current_url = ""
        self.canonical_url = ""
        self.is_fetching = False
        self._start_time = 0

        # 主动高频探测定时器 (每 150ms 探测一次数据是否挂载)
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(150)
        self._poll_timer.timeout.connect(self._on_poll_check)

        self._load_timer = QTimer(self)
        self._load_timer.setSingleShot(True)
        self._load_timer.timeout.connect(self._on_load_timeout)

        self.view.urlChanged.connect(self._on_url_changed)

    def sync_cookies_from_chrome(self) -> int:
        """从本机 Chrome 同步 1688 Cookie"""
        try:
            count = inject_cookies_to_profile(self.profile)
            if count > 0:
                self.sig_cookie_synced.emit(count)
                self.sig_status.emit(f"✅ 已从本机 Chrome 自动同步 {count} 个 1688 安全凭据")
            else:
                self.sig_status.emit("ℹ️ 未在本机 Chrome 发现可用 1688 Cookie，可直接扫码登录")
            return count
        except Exception as e:
            self.sig_status.emit(f"⚠️ Cookie 同步提示: {e}")
            return 0

    def clear_cookies(self):
        """清空所有存储的 Cookie 与登录会话"""
        try:
            self.profile.cookieStore().deleteAllCookies()
            self.profile.clearHttpCache()
            self.sig_status.emit("🧹 已成功清除软件内所有 1688 账号与登录凭据。")
        except Exception as e:
            self.sig_status.emit(f"⚠️ 清理凭据失败: {e}")

    def enable_interactive_mode(self, enable: bool):
        """交互窗口模式切换（扫码或滑块时开启图片加载）"""
        self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.AutoLoadImages, enable)

    def start_fetch(self, raw_url: str):
        """开始极速解析 1688 页面"""
        canonical = parse_1688_offer_url(raw_url)
        if not canonical or not canonical.startswith("http"):
            self.sig_error.emit("请输入有效的 1688 商品链接或 Offer ID (如: https://detail.1688.com/offer/786765906618.html)")
            return

        self.is_fetching = True
        self.canonical_url = canonical
        self.target_offer_id = ""
        m = re.search(r'/offer/(\d+)\.html', canonical)
        if m:
            self.target_offer_id = m.group(1)

        self._start_time = time.time()
        self.enable_interactive_mode(False)  # 极速探测模式

        self.sig_loading.emit(True)
        self.sig_status.emit(f"⚡ 正在极速连接商品页面: {canonical} ...")

        # 核心防串台：立即清空当前 DOM 中的残留数据，避免极速探测误判为上一个旧商品
        self.view.page().runJavaScript("window.context = null; window.offer_details = null;")

        self._load_timer.start(18000)  # 18秒超时保护
        self._poll_timer.start()       # 立即启动 150ms 主动探测
        self.view.load(QUrl(canonical))

    def _on_url_changed(self, url: QUrl):
        url_str = url.toString()
        if "_____tmd_____/punish" in url_str:
            self._poll_timer.stop()
            self.enable_interactive_mode(True)
            self.sig_status.emit("⚠️ 遇到阿里安全滑块验证，正在等待交互验证...")
            self.sig_need_interaction.emit("captcha", "检测到安全验证拦截，请在窗口中按住滑块拖动到最右侧完成验证")
        elif "login.1688.com" in url_str or "login.taobao.com" in url_str:
            self._poll_timer.stop()
            self.enable_interactive_mode(True)
            self.sig_status.emit("🔑 页面需要登录，请使用 1688 / 淘宝 App 扫码登录")
            self.sig_need_interaction.emit("login", "请使用手机 1688 或 淘宝 App 扫描二维码登录")

    def _on_poll_check(self):
        """高频探测商品数据是否已挂载到 DOM"""
        if not self.is_fetching:
            self._poll_timer.stop()
            return

        def handle_probe(state):
            if not self.is_fetching:
                return

            if state == "ready":
                self._poll_timer.stop()
                # 数据已就绪，立即切断浏览器多余的媒体与广告加载
                self.view.stop()
                elapsed = time.time() - self._start_time
                self.sig_status.emit(f"⚡ 页面核心数据已在 {elapsed:.2f} 秒内挂载，正在解析...")
                self._execute_extraction()
            elif state == "captcha":
                self._poll_timer.stop()
                self.enable_interactive_mode(True)
                self.sig_status.emit("⚠️ 遇到阿里安全滑块验证，正在等待交互验证...")
                self.sig_need_interaction.emit("captcha", "检测到安全滑块，请在窗口中完成验证")
            elif state == "login":
                self._poll_timer.stop()
                self.enable_interactive_mode(True)
                self.sig_status.emit("🔑 页面需要登录，请扫码登录...")
                self.sig_need_interaction.emit("login", "请使用手机扫码登录")

        script = JS_PROBE_SCRIPT % (self.target_offer_id or "")
        self.view.page().runJavaScript(script, handle_probe)

    def _execute_extraction(self):
        if not self.is_fetching:
            return

        def on_js_result(raw_json):
            if not self.is_fetching:
                return

            try:
                data = json.loads(raw_json)
            except Exception as e:
                self.sig_error.emit(f"解析页面数据时出错: {e}")
                self._finish_fetch()
                return

            # 防串台兜底校验：如果提取出的 offerId 与目标商品不一致，重新启动轮询等待真实目标商品载入
            cur_id = str(data.get("offerId") or "")
            if self.target_offer_id and cur_id and cur_id != self.target_offer_id:
                self._poll_timer.start()
                return

            if data.get("isBlocked"):
                reason = data.get("blockReason", "captcha")
                self.enable_interactive_mode(True)
                if reason == "captcha":
                    self.sig_status.emit("⚠️ 页面被安全滑块拦截，请在验证窗口完成滑动")
                    self.sig_need_interaction.emit("captcha", "检测到安全验证拦截，请在窗口中按住滑块拖动到最右侧完成验证")
                else:
                    self.sig_status.emit("🔑 页面需要登录，请在窗口中扫码登录")
                    self.sig_need_interaction.emit("login", "请在窗口中扫码登录后重试")
                return

            if data.get("success"):
                # 若详情图未从当前 DOM 提取到，但包含 detailUrl，直接从阿里 CDN 极速拉取 (50ms)
                if len(data.get("detailImages", [])) == 0 and data.get("detailUrl"):
                    try:
                        d_url = data["detailUrl"]
                        if d_url.startswith("//"):
                            d_url = "https:" + d_url
                        req = urllib.request.Request(
                            d_url,
                            headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"}
                        )
                        with urllib.request.urlopen(req, timeout=5) as resp:
                            d_text = resp.read().decode("utf-8", errors="ignore")
                        d_content = ""
                        if "=" in d_text:
                            clean_json = d_text.split("=", 1)[1].strip().rstrip(";")
                            try:
                                d_obj = json.loads(clean_json)
                                d_content = d_obj.get("content", "")
                            except Exception:
                                d_content = d_text
                        else:
                            d_content = d_text

                        d_imgs = re.findall(r'src=[\"\'](https?:?//[^\"\'\s>]+)', d_content)
                        if not d_imgs:
                            d_imgs = re.findall(r'(https?:?//[a-zA-Z0-9\._\-]+\.alicdn\.com/img/[^\"\'\s<>\\]+)', d_content)
                        for u in d_imgs:
                            if u.startswith("//"):
                                u = "https:" + u
                            if u not in data["detailImages"]:
                                data["detailImages"].append(u)
                    except Exception as e:
                        pass

                self._load_timer.stop()
                self._poll_timer.stop()
                self._finish_fetch()
                self.sig_success.emit(data)
                elapsed = time.time() - self._start_time
                self.sig_status.emit(f"🎉 耗时 {elapsed:.2f}s 极速提取成功！共捕获 {len(data.get('mainImages', []))} 张主图、{len(data.get('skuImages', []))} 张规格图、{len(data.get('detailImages', []))} 张详情图")
            else:
                self._finish_fetch()
                self.sig_error.emit("未能从该页面提取到商品数据，请确认商品是否已下架或点击「验证/登录窗口」查看。")

        self.view.page().runJavaScript(JS_EXTRACTOR_SCRIPT, on_js_result)

    def _on_load_timeout(self):
        if self.is_fetching:
            self._poll_timer.stop()
            self._finish_fetch()
            self.sig_error.emit("页面加载超时，请检查网络连接或点击「验证/登录窗口」查看状态")

    def _finish_fetch(self):
        self.is_fetching = False
        self._load_timer.stop()
        self._poll_timer.stop()
        self.sig_loading.emit(False)

    def cancel(self):
        self.is_fetching = False
        self._load_timer.stop()
        self._poll_timer.stop()
        self.view.stop()
        self.sig_loading.emit(False)
        self.sig_status.emit("已取消提取。")
