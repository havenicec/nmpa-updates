#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1688 Cookie 自动获取与同步模块 (macOS Chrome / Edge / 独立会话)
"""

import os
import shutil
import sqlite3
import subprocess
from typing import List, Tuple, Optional
from PySide6.QtCore import QUrl, QByteArray
from PySide6.QtNetwork import QNetworkCookie
from PySide6.QtWebEngineCore import QWebEngineProfile
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend


def get_chrome_safe_storage_password() -> Optional[str]:
    """从 macOS Keychain 获取 Chrome Safe Storage 密码"""
    for service_name in ["Chrome Safe Storage", "Chromium Safe Storage", "Microsoft Edge Safe Storage"]:
        try:
            cmd = ["security", "find-generic-password", "-s", service_name, "-w"]
            pw = subprocess.check_output(cmd, stderr=subprocess.DEVNULL).strip().decode("utf-8")
            if pw:
                return pw
        except Exception:
            continue
    return None


def derive_aes_key(password: str) -> bytes:
    """基于 PBKDF2-SHA1 派生 AES 解密密钥"""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA1(),
        length=16,
        salt=b"saltysalt",
        iterations=1003,
        backend=default_backend()
    )
    return kdf.derive(password.encode("utf-8"))


def decrypt_chrome_cookie_value(enc_val: bytes, key: bytes) -> str:
    """解密 macOS Chromium v10/v11 格式的 Cookie 密文"""
    if not enc_val or not enc_val.startswith(b"v10"):
        return ""
    try:
        enc_payload = enc_val[3:]
        iv = b" " * 16
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        dec = decryptor.update(enc_payload) + decryptor.finalize()
        pad = dec[-1]
        if isinstance(pad, int) and 0 < pad <= 16:
            dec = dec[:-pad]
        # Chromium 新版本在明文头部包含 32 字节哈希/校验头
        if len(dec) > 32:
            candidate = dec[32:]
            try:
                cand_str = candidate.decode("utf-8")
                cand_str.encode("latin-1")
                return cand_str
            except Exception:
                pass
        return dec.decode("utf-8", errors="ignore")
    except Exception:
        return ""


def get_local_chrome_1688_cookies() -> List[Tuple[str, str, str, str, bool, bool]]:
    """
    读取并解密本机 Chrome / Edge 中关于 1688, taobao, alibaba 的 Cookies
    返回格式: [(host_key, name, path, decrypted_val, is_secure, is_httponly), ...]
    """
    pw = get_chrome_safe_storage_password()
    if not pw:
        return []

    key = derive_aes_key(pw)

    cookie_paths = [
        os.path.expanduser("~/Library/Application Support/Google/Chrome/Default/Cookies"),
        os.path.expanduser("~/Library/Application Support/Google/Chrome/Profile 1/Cookies"),
        os.path.expanduser("~/Library/Application Support/Microsoft Edge/Default/Cookies"),
    ]

    target_path = None
    for cp in cookie_paths:
        if os.path.exists(cp):
            target_path = cp
            break

    if not target_path:
        return []

    temp_db = f"/tmp/1688_chrome_cookies_{os.getpid()}.db"
    try:
        shutil.copy2(target_path, temp_db)
        conn = sqlite3.connect(temp_db)
        c = conn.cursor()
        query = """
            SELECT host_key, name, path, encrypted_value, is_secure, is_httponly 
            FROM cookies 
            WHERE host_key LIKE '%1688%' OR host_key LIKE '%.taobao.com' OR host_key LIKE '%.alibaba.com'
        """
        c.execute(query)
        rows = c.fetchall()
        conn.close()

        results = []
        for host, name, path, enc_val, sec, http_only in rows:
            val = decrypt_chrome_cookie_value(enc_val, key)
            if val:
                results.append((host, name, path, val, bool(sec), bool(http_only)))
        return results
    except Exception as e:
        print(f"[cookie_1688] 提取 Cookie 失败: {e}")
        return []
    finally:
        if os.path.exists(temp_db):
            try:
                os.remove(temp_db)
            except Exception:
                pass


def inject_cookies_to_profile(profile: QWebEngineProfile) -> int:
    """将本机 Chrome 的 1688 Cookie 注入到指定的 QWebEngineProfile 中"""
    cookies = get_local_chrome_1688_cookies()
    if not cookies:
        return 0

    store = profile.cookieStore()
    count = 0
    for host, name, path, val, sec, http_only in cookies:
        try:
            cookie = QNetworkCookie(QByteArray(name.encode("utf-8")), QByteArray(val.encode("utf-8")))
            cookie.setDomain(host)
            cookie.setPath(path or "/")
            cookie.setSecure(sec)
            cookie.setHttpOnly(http_only)
            domain_clean = host.lstrip(".")
            store.setCookie(cookie, QUrl(f"https://{domain_clean}"))
            count += 1
        except Exception:
            continue
    return count
