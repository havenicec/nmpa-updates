#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1688 商品图片与视频下载管理器
支持多线程并发下载、分类保存、智能重命名与进度汇报
"""

import os
import re
import ssl
import urllib.request
from typing import List, Dict, Callable, Optional
from PySide6.QtCore import QObject, Signal, QRunnable, QThreadPool


def get_safe_ssl_context():
    """免受 macOS 本地证书缺失或网络代理 MITM 干扰的 SSL 上下文"""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        return None


def clean_alibaba_media_url(url: str) -> str:
    """清理电商 CDN (1688 / 阿里 / 抖音 / 字节电商) 图片后缀，获取最高清晰度原图"""
    if not url:
        return ""
    # 去除协议前缀缺失情况
    if url.startswith("//"):
        url = "https:" + url
    elif not url.startswith("http://") and not url.startswith("https://"):
        url = "https://" + url

    # 1. 1688 / 阿里 CDN 清洗
    if "alicdn.com" in url:
        # 去除 WebP 动态压缩转码后缀
        url = re.sub(r'_\.webp$', '', url)
        # 去除尺寸限制后缀，如 .310x310.jpg, _250x250.jpg, .search.jpg, .summ.jpg
        url = re.sub(r'\.(?:220x220|310x310|search|summ|60x60|100x100)\.jpg$', '.jpg', url)
        url = re.sub(r'_(?:100x100|200x200|220x220|250x250|300x300|400x400|500x500)\.jpg$', '', url)
        # 去除 URL 参数中可能存在的缩放指令
        if "?" in url and not url.endswith(".mp4"):
            base, query = url.split("?", 1)
            if "img.alicdn.com" in base or "cbu01.alicdn.com" in base:
                url = base

    # 2. 抖音 / 字节电商 CDN 清洗 (ecombdimg.com / byteimg.com / bytednsdoc.com)
    elif any(d in url for d in ["ecombdimg.com", "byteimg.com", "bytednsdoc.com"]):
        # 去除尺寸限制与 WebP 降质，转换为官方无损原图模板 ~tplv-{tpl}-image.jpeg
        if "~tplv-" in url:
            base, tpl = url.split("~tplv-", 1)
            tpl_parts = tpl.split("-", 1)
            tpl_prefix = tpl_parts[0] if len(tpl_parts) > 1 else "5mmsx3fupr"
            url = f"{base}~tplv-{tpl_prefix}-image.jpeg"

    return url


def get_thumbnail_url(url: str) -> str:
    """获取极速轻量缩略图 URL (1688 与 抖音专属尺寸加速)"""
    clean = clean_alibaba_media_url(url)
    if "alicdn.com" in clean and not clean.endswith(".mp4"):
        return clean + "_250x250.jpg"
    elif any(d in clean for d in ["ecombdimg.com", "byteimg.com"]):
        if "~tplv-" in clean:
            base, tpl = clean.split("~tplv-", 1)
            tpl_parts = tpl.split("-", 1)
            tpl_prefix = tpl_parts[0] if len(tpl_parts) > 1 else "5mmsx3fupr"
            return f"{base}~tplv-{tpl_prefix}-resize_q:250:250:q80.webp"
    return clean


clean_media_url = clean_alibaba_media_url


def sanitize_filename(name: str) -> str:
    """清理文件名中的非法字符"""
    name = re.sub(r'[\\/*?:"<>|]', '_', name)
    name = re.sub(r'\s+', ' ', name).strip()
    return name[:120] if len(name) > 120 else name


class DownloadWorkerSignals(QObject):
    sig_progress = Signal(int, int, str)  # completed, total, current_file
    sig_item_done = Signal(str, bool, str)  # item_id, success, local_path_or_err
    sig_all_finished = Signal(int, int, str)  # success_count, fail_count, folder_path


class BatchDownloadWorker(QRunnable):
    """后台批量并发下载执行线程"""
    def __init__(self, items: List[Dict], dest_folder: str, organize_subfolders: bool = True):
        super().__init__()
        self.items = items
        self.dest_folder = dest_folder
        self.organize_subfolders = organize_subfolders
        self.signals = DownloadWorkerSignals()
        self.is_cancelled = False

    def cancel(self):
        self.is_cancelled = True

    def run(self):
        total = len(self.items)
        success_count = 0
        fail_count = 0

        # 分类目录映射
        category_dir_map = {
            "main": "01_主图画廊",
            "sku": "02_规格SKU图",
            "detail": "03_详情描述图",
            "video": "04_商品视频"
        }

        os.makedirs(self.dest_folder, exist_ok=True)

        for idx, item in enumerate(self.items):
            if self.is_cancelled:
                break

            cat = item.get("category", "detail")
            title = item.get("title", f"item_{idx+1}")
            raw_url = item.get("url", "")
            media_url = clean_alibaba_media_url(raw_url)
            item_id = item.get("id", str(idx))

            # 确定保存子目录
            if self.organize_subfolders:
                sub_name = category_dir_map.get(cat, "05_其他素材")
                target_dir = os.path.join(self.dest_folder, sub_name)
            else:
                target_dir = self.dest_folder
            os.makedirs(target_dir, exist_ok=True)

            # 确定文件后缀
            ext = ".jpg"
            if cat == "video" or ".mp4" in media_url.lower():
                ext = ".mp4"
            elif ".png" in media_url.lower():
                ext = ".png"
            elif ".gif" in media_url.lower():
                ext = ".gif"

            safe_title = sanitize_filename(title)
            # 如果不按目录分，前缀标注分类
            if not self.organize_subfolders:
                prefix = {"main": "主图", "sku": "规格", "detail": "详情", "video": "视频"}.get(cat, "素材")
                file_name = f"{prefix}_{safe_title}{ext}"
            else:
                file_name = f"{safe_title}{ext}"

            local_path = os.path.join(target_dir, file_name)

            # 文件名查重避免覆盖
            dup_idx = 1
            base_local, base_ext = os.path.splitext(local_path)
            while os.path.exists(local_path):
                local_path = f"{base_local}_{dup_idx}{base_ext}"
                dup_idx += 1

            self.signals.sig_progress.emit(idx, total, os.path.basename(local_path))

            # 下载文件
            try:
                headers = {
                    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                }
                if "alicdn.com" in media_url:
                    headers["Referer"] = "https://detail.1688.com/"
                elif any(d in media_url for d in ["ecombdimg.com", "byteimg.com", "zjcdn.com", "bytednsdoc.com"]):
                    headers["Referer"] = "https://haohuo.jinritemai.com/"

                req = urllib.request.Request(media_url, headers=headers)
                ssl_ctx = get_safe_ssl_context()
                with urllib.request.urlopen(req, timeout=20, context=ssl_ctx) as resp:
                    data = resp.read()
                    with open(local_path, "wb") as f:
                        f.write(data)
                success_count += 1
                self.signals.sig_item_done.emit(item_id, True, local_path)
            except Exception as e:
                fail_count += 1
                self.signals.sig_item_done.emit(item_id, False, str(e))

            self.signals.sig_progress.emit(idx + 1, total, os.path.basename(local_path))

        self.signals.sig_all_finished.emit(success_count, fail_count, self.dest_folder)
