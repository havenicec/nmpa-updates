#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音 / 今日特卖 / 抖店商品全量素材解析引擎
通过 Chromium 移动端沙箱会话与安全 API 挂载拦截技术，秒级极速提取主图画廊、规格SKU图、详情图与高清视频
"""

import re
import json
import os
import time
import ssl
import urllib.request
import urllib.parse
from typing import Optional, Dict

from PySide6.QtCore import QObject, Signal, QUrl, QTimer
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import (
    QWebEngineProfile, QWebEnginePage, QWebEngineScript, QWebEngineSettings
)


def get_safe_ssl_context():
    """免受 macOS 本地证书缺失或网络代理 MITM 干扰的 SSL 上下文"""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        return None


def parse_douyin_offer_url(raw_input: str) -> str:
    """从分享文案或各种链接中解析规范化抖音商品链接"""
    if not raw_input:
        return ""
    raw = raw_input.strip()

    # 1. 从分享文案中提取 HTTP 链接
    m = re.search(r'https?://[^\s\u4e00-\u9fa5]+', raw)
    url = m.group(0) if m else raw

    # 2. 若为 v.douyin.com 形式的短链，解析 302 重定向获取完整带安全签名 (ec_s) 链接
    if "v.douyin.com" in url:
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X)"}
            )
            ssl_ctx = get_safe_ssl_context()
            with urllib.request.urlopen(req, timeout=6, context=ssl_ctx) as resp:
                url = resp.geturl()
        except Exception:
            pass

    return url


DOUYIN_HOOK_JS = """
window.__douyin_data = {
    h5: null,
    detail: null
};

// 拦截 fetch API
const origFetch = window.fetch;
window.fetch = async function(...args) {
    const res = await origFetch.apply(this, args);
    const clone = res.clone();
    clone.text().then(t => {
        try {
            const data = JSON.parse(t);
            const u = typeof args[0] === "string" ? args[0] : (args[0] && args[0].url ? args[0].url : String(args[0]));
            if (u.includes("promotion/pack/h5")) {
                window.__douyin_data.h5 = data;
            } else if (u.includes("promotion/pack/detail")) {
                window.__douyin_data.detail = data;
            }
        } catch(e) {}
    });
    return res;
};

// 拦截 XMLHttpRequest
const origOpen = XMLHttpRequest.prototype.open;
const origSend = XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open = function(method, url) {
    this._url = url;
    return origOpen.apply(this, arguments);
};
XMLHttpRequest.prototype.send = function() {
    this.addEventListener("load", () => {
        try {
            const data = JSON.parse(this.responseText);
            if (this._url.includes("promotion/pack/h5")) {
                window.__douyin_data.h5 = data;
            } else if (this._url.includes("promotion/pack/detail")) {
                window.__douyin_data.detail = data;
            }
        } catch(e) {}
    });
    return origSend.apply(this, arguments);
};
"""


class DouyinEngine(QObject):
    """抖音 / 今日特卖商品素材极速解析引擎"""
    sig_status = Signal(str)
    sig_loading = Signal(bool)
    sig_success = Signal(dict)
    sig_error = Signal(str)
    sig_need_interaction = Signal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.profile = QWebEngineProfile("douyin_isolated_profile", self)
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        # 必须使用 iPhone / Mobile UA 以便抖店正确路由至轻量 H5 结构
        self.profile.setHttpUserAgent(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 "
            "(KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
        )

        hook = QWebEngineScript()
        hook.setName("douyin_api_hook")
        hook.setInjectionPoint(QWebEngineScript.DocumentCreation)
        hook.setWorldId(QWebEngineScript.MainWorld)
        hook.setSourceCode(DOUYIN_HOOK_JS)
        self.profile.scripts().insert(hook)

        self.page = QWebEnginePage(self.profile, self)
        # 极速解析模式：禁用图片预渲染，节约 90% 带宽与时间
        self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.AutoLoadImages, False)

        self.view = QWebEngineView()
        self.view.setPage(self.page)
        self.view.resize(390, 844)

        self.is_fetching = False
        self._is_probing = False
        self._start_time = 0
        self.target_url = ""

        # 400ms 主动探测定时器 (避免高频注入导致 Chromium 崩溃)
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(400)
        self._poll_timer.timeout.connect(self._on_poll_check)

        self._load_timer = QTimer(self)
        self._load_timer.setSingleShot(True)
        self._load_timer.timeout.connect(self._on_timeout)

    def enable_interactive_mode(self, enable: bool):
        try:
            self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.AutoLoadImages, enable)
        except Exception:
            pass

    def start_fetch(self, raw_url: str):
        """开始解析抖音商品素材"""
        canonical = parse_douyin_offer_url(raw_url)
        if not canonical or not canonical.startswith("http"):
            self.sig_error.emit("请输入有效的抖音商品链接（如: https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?...）")
            return

        self.is_fetching = True
        self._is_probing = False
        self.target_url = canonical
        self._start_time = time.time()
        self.enable_interactive_mode(False)

        self.sig_loading.emit(True)
        self.sig_status.emit(f"⚡ 正在极速连接抖音好物页面...")

        self._load_timer.start(18000)
        self._poll_timer.start()
        self.view.load(QUrl(canonical))

    def _on_poll_check(self):
        if not self.is_fetching or self._is_probing:
            return

        self._is_probing = True

        js = """
        (function() {
            var errEl = document.querySelector('.err-reason-text, .error-text');
            var isBlocked = errEl && errEl.innerText.includes('安全风险');
            return JSON.stringify({
                has_h5: !!window.__douyin_data?.h5,
                has_detail: !!window.__douyin_data?.detail,
                is_blocked: isBlocked,
                h5: window.__douyin_data?.h5,
                detail: window.__douyin_data?.detail
            });
        })()
        """
        def on_probe(raw):
            self._is_probing = False
            if not self.is_fetching or not raw:
                return

            try:
                res = json.loads(raw)
            except Exception:
                return

            if res.get("is_blocked"):
                self._finish_fetch()
                self.sig_error.emit("⚠️ 遇到抖音安全风控拦截，请确保粘贴完整的带签名分享链接，或点击「验证/登录窗口」查看")
                return

            # 当主数据已取到，触发一次向下微滚动以激活可能延迟触发的 detail 请求
            if res.get("has_h5"):
                try:
                    self.view.page().runJavaScript("window.scrollTo(0, 1500);")
                except Exception:
                    pass

            # 当核心 H5 已经就绪，且详情数据已抓到 (或距开始已超 2.2 秒)
            if res.get("has_h5") and (res.get("has_detail") or time.time() - self._start_time > 2.2):
                try:
                    self.view.stop()
                except Exception:
                    pass
                self._finish_fetch()
                self._parse_and_emit(res.get("h5", {}), res.get("detail", {}))

        try:
            self.view.page().runJavaScript(js, on_probe)
        except Exception:
            self._is_probing = False

    def _parse_and_emit(self, h5_data: dict, det_data: dict):
        p = h5_data.get("promotion_h5", {})
        basic = p.get("basic_info_data", {})
        title = basic.get("title_info", {}).get("title", "")
        
        # 价格提取 (优先从 URL goods_detail 分->元 提取真实未脱敏价格)
        price_display = self._extract_price(self.target_url, basic)

        shop_info = p.get("shop_info", {}).get("basic_info", {})
        shop_name = shop_info.get("shop_name", "抖音精选店铺")

        # 视频与主图
        video = None
        main_images = []
        head_media = p.get("head_figure_data", {}).get("media_list", [])
        for m in head_media:
            m_type = m.get("type")
            c_list = m.get("content_list", [])
            if m_type == "video" and c_list:
                video = {
                    "title": "主图视频",
                    "url": c_list[0].get("url"),
                    "cover": c_list[0].get("cover_url")
                }
            elif m_type == "image":
                for it in c_list:
                    u = it.get("url")
                    if u and u not in main_images:
                        main_images.append(u)

        # 详情描述图 (去重处理)
        detail_images = []
        d_info = det_data.get("detail_info", {}) if det_data else {}
        det_list = d_info.get("detail_imgs", []) or d_info.get("detail_imgs_new", [])
        seen_uris = set()
        for im in det_list:
            uri = im.get("uri")
            if uri and uri in seen_uris:
                continue
            if uri:
                seen_uris.add(uri)
            urls = im.get("url_list", [])
            if urls:
                u = urls[0]
                if u not in detail_images:
                    detail_images.append(u)

        # 规格 SKU 样图提取 (若商品有多种 SKU 选项)
        sku_images = []
        popup = p.get("init_popup_data", {})
        spec_list = popup.get("sku_data", {}).get("spec_list", []) or popup.get("spec_info", {}).get("spec_list", [])
        for sp in spec_list:
            p_name = sp.get("spec_name", "规格")
            for v in sp.get("values", []):
                v_name = v.get("name", "")
                v_img = v.get("image", {}).get("url_list", [None])[0] if v.get("image") else None
                if v_img:
                    sku_images.append({
                        "prop": p_name,
                        "name": v_name,
                        "url": v_img
                    })

        product_id = ""
        m_id = re.search(r'(?:product_id|promotion_id|id)=(\d+)', self.target_url)
        if m_id:
            product_id = m_id.group(1)

        result = {
            "success": True,
            "platform": "douyin",
            "title": title or "抖音商品",
            "offerId": product_id,
            "companyName": shop_name,
            "priceRange": price_display,
            "video": video,
            "mainImages": main_images,
            "skuImages": sku_images,
            "detailImages": detail_images
        }
        elapsed = time.time() - self._start_time
        self.sig_status.emit(
            f"🎉 耗时 {elapsed:.2f}s 极速提取成功！共捕获 {len(main_images)} 张主图、"
            f"{len(sku_images)} 张规格图、{len(detail_images)} 张详情图"
            + ("、1 个主图视频" if video else "")
        )
        self.sig_success.emit(result)

    def _extract_price(self, raw_url: str, basic_info: dict) -> str:
        """多重策略提取精确价格"""
        # 策略 1: 从 URL query 的 goods_detail 提取精准分转元
        m = re.search(r'goods_detail=([^&]+)', raw_url)
        if m:
            try:
                gd_str = urllib.parse.unquote(m.group(1))
                gd = json.loads(gd_str)
                if "min_price" in gd:
                    val = float(gd["min_price"]) / 100
                    return f"¥{val:.2f}"
            except Exception:
                pass

        # 策略 2: 从 API 返回提取
        price_info = basic_info.get("price_info", {})
        discount_price = price_info.get("discount_price", {}).get("min_price", "")
        regular_price = price_info.get("price", {}).get("min_price", "")
        p_val = discount_price or regular_price
        if p_val and "?" not in p_val:
            prefix = price_info.get("discount_price", {}).get("prefix", "券后")
            return f"{prefix} ¥{p_val}".strip()

        return f"¥{p_val}" if p_val else "待查"

    def _on_timeout(self):
        if self.is_fetching:
            self._finish_fetch()
            self.sig_error.emit("提取页面超时，请检查网络连接或点击「验证/登录窗口」")

    def _finish_fetch(self):
        self.is_fetching = False
        self._is_probing = False
        self._load_timer.stop()
        self._poll_timer.stop()
        self.sig_loading.emit(False)

    def cancel(self):
        self._finish_fetch()
        try:
            self.view.stop()
        except Exception:
            pass
        self.sig_status.emit("已取消提取。")

