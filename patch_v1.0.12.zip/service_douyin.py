#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音 / 今日特卖 / 抖店商品全量素材解析引擎
支持移动端沙箱会话、全渠道URL自动规范化、安全签名拦截探测与全景图影极速提取
"""

import re
import json
import os
import time
import ssl
import urllib.request
import urllib.parse
from typing import Optional, Dict

from PySide6.QtCore import QObject, Signal, QUrl, QTimer
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import (
    QWebEngineProfile, QWebEnginePage, QWebEngineScript, QWebEngineSettings
)


def get_safe_ssl_context():
    """免受 macOS 本地证书缺失或网络代理 MITM 干扰的 SSL 上下文"""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        return None


GLOBAL_DOUYIN_METACACHE: Dict[str, dict] = {}
GLOBAL_DOUYIN_RESOLVE_CACHE: Dict[str, str] = {}


def parse_douyin_offer_url(raw_input: str) -> str:
    """从分享文案、短链、抖店商家后台、短视频链接、商品ID中解析出标准化的链接 (带解析缓存与PC/移动双模式)"""
    if not raw_input:
        return ""
    raw = raw_input.strip()

    if raw in GLOBAL_DOUYIN_RESOLVE_CACHE:
        return GLOBAL_DOUYIN_RESOLVE_CACHE[raw]

    # 1. 如果纯输入的是 15-22 位纯数字（抖店商品 ID）
    if raw.isdigit() and len(raw) >= 15:
        res = f"https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id={raw}"
        GLOBAL_DOUYIN_RESOLVE_CACHE[raw] = res
        return res

    # 2. 从可能夹杂的分享文案中提取 HTTP 链接
    m = re.search(r'https?://[^\s\u4e00-\u9fa5]+', raw)
    url = m.group(0) if m else raw

    # 3. 若为 v.douyin.com 短链，使用 Desktop UA 请求 302 重定向获取真实目标链接
    # (注意：使用桌面端 UA 可直接使短视频短链跳转至官方无水印高画质 /video/ 路由，避免进入阻断网页)
    if "v.douyin.com" in url:
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                }
            )
            ssl_ctx = get_safe_ssl_context()
            with urllib.request.urlopen(req, timeout=8, context=ssl_ctx) as resp:
                url = resp.geturl()
        except Exception:
            pass

    # 4. 判断是否为抖音短视频、图文笔记或发现页弹窗链接 (/video/ 或 /note/ 或 modal_id 或 share/video)
    m_vid = re.search(r'\/(?:video|note)\/(\d+)', url)
    if not m_vid:
        m_vid = re.search(r'[?&]modal_id=(\d+)', url)
    if m_vid:
        vid = m_vid.group(1)
        prefix = "note" if "/note/" in url else "video"
        res = f"https://www.douyin.com/{prefix}/{vid}"
        GLOBAL_DOUYIN_RESOLVE_CACHE[raw] = res
        return res

    # 5. 纠正已下线的老版 /views/product/item2 路由为当前官方商详路由
    if "/views/product/item2" in url:
        url = url.replace("/views/product/item2", "/ecommerce/trade/detail/index.html")

    # 6. 提取商品 ID，并规范化为最简详情页链接
    m_id = re.search(r'(?:product_?id|goods_?id|promotion_?id|item_?id|id)[=\/:](\d{15,22})', url, re.I)
    if not m_id:
        m_id = re.search(r'\/(\d{15,22})(?:\/|\?|$)', url)

    if m_id:
        p_id = m_id.group(1)
        canonical_url = f"https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id={p_id}"
        # 尝试从 redirect query 中缓存 goods_detail
        try:
            parsed = urllib.parse.urlparse(url)
            qs = urllib.parse.parse_qs(parsed.query)
            if "goods_detail" in qs:
                gd = json.loads(qs["goods_detail"][0])
                GLOBAL_DOUYIN_METACACHE[canonical_url] = gd
                GLOBAL_DOUYIN_METACACHE[p_id] = gd
        except Exception:
            pass

        if "ec_s=" not in url:
            GLOBAL_DOUYIN_RESOLVE_CACHE[raw] = canonical_url
            return canonical_url

    GLOBAL_DOUYIN_RESOLVE_CACHE[raw] = url
    return url


DOUYIN_HOOK_JS = """
window.__douyin_data = {
    h5: null,
    detail: null,
    video: null
};

function trySaveDouyinData(data, u) {
    if (!data || typeof data !== 'object') return;
    try {
        // 1. 短视频元数据拦截
        var vDetail = data.aweme_detail || (data.data && data.data.aweme_detail) || null;
        if (!vDetail && data.item_list && Array.isArray(data.item_list) && data.item_list.length > 0) {
            vDetail = data.item_list[0];
        }
        if (vDetail) {
            window.__douyin_data.video = vDetail;
        }

        // 2. 电商商品详情数据拦截
        var p = data.promotion_h5 || (data.data && data.data.promotion_h5) || (data.data && data.data.basic_info_data ? data.data : null);
        if (p) {
            window.__douyin_data.h5 = data.promotion_h5 ? data : { promotion_h5: p };
        } else if (data.head_figure_data || (data.data && data.data.head_figure_data)) {
            var obj = (data.data && data.data.head_figure_data) ? data.data : data;
            window.__douyin_data.h5 = { promotion_h5: obj };
        }

        var d = data.detail_info || (data.data && data.data.detail_info) || (data.detail_imgs ? data : (data.data && data.data.detail_imgs ? data.data : null));
        if (d) {
            window.__douyin_data.detail = data.detail_info ? data : { detail_info: d };
        }
    } catch(e) {}
}

// 拦截 fetch API
const origFetch = window.fetch;
window.fetch = async function(...args) {
    try {
        const res = await origFetch.apply(this, args);
        const clone = res.clone();
        clone.text().then(t => {
            try {
                const data = JSON.parse(t);
                const u = typeof args[0] === "string" ? args[0] : (args[0] && args[0].url ? args[0].url : String(args[0]));
                trySaveDouyinData(data, u);
            } catch(e) {}
        }).catch(function() {});
        return res;
    } catch(e) {
        return origFetch.apply(this, args);
    }
};

// 拦截 XMLHttpRequest
const origOpen = XMLHttpRequest.prototype.open;
const origSend = XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open = function(method, url) {
    this._url = url;
    return origOpen.apply(this, arguments);
};
XMLHttpRequest.prototype.send = function() {
    this.addEventListener("load", function() {
        try {
            const data = JSON.parse(this.responseText);
            trySaveDouyinData(data, this._url || "");
        } catch(e) {}
    });
    return origSend.apply(this, arguments);
};
"""


class DouyinEngine(QObject):
    """抖音 / 今日特卖商品素材极速解析引擎"""
    sig_status = Signal(str)
    sig_loading = Signal(bool)
    sig_success = Signal(dict)
    sig_error = Signal(str)
    sig_need_interaction = Signal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        # 使用独立的内存隔离沙箱 Profile (off-the-record)，彻底规避多进程磁盘数据库锁死、崩溃与旧缓存干扰
        self.profile = QWebEngineProfile(self)
        self.profile.settings().setAttribute(QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False)
        self.profile.settings().setAttribute(QWebEngineSettings.WebAttribute.AutoLoadImages, True)
        self.profile.settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, True)

        # 必须使用 iPhone / Mobile UA 以便抖店正确路由至轻量 H5 结构
        self.profile.setHttpUserAgent(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 "
            "(KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
        )

        # 尝试自动从系统 Chrome 导入抖店与抖音已有的安全凭据
        self.sync_cookies_from_chrome()

        # 严格锁定禁用 HEVC / DASH 专属协商，迫使抖音服务器下发全平台兼容的标准 H.264 MP4 视频流
        self._enforce_non_hevc_cookies()

        hook = QWebEngineScript()
        hook.setName("douyin_api_hook")
        hook.setInjectionPoint(QWebEngineScript.DocumentCreation)
        hook.setWorldId(QWebEngineScript.MainWorld)
        hook.setSourceCode(DOUYIN_HOOK_JS)
        self.profile.scripts().insert(hook)

        self.page = QWebEnginePage(self.profile, self)
        self.view = QWebEngineView()
        self.view.setPage(self.page)
        self.view.resize(390, 844)
        self.view.urlChanged.connect(self._on_url_changed)
        self.view.loadFinished.connect(self._on_load_finished)

        self.is_fetching = False
        self._is_probing = False
        self._is_handling_interaction = False
        self._start_time = 0
        self._last_probe_time = 0
        self.target_url = ""

        # 400ms 主动探测定时器 (多重数据源探测)
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(400)
        self._poll_timer.timeout.connect(self._on_poll_check)

        self._load_timer = QTimer(self)
        self._load_timer.setSingleShot(True)
        self._load_timer.timeout.connect(self._on_timeout)

    def _enforce_non_hevc_cookies(self):
        """确保会话中 hevc_supported=false 与 is_dash_user=0，保证 Chromium 可以正常解析"""
        try:
            from PySide6.QtNetwork import QNetworkCookie
            from PySide6.QtCore import QByteArray
            store = self.profile.cookieStore()
            c_h = QNetworkCookie(QByteArray(b"hevc_supported"), QByteArray(b"false"))
            c_h.setDomain(".douyin.com")
            c_h.setPath("/")
            store.setCookie(c_h, QUrl("https://www.douyin.com"))

            c_d = QNetworkCookie(QByteArray(b"is_dash_user"), QByteArray(b"0"))
            c_d.setDomain(".douyin.com")
            c_d.setPath("/")
            store.setCookie(c_d, QUrl("https://www.douyin.com"))
        except Exception:
            pass

    def _on_load_finished(self, ok: bool):
        """页面主文档加载完毕即时触发探测，消除死锁等待"""
        if not self.is_fetching or self._is_handling_interaction:
            return
        self._is_probing = False
        self._on_poll_check()

    def sync_cookies_from_chrome(self) -> int:
        """从本地 Chrome / Edge 读取并注入 抖音/抖店 凭证"""
        try:
            from cookie_1688 import inject_douyin_cookies_to_profile
            return inject_douyin_cookies_to_profile(self.profile)
        except Exception:
            return 0

    def enable_interactive_mode(self, enable: bool):
        pass

    def start_fetch(self, raw_url: str):
        """开始解析抖音商品素材或短视频"""
        canonical = parse_douyin_offer_url(raw_url)
        if not canonical or not canonical.startswith("http"):
            self.sig_error.emit("请输入有效的抖音或抖店链接（如: https://haohuo.jinritemai.com/... 或 https://v.douyin.com/...）")
            return

        self.is_fetching = True
        self._is_probing = False
        self._is_handling_interaction = False
        self.target_url = canonical
        self._start_time = time.time()
        self._last_probe_time = 0
        self.is_video_mode = "/video/" in canonical or "/note/" in canonical

        self.sig_loading.emit(True)
        if self.is_video_mode:
            self.sig_status.emit("⚡ 正在解析抖音短视频/图文素材...")
            self.profile.setHttpUserAgent(
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
            )
            self.view.resize(1280, 800)
        else:
            self.sig_status.emit("⚡ 正在极速连接抖音好物页面...")
            self.profile.setHttpUserAgent(
                "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
            )
            self.view.resize(390, 844)

        # 25 秒防抖超时保护 (适配复杂网络与脚本分块载入)
        self._load_timer.start(25000)
        self._poll_timer.start()
        self.view.load(QUrl(canonical))

    def _on_url_changed(self, url: QUrl):
        if not self.is_fetching or self._is_handling_interaction:
            return
        url_str = url.toString()
        if any(k in url_str for k in ["login.douyin.com", "sso.jinritemai.com", "passport.douyin.com"]):
            self._handle_interaction_needed("login", "页面需要登录，请使用手机抖音 App 扫码登录")
            return

        # 动态重定向智能感知与自愈：若上游传入短链并在 WebEngine 内跳转至短视频/图文，自动校准模式并重载为高清 PC 页面
        if "/video/" in url_str or "/note/" in url_str or "share/video" in url_str or "modal_id=" in url_str:
            m_vid = re.search(r'\/(?:video|note)\/(\d+)', url_str)
            if not m_vid:
                m_vid = re.search(r'[?&]modal_id=(\d+)', url_str)
            if m_vid:
                vid = m_vid.group(1)
                prefix = "note" if "/note/" in url_str else "video"
                canonical_pc = f"https://www.douyin.com/{prefix}/{vid}"
                if not getattr(self, "is_video_mode", False) or "share/video" in url_str:
                    self.is_video_mode = True
                    self.target_url = canonical_pc
                    self.profile.setHttpUserAgent(
                        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                    )
                    self.view.resize(1280, 800)
                    self.sig_status.emit("⚡ 识别到短视频短链，正在加载 PC 高清播放流...")
                    self.view.load(QUrl(canonical_pc))
                    return

    def _handle_interaction_needed(self, itype: str, message: str):
        """集中处理安全风控或扫码验证，立即截断网络与超时等待"""
        if self._is_handling_interaction:
            return
        self._is_handling_interaction = True
        self._poll_timer.stop()
        self._load_timer.stop()
        try:
            self.view.stop()
        except Exception:
            pass
        self.sig_status.emit(f"⚠️ {message}")
        self.sig_need_interaction.emit(itype, message)

    def _on_poll_check(self):
        if not self.is_fetching or self._is_handling_interaction:
            return

        now = time.time()
        if self._is_probing:
            if now - getattr(self, "_last_probe_time", 0) > 1.2:
                # 前次 JS 探测超时未返回（如发生底层页面切换），强制解锁看门狗
                self._is_probing = False
            else:
                return

        self._is_probing = True
        self._last_probe_time = now

        # 分支 1: 短视频 / 图文笔记解析逻辑 (四路并行探测：播放器实例 + DOM媒体流 + 网络Hook + 图文画廊)
        if getattr(self, "is_video_mode", False):
            js_video = """
            (function() {
                var res = {
                    is_video: true,
                    is_note: false,
                    has_v: false,
                    src: '',
                    sources: [],
                    images: [],
                    title: '',
                    cover: '',
                    author: '',
                    is_blocked: false
                };

                // 1. 安全风控与滑块检测
                var bodyText = document.body ? document.body.innerText : '';
                if (bodyText.includes('安全验证') || bodyText.includes('拖动滑块') || bodyText.includes('验证码')) {
                    res.is_blocked = true;
                    return JSON.stringify(res);
                }

                // 2. 优先从网络拦截数据包获取 (window.__douyin_data.video)
                var hookV = (window.__douyin_data && window.__douyin_data.video) ? window.__douyin_data.video : null;
                if (hookV) {
                    var vObj = hookV.video || {};
                    var playList = (vObj.play_addr && vObj.play_addr.url_list) ? vObj.play_addr.url_list : [];
                    var coverList = (vObj.cover && vObj.cover.url_list) ? vObj.cover.url_list : ((vObj.origin_cover && vObj.origin_cover.url_list) ? vObj.origin_cover.url_list : []);
                    if (playList.length > 0) {
                        res.has_v = true;
                        res.src = playList[0] || '';
                        res.sources = playList;
                        res.title = hookV.desc || document.title;
                        res.cover = coverList[0] || '';
                        res.author = hookV.author ? (hookV.author.nickname || '') : '';
                        return JSON.stringify(res);
                    }
                }

                // 3. 从 window.player (xgplayer 播放器实例) 提取视频流及海报
                var playUrls = [];
                var posterUrl = '';
                if (window.player) {
                    try {
                        if (window.player.config) {
                            if (window.player.config.poster) posterUrl = window.player.config.poster;
                            var cfgUrl = window.player.config.url;
                            if (typeof cfgUrl === 'string' && cfgUrl.startsWith('http')) {
                                playUrls.push(cfgUrl);
                            } else if (Array.isArray(cfgUrl)) {
                                cfgUrl.forEach(function(item) {
                                    if (typeof item === 'string' && item.startsWith('http')) {
                                        playUrls.push(item);
                                    } else if (item && item.src && typeof item.src === 'string' && item.src.startsWith('http')) {
                                        playUrls.push(item.src);
                                    }
                                });
                            }
                        }
                        if (window.player.src) {
                            var pSrc = window.player.src;
                            if (typeof pSrc === 'string' && pSrc.startsWith('http') && !playUrls.includes(pSrc)) {
                                playUrls.push(pSrc);
                            }
                        }
                    } catch(e) {}
                }

                // 4. 从 Player.instances 提取 (兼容多播放器实例)
                if (window.Player && Array.isArray(window.Player.instances)) {
                    window.Player.instances.forEach(function(inst) {
                        try {
                            if (inst && inst.config && inst.config.url) {
                                var cu = inst.config.url;
                                if (typeof cu === 'string' && cu.startsWith('http') && !playUrls.includes(cu)) {
                                    playUrls.push(cu);
                                }
                            }
                        } catch(e) {}
                    });
                }

                // 5. DOM video 探测并解除静音阻断
                var v = document.querySelector('video');
                if (v) {
                    try { v.muted = true; } catch(e) {}
                    var vSrc = v.currentSrc || v.src || '';
                    if (vSrc && vSrc.startsWith('http') && !playUrls.includes(vSrc)) {
                        playUrls.push(vSrc);
                    }
                    var sources = Array.from(v.querySelectorAll('source')).map(function(s){ return s.src; }).filter(Boolean);
                    sources.forEach(function(s) {
                        if (s.startsWith('http') && !playUrls.includes(s)) playUrls.push(s);
                    });
                }

                // 6. 图文笔记 (Note) 探测：如果存在图文多图轮播
                var noteImgs = Array.from(document.querySelectorAll('img[src*="douyinpic.com"], .note-detail-image img, [class*="slider"] img, [class*="swiper"] img'))
                    .map(function(i) { return i.src || i.getAttribute('data-src') || ''; })
                    .filter(function(u) { return u && u.startsWith('http') && !u.includes('avatar') && !u.includes('qrcode'); });
                var uniqueNoteImgs = [];
                noteImgs.forEach(function(im) {
                    if (!uniqueNoteImgs.includes(im)) uniqueNoteImgs.push(im);
                });

                // 7. 标题提取 (全版本 DOM 覆盖)
                var titleEl = document.querySelector('[data-e2e*="video-title"], [data-e2e*="desc"], .title, h1, [class*="video-title"], [class*="video-desc"]');
                var title = titleEl ? titleEl.innerText.trim() : (document.title || '');
                if (title.includes(' - 抖音')) {
                    title = title.replace(' - 抖音', '').trim();
                }

                // 8. 封面图提取
                var cover = posterUrl;
                if (!cover) {
                    var coverImg = document.querySelector('img[src*="biz_tag=pcweb_cover"], img[src*="origin_cover"], img[src*="douyinpic.com"], xg-poster, .xgplayer-poster, [class*="poster"] img');
                    if (coverImg) {
                        cover = coverImg.src || coverImg.getAttribute('style') || '';
                    }
                }
                if (!cover) {
                    var ogImg = document.querySelector('meta[property="og:image"], meta[name="og:image"]');
                    if (ogImg && ogImg.content) cover = ogImg.content;
                }
                if (!cover && uniqueNoteImgs.length > 0) {
                    cover = uniqueNoteImgs[0];
                }

                // 9. 作者昵称
                var authorEl = document.querySelector('[data-e2e*="user-info"], [class*="account-name"], [class*="author"], [class*="user-name"]');
                var author = authorEl ? authorEl.innerText.split('\\n')[0].trim() : '';

                res.has_v = playUrls.length > 0;
                res.src = playUrls[0] || '';
                res.sources = playUrls;
                res.title = title;
                res.cover = cover;
                res.author = author;
                if (!res.has_v && uniqueNoteImgs.length > 0) {
                    res.is_note = true;
                    res.images = uniqueNoteImgs;
                }
                return JSON.stringify(res);
            })()
            """
            def on_video_probe(raw):
                self._is_probing = False
                if not self.is_fetching or not raw or self._is_handling_interaction:
                    return
                try:
                    res = json.loads(raw)
                except Exception:
                    return
                if res.get("is_blocked"):
                    self._handle_interaction_needed("captcha", "检测到抖音安全验证拦截，请在弹出的窗口中拖动滑块完成验证")
                    return
                if res.get("has_v") or (res.get("is_note") and res.get("images")):
                    try:
                        self.view.stop()
                    except Exception:
                        pass
                    self._finish_fetch()
                    self._parse_and_emit_video(res)

            try:
                self.view.page().runJavaScript(js_video, on_video_probe)
            except Exception:
                self._is_probing = False
            return

        # 分支 2: 电商商品详情解析逻辑
        js = """
        (function() {
            var bodyText = document.body ? document.body.innerText : '';
            
            // 1. 检查是否存在安全风控拦截/需要扫码
            var isBlocked = bodyText.includes('安全风险') || 
                            bodyText.includes('请使用抖音APP扫码') || 
                            bodyText.includes('进入抖音查看商品详情') ||
                            document.querySelector('.detail-abnormal, .err-reason-text, .na-rq-code') !== null;

            // 2. 检查是否出现“页面已下线”旧版弹窗，如果是，自动点击“继续访问”
            var offlineBtn = document.querySelector('.offline-dialog__button, .offline-dialog__button-text');
            if (offlineBtn) {
                try { offlineBtn.click(); } catch(e) {}
            }

            // 3. 检查 RENDER_DATA 或 SSR 内嵌数据
            var renderData = null;
            var rdEl = document.querySelector('#RENDER_DATA');
            if (rdEl && rdEl.textContent) {
                try {
                    renderData = JSON.parse(decodeURIComponent(rdEl.textContent));
                } catch(e) {}
            }
            if (!renderData && window.RENDER_DATA) {
                renderData = window.RENDER_DATA;
            }

            // 4. Hook 抓取的数据
            var hookH5 = window.__douyin_data ? window.__douyin_data.h5 : null;
            var hookDetail = window.__douyin_data ? window.__douyin_data.detail : null;

            // 5. DOM 兜底抽取 (若页面已正常渲染出图影)
            var mainImgs = Array.from(document.querySelectorAll('.head-figure img, .carousel img, .swiper-slide img, [class*="head"] img, [class*="gallery"] img, [class*="banner"] img'))
                .map(i => i.src || i.getAttribute('data-src') || i.getAttribute('data-origin-src'))
                .filter(u => u && !u.startsWith('data:') && !u.includes('aweme-qrcode') && !u.includes('product-down'));
            
            var detailImgs = Array.from(document.querySelectorAll('.detail-container img, .detail-imgs img, .product-detail img, [class*="detail"] img'))
                .map(i => i.src || i.getAttribute('data-src') || i.getAttribute('data-origin-src'))
                .filter(u => u && !u.startsWith('data:') && !u.includes('aweme-qrcode') && !u.includes('product-down'));

            var videoEl = document.querySelector('video');
            var videoUrl = videoEl && videoEl.src ? videoEl.src : '';

            var domData = null;
            if (mainImgs.length > 0 || detailImgs.length > 0 || videoUrl) {
                var titleEl = document.querySelector('.title-info, .title, .product-title, h1, [class*="title"]');
                var priceEl = document.querySelector('.price, .price-info, .discount-price, [class*="price"]');
                domData = {
                    title: titleEl ? titleEl.innerText.trim() : (document.title && !document.title.includes('商品详情') ? document.title : ''),
                    price: priceEl ? priceEl.innerText.trim() : '',
                    mainImages: mainImgs,
                    detailImages: detailImgs,
                    video: videoUrl ? { title: "主图视频", url: videoUrl, cover: (videoEl.poster || '') } : null
                };
            }

            return JSON.stringify({
                is_blocked: isBlocked,
                has_h5: !!(hookH5 || renderData),
                has_detail: !!hookDetail,
                has_dom: !!domData,
                h5: hookH5 || renderData,
                detail: hookDetail,
                dom_data: domData
            });
        })()
        """
        def on_probe(raw):
            self._is_probing = False
            if not self.is_fetching or not raw or self._is_handling_interaction:
                return

            try:
                res = json.loads(raw)
            except Exception:
                return

            # 如果检测到安全拦截或扫码，立即唤起交互式窗口
            if res.get("is_blocked"):
                self._handle_interaction_needed("qrcode", "检测到抖音安全验证拦截，请在弹出的窗口中扫码或完成验证")
                return

            # 当主数据已取到，触发一次向下微滚动以激活可能延迟触发的 detail 请求
            if res.get("has_h5"):
                try:
                    self.view.page().runJavaScript("window.scrollTo(0, 1500);")
                except Exception:
                    pass

            # 当核心 H5 已经就绪（或 DOM 数据已就绪），完成提取
            h5_ready = res.get("has_h5") and (res.get("has_detail") or time.time() - self._start_time > 2.5)
            dom_ready = res.get("has_dom") and time.time() - self._start_time > 3.0

            if h5_ready or dom_ready:
                try:
                    self.view.stop()
                except Exception:
                    pass
                self._finish_fetch()
                self._parse_and_emit(res.get("h5", {}), res.get("detail", {}), res.get("dom_data"))

        try:
            self.view.page().runJavaScript(js, on_probe)
        except Exception:
            self._is_probing = False

    def _parse_and_emit(self, h5_data: dict, det_data: dict, dom_data: dict = None):
        h5_data = h5_data or {}
        det_data = det_data or {}

        # 兼容多种数据结构（promotion_h5 或根对象 或 data.promotion_h5）
        p = h5_data.get("promotion_h5") or h5_data.get("data", {}).get("promotion_h5") or h5_data
        basic = p.get("basic_info_data", {})
        title = basic.get("title_info", {}).get("title", "")
        
        # 价格提取 (优先从 URL goods_detail 分->元 提取真实未脱敏价格)
        price_display = self._extract_price(self.target_url, basic)

        shop_info = p.get("shop_info", {}).get("basic_info", {})
        shop_name = shop_info.get("shop_name", "抖音精选店铺")

        # 视频与主图
        video = None
        main_images = []
        head_media = p.get("head_figure_data", {}).get("media_list", [])
        for m in head_media:
            m_type = m.get("type")
            c_list = m.get("content_list", [])
            if m_type == "video" and c_list:
                video = {
                    "title": "主图视频",
                    "url": c_list[0].get("url"),
                    "cover": c_list[0].get("cover_url")
                }
            elif m_type == "image":
                for it in c_list:
                    u = it.get("url")
                    if u and u not in main_images:
                        main_images.append(u)

        # 详情描述图 (去重处理)
        detail_images = []
        d_info = det_data.get("detail_info", {}) if det_data else {}
        det_list = d_info.get("detail_imgs", []) or d_info.get("detail_imgs_new", []) or det_data.get("detail_imgs", [])
        seen_uris = set()
        for im in det_list:
            if isinstance(im, str):
                if im not in detail_images:
                    detail_images.append(im)
                continue
            uri = im.get("uri")
            if uri and uri in seen_uris:
                continue
            if uri:
                seen_uris.add(uri)
            urls = im.get("url_list", [])
            if urls:
                u = urls[0]
                if u not in detail_images:
                    detail_images.append(u)

        # 规格 SKU 样图提取 (若商品有多种 SKU 选项)
        sku_images = []
        popup = p.get("init_popup_data", {})
        spec_list = popup.get("sku_data", {}).get("spec_list", []) or popup.get("spec_info", {}).get("spec_list", [])
        for sp in spec_list:
            p_name = sp.get("spec_name", "规格")
            for v in sp.get("values", []):
                v_name = v.get("name", "")
                v_img = v.get("image", {}).get("url_list", [None])[0] if v.get("image") else None
                if v_img:
                    sku_images.append({
                        "prop": p_name,
                        "name": v_name,
                        "url": v_img
                    })

        # DOM 兜底合并
        if dom_data:
            if not main_images and dom_data.get("mainImages"):
                main_images = dom_data["mainImages"]
            if not detail_images and dom_data.get("detailImages"):
                detail_images = dom_data["detailImages"]
            if not video and dom_data.get("video"):
                video = dom_data["video"]
            if not title and dom_data.get("title"):
                title = dom_data["title"]
            if (not price_display or price_display == "待查") and dom_data.get("price"):
                price_display = dom_data["price"]

        product_id = ""
        m_id = re.search(r'(?:product_?id|promotion_?id|item_?id|id)=(\d+)', self.target_url)
        if m_id:
            product_id = m_id.group(1)

        # 检查是否命中了重定向时预解出的 goods_detail
        initial_gd = GLOBAL_DOUYIN_METACACHE.get(self.target_url) or GLOBAL_DOUYIN_METACACHE.get(product_id)
        if initial_gd:
            if not title and initial_gd.get("title"):
                title = initial_gd["title"]
            if (not price_display or price_display == "待查") and "min_price" in initial_gd:
                try:
                    val = float(initial_gd["min_price"]) / 100
                    price_display = f"¥{val:.2f}"
                except Exception:
                    pass
            if not main_images and initial_gd.get("img", {}).get("url_list"):
                main_images = initial_gd["img"]["url_list"]

        result = {
            "success": True,
            "platform": "douyin",
            "title": title or "抖音商品",
            "offerId": product_id,
            "companyName": shop_name,
            "priceRange": price_display,
            "video": video,
            "mainImages": main_images,
            "skuImages": sku_images,
            "detailImages": detail_images
        }
        elapsed = time.time() - self._start_time
        self.sig_status.emit(
            f"🎉 耗时 {elapsed:.2f}s 极速提取成功！共捕获 {len(main_images)} 张主图、"
            f"{len(sku_images)} 张规格图、{len(detail_images)} 张详情图"
            + ("、1 个主图视频" if video else "")
        )
        self.sig_success.emit(result)

    def _parse_and_emit_video(self, data: dict):
        """解析并输出抖音短视频或图文笔记素材"""
        is_note = data.get("is_note", False)
        best_video_url = data.get("src", "")
        sources = data.get("sources", [])
        if not best_video_url and sources:
            best_video_url = sources[0]

        title = data.get("title", "抖音短视频" if not is_note else "抖音图文笔记")
        if " - 抖音" in title:
            title = title.replace(" - 抖音", "").strip()

        cover = data.get("cover", "")
        m_cov = re.search(r'url\(["\']?(.*?)["\']?\)', cover)
        if m_cov:
            cover = m_cov.group(1)

        video_id = ""
        m_vid = re.search(r'\/(?:video|note)\/(\d+)', self.target_url)
        if not m_vid:
            m_vid = re.search(r'[?&]modal_id=(\d+)', self.target_url)
        if m_vid:
            video_id = m_vid.group(1)

        author = data.get("author", "") or "抖音创作者"
        note_images = data.get("images", [])

        main_images = note_images if is_note and note_images else ([cover] if cover else [])

        result = {
            "success": True,
            "platform": "douyin_video",
            "title": title or ("抖音图文笔记" if is_note else "抖音短视频"),
            "offerId": video_id,
            "companyName": author,
            "priceRange": "图文笔记素材" if is_note else "短视频素材",
            "video": {
                "title": title or "高清短视频",
                "url": best_video_url,
                "cover": cover
            } if best_video_url else None,
            "mainImages": main_images,
            "skuImages": [],
            "detailImages": []
        }
        elapsed = time.time() - self._start_time
        if is_note:
            self.sig_status.emit(f"🎉 耗时 {elapsed:.2f}s 成功提取抖音图文！共捕获 {len(main_images)} 张高清图片")
        else:
            self.sig_status.emit(f"🎉 耗时 {elapsed:.2f}s 成功提取抖音短视频！已捕获高清视频与封面图")
        self.sig_success.emit(result)

    def _extract_price(self, raw_url: str, basic_info: dict) -> str:
        """多重策略提取精确价格"""
        # 策略 1: 从 URL query 的 goods_detail 提取精准分转元
        m = re.search(r'goods_detail=([^&]+)', raw_url)
        if m:
            try:
                gd_str = urllib.parse.unquote(m.group(1))
                gd = json.loads(gd_str)
                if "min_price" in gd:
                    val = float(gd["min_price"]) / 100
                    return f"¥{val:.2f}"
            except Exception:
                pass

        # 策略 2: 从 API 返回提取
        price_info = basic_info.get("price_info", {})
        discount_price = price_info.get("discount_price", {}).get("min_price", "")
        regular_price = price_info.get("price", {}).get("min_price", "")
        p_val = discount_price or regular_price
        if p_val and "?" not in p_val:
            prefix = price_info.get("discount_price", {}).get("prefix", "券后")
            return f"{prefix} ¥{p_val}".strip()

        return f"¥{p_val}" if p_val else "待查"

    def _on_timeout(self):
        if not self.is_fetching or self._is_handling_interaction:
            return

        # 超时保护：若已捕获到短链元数据，直接优雅降级产出
        product_id = ""
        m_id = re.search(r'(?:product_?id|promotion_?id|item_?id|id)=(\d+)', self.target_url)
        if m_id:
            product_id = m_id.group(1)
        initial_gd = GLOBAL_DOUYIN_METACACHE.get(self.target_url) or GLOBAL_DOUYIN_METACACHE.get(product_id)
        if initial_gd:
            self._finish_fetch()
            self._parse_and_emit({}, {}, None)
            return

        self._finish_fetch()
        self.sig_error.emit("提取页面超时，请检查网络连接或点击「验证/登录窗口」扫码验证")

    def _finish_fetch(self):
        self.is_fetching = False
        self._is_probing = False
        self._is_handling_interaction = False
        self._load_timer.stop()
        self._poll_timer.stop()
        self.sig_loading.emit(False)

    def cancel(self):
        self._finish_fetch()
        try:
            self.view.stop()
        except Exception:
            pass
        self.sig_status.emit("已取消提取。")
